--
-- PostgreSQL database dump
--

\restrict WqYM5KwlojtBg3j4X9lpBMIxFvbQ26de2CwG6yFM8I4q85Oxm9VZG1xcjMQxedl

-- Dumped from database version 16.11 (Debian 16.11-1.pgdg12+1)
-- Dumped by pg_dump version 16.11 (Debian 16.11-1.pgdg12+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: l02_runtime; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA l02_runtime;


ALTER SCHEMA l02_runtime OWNER TO postgres;

--
-- Name: mcp_contexts; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA mcp_contexts;


ALTER SCHEMA mcp_contexts OWNER TO postgres;

--
-- Name: mcp_documents; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA mcp_documents;


ALTER SCHEMA mcp_documents OWNER TO postgres;

--
-- Name: shared; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA shared;


ALTER SCHEMA shared OWNER TO postgres;

--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA mcp_documents;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: vector; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA public;


--
-- Name: EXTENSION vector; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION vector IS 'vector data type and ivfflat and hnsw access methods';


--
-- Name: auto_save_context_version(); Type: FUNCTION; Schema: mcp_contexts; Owner: postgres
--

CREATE FUNCTION mcp_contexts.auto_save_context_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF (OLD.current_phase IS DISTINCT FROM NEW.current_phase) OR
     (OLD.iteration IS DISTINCT FROM NEW.iteration) OR
     (OLD.status IS DISTINCT FROM NEW.status) OR
     (OLD.immediate_context IS DISTINCT FROM NEW.immediate_context) THEN
    INSERT INTO context_versions (task_id, version, snapshot, change_type, change_summary)
    VALUES (
      NEW.task_id,
      NEW.version,
      row_to_json(NEW)::jsonb,
      'auto_save',
      'Auto-saved on significant state change'
    );
  END IF;
  RETURN NEW;
END;
$$;


ALTER FUNCTION mcp_contexts.auto_save_context_version() OWNER TO postgres;

--
-- Name: increment_task_version(); Type: FUNCTION; Schema: mcp_contexts; Owner: postgres
--

CREATE FUNCTION mcp_contexts.increment_task_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.version = OLD.version + 1;
  RETURN NEW;
END;
$$;


ALTER FUNCTION mcp_contexts.increment_task_version() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: mcp_contexts; Owner: postgres
--

CREATE FUNCTION mcp_contexts.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION mcp_contexts.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agent_state; Type: TABLE; Schema: l02_runtime; Owner: postgres
--

CREATE TABLE l02_runtime.agent_state (
    agent_id text NOT NULL,
    session_id text NOT NULL,
    state text NOT NULL,
    context jsonb,
    last_updated timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb
);


ALTER TABLE l02_runtime.agent_state OWNER TO postgres;

--
-- Name: checkpoints; Type: TABLE; Schema: l02_runtime; Owner: postgres
--

CREATE TABLE l02_runtime.checkpoints (
    checkpoint_id text NOT NULL,
    agent_id text NOT NULL,
    session_id text NOT NULL,
    state text NOT NULL,
    context_data bytea,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    size_bytes integer,
    compressed boolean DEFAULT false
);


ALTER TABLE l02_runtime.checkpoints OWNER TO postgres;

--
-- Name: active_sessions; Type: TABLE; Schema: mcp_contexts; Owner: postgres
--

CREATE TABLE mcp_contexts.active_sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    session_id character varying(255) NOT NULL,
    task_id character varying(255),
    status character varying(50) DEFAULT 'active'::character varying,
    started_at timestamp with time zone DEFAULT now(),
    last_heartbeat timestamp with time zone DEFAULT now(),
    ended_at timestamp with time zone,
    context_snapshot jsonb,
    recovery_needed boolean DEFAULT false,
    recovery_type character varying(50),
    conversation_summary text,
    unsaved_changes jsonb DEFAULT '[]'::jsonb,
    project_dir character varying(1000),
    git_branch character varying(255),
    CONSTRAINT active_sessions_recovery_type_check CHECK (((recovery_type)::text = ANY ((ARRAY['crash'::character varying, 'compaction'::character varying, 'timeout'::character varying, 'manual'::character varying])::text[]))),
    CONSTRAINT active_sessions_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'ended'::character varying, 'crashed'::character varying, 'compacted'::character varying, 'recovered'::character varying])::text[])))
);


ALTER TABLE mcp_contexts.active_sessions OWNER TO postgres;

--
-- Name: checkpoints; Type: TABLE; Schema: mcp_contexts; Owner: postgres
--

CREATE TABLE mcp_contexts.checkpoints (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    checkpoint_id character varying(255) NOT NULL,
    label character varying(500) NOT NULL,
    description text,
    checkpoint_type character varying(50) DEFAULT 'manual'::character varying,
    task_id character varying(255),
    scope character varying(50) DEFAULT 'task'::character varying,
    included_tasks jsonb DEFAULT '[]'::jsonb,
    snapshot jsonb NOT NULL,
    es_memory_id character varying(255),
    created_by character varying(255),
    session_id character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT checkpoints_checkpoint_type_check CHECK (((checkpoint_type)::text = ANY ((ARRAY['manual'::character varying, 'milestone'::character varying, 'pre_migration'::character varying, 'recovery_point'::character varying, 'auto'::character varying])::text[]))),
    CONSTRAINT checkpoints_scope_check CHECK (((scope)::text = ANY ((ARRAY['task'::character varying, 'global'::character varying, 'multi_task'::character varying])::text[])))
);


ALTER TABLE mcp_contexts.checkpoints OWNER TO postgres;

--
-- Name: context_conflicts; Type: TABLE; Schema: mcp_contexts; Owner: postgres
--

CREATE TABLE mcp_contexts.context_conflicts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_a_id character varying(255) NOT NULL,
    task_b_id character varying(255),
    conflict_type character varying(50) NOT NULL,
    description text NOT NULL,
    severity character varying(20) DEFAULT 'medium'::character varying,
    strength numeric(3,2) NOT NULL,
    evidence jsonb DEFAULT '{}'::jsonb,
    resolution_status character varying(50) DEFAULT 'unresolved'::character varying,
    resolution jsonb,
    resolved_by character varying(255),
    detected_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone,
    detected_by character varying(100),
    detection_method character varying(255),
    CONSTRAINT context_conflicts_conflict_type_check CHECK (((conflict_type)::text = ANY ((ARRAY['state_mismatch'::character varying, 'file_conflict'::character varying, 'spec_contradiction'::character varying, 'version_divergence'::character varying, 'lock_collision'::character varying, 'data_inconsistency'::character varying])::text[]))),
    CONSTRAINT context_conflicts_resolution_status_check CHECK (((resolution_status)::text = ANY ((ARRAY['unresolved'::character varying, 'investigating'::character varying, 'resolved'::character varying, 'ignored'::character varying, 'escalated'::character varying])::text[]))),
    CONSTRAINT context_conflicts_severity_check CHECK (((severity)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying, 'critical'::character varying])::text[])))
);


ALTER TABLE mcp_contexts.context_conflicts OWNER TO postgres;

--
-- Name: context_versions; Type: TABLE; Schema: mcp_contexts; Owner: postgres
--

CREATE TABLE mcp_contexts.context_versions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id character varying(255) NOT NULL,
    version integer NOT NULL,
    snapshot jsonb NOT NULL,
    change_summary text,
    change_type character varying(50),
    created_by character varying(255),
    session_id character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT context_versions_change_type_check CHECK (((change_type)::text = ANY ((ARRAY['manual'::character varying, 'auto_save'::character varying, 'checkpoint'::character varying, 'recovery'::character varying, 'migration'::character varying])::text[])))
);


ALTER TABLE mcp_contexts.context_versions OWNER TO postgres;

--
-- Name: global_context; Type: TABLE; Schema: mcp_contexts; Owner: postgres
--

CREATE TABLE mcp_contexts.global_context (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id character varying(255) NOT NULL,
    project_name character varying(500) NOT NULL,
    description text,
    hard_rules jsonb DEFAULT '[]'::jsonb,
    tech_stack jsonb DEFAULT '[]'::jsonb,
    key_paths jsonb DEFAULT '{}'::jsonb,
    services jsonb DEFAULT '{}'::jsonb,
    active_task_id character varying(255),
    orchestrator_context jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    version integer DEFAULT 1
);


ALTER TABLE mcp_contexts.global_context OWNER TO postgres;

--
-- Name: task_contexts; Type: TABLE; Schema: mcp_contexts; Owner: postgres
--

CREATE TABLE mcp_contexts.task_contexts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id character varying(255) NOT NULL,
    name character varying(500) NOT NULL,
    description text,
    agent_type character varying(100),
    status character varying(50) DEFAULT 'pending'::character varying,
    priority integer DEFAULT 50,
    current_phase character varying(255),
    iteration integer DEFAULT 0,
    score numeric(5,2),
    locked_elements jsonb DEFAULT '[]'::jsonb,
    immediate_context jsonb DEFAULT '{"blockers": [], "nextStep": null, "workingOn": null, "lastAction": null}'::jsonb NOT NULL,
    key_files jsonb DEFAULT '[]'::jsonb,
    technical_decisions jsonb DEFAULT '[]'::jsonb,
    resume_prompt text,
    keywords jsonb DEFAULT '[]'::jsonb,
    token_estimate integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_session_at timestamp with time zone,
    version integer DEFAULT 1,
    CONSTRAINT task_contexts_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'blocked'::character varying, 'archived'::character varying])::text[])))
);


ALTER TABLE mcp_contexts.task_contexts OWNER TO postgres;

--
-- Name: task_relationships; Type: TABLE; Schema: mcp_contexts; Owner: postgres
--

CREATE TABLE mcp_contexts.task_relationships (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_task_id character varying(255) NOT NULL,
    target_task_id character varying(255) NOT NULL,
    relationship_type character varying(50) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    strength numeric(3,2) DEFAULT 1.0,
    created_by character varying(255),
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT task_relationships_relationship_type_check CHECK (((relationship_type)::text = ANY ((ARRAY['blocks'::character varying, 'blocked_by'::character varying, 'depends_on'::character varying, 'dependency_of'::character varying, 'related_to'::character varying, 'parent_of'::character varying, 'child_of'::character varying])::text[])))
);


ALTER TABLE mcp_contexts.task_relationships OWNER TO postgres;

--
-- Name: agents; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    did character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    agent_type character varying(100) DEFAULT 'general'::character varying,
    status character varying(50) DEFAULT 'created'::character varying,
    configuration jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    resource_limits jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.agents OWNER TO postgres;

--
-- Name: alerts; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.alerts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    alert_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    severity character varying(50) NOT NULL,
    type character varying(100) NOT NULL,
    metric character varying(255) NOT NULL,
    message text NOT NULL,
    channels text[] DEFAULT '{}'::text[],
    delivery_attempts integer DEFAULT 0,
    delivered boolean DEFAULT false,
    last_attempt timestamp without time zone,
    agent_id uuid,
    agent_did character varying(255),
    tenant_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.alerts OWNER TO postgres;

--
-- Name: anomalies; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.anomalies (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    anomaly_id character varying(255) NOT NULL,
    metric_name character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    baseline_value numeric(20,6) NOT NULL,
    current_value numeric(20,6) NOT NULL,
    z_score numeric(10,4) NOT NULL,
    deviation_percent numeric(10,4),
    confidence numeric(5,4) DEFAULT 0.95,
    status character varying(50) DEFAULT 'alerting'::character varying,
    detected_at timestamp without time zone NOT NULL,
    resolved_at timestamp without time zone,
    alert_sent boolean DEFAULT false,
    agent_id uuid,
    agent_did character varying(255),
    tenant_id character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.anomalies OWNER TO postgres;

--
-- Name: api_requests; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.api_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id character varying(255) NOT NULL,
    trace_id character varying(255),
    span_id character varying(255),
    "timestamp" timestamp without time zone NOT NULL,
    method character varying(10) NOT NULL,
    path character varying(1000) NOT NULL,
    consumer_id character varying(255),
    tenant_id character varying(255),
    authenticated boolean DEFAULT false,
    auth_method character varying(50),
    status_code integer NOT NULL,
    latency_ms numeric(10,2) NOT NULL,
    request_size_bytes integer,
    response_size_bytes integer,
    rate_limit_tier character varying(50),
    idempotency_key character varying(255),
    idempotent_cache_hit boolean DEFAULT false,
    error_code character varying(50),
    error_message text,
    client_ip character varying(45),
    user_agent text,
    headers jsonb DEFAULT '{}'::jsonb,
    query_params jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.api_requests OWNER TO postgres;

--
-- Name: authentication_events; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.authentication_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    consumer_id character varying(255),
    tenant_id character varying(255),
    auth_method character varying(50) NOT NULL,
    success boolean NOT NULL,
    failure_reason character varying(255),
    client_ip character varying(45),
    user_agent text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.authentication_events OWNER TO postgres;

--
-- Name: circuit_breaker_events; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.circuit_breaker_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    service_id character varying(255) NOT NULL,
    circuit_name character varying(255) NOT NULL,
    event_type character varying(50) NOT NULL,
    state_from character varying(50),
    state_to character varying(50) NOT NULL,
    failure_count integer,
    success_count integer,
    failure_threshold integer,
    timeout_seconds integer,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.circuit_breaker_events OWNER TO postgres;

--
-- Name: claims; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.claims (
    id character varying(128) NOT NULL,
    document_id character varying(128) NOT NULL,
    section_id character varying(128),
    subject character varying(512) NOT NULL,
    predicate character varying(256) NOT NULL,
    object text NOT NULL,
    qualifier text,
    confidence double precision DEFAULT 1.0,
    original_text text,
    claim_type character varying(64) DEFAULT 'factual'::character varying,
    deprecated boolean DEFAULT false,
    deprecated_at timestamp with time zone,
    source_document_id character varying(128),
    embedding public.vector(384),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.claims OWNER TO postgres;

--
-- Name: compliance_results; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.compliance_results (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    result_id character varying(255) NOT NULL,
    execution_id character varying(255) NOT NULL,
    agent_id uuid,
    agent_did character varying(255),
    tenant_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    compliant boolean DEFAULT true,
    violations jsonb DEFAULT '[]'::jsonb,
    constraints_checked jsonb DEFAULT '[]'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.compliance_results OWNER TO postgres;

--
-- Name: configurations; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.configurations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    namespace character varying(100) NOT NULL,
    key character varying(255) NOT NULL,
    value jsonb NOT NULL,
    version integer DEFAULT 1,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.configurations OWNER TO postgres;

--
-- Name: conflicts; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.conflicts (
    id character varying(128) NOT NULL,
    claim_a_id character varying(128) NOT NULL,
    claim_b_id character varying(128) NOT NULL,
    conflict_type character varying(64) NOT NULL,
    strength double precision DEFAULT 0.5,
    resolution_status character varying(32) DEFAULT 'pending'::character varying,
    resolution_details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.conflicts OWNER TO postgres;

--
-- Name: consolidations; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.consolidations (
    id character varying(128) NOT NULL,
    source_document_ids text[] NOT NULL,
    result_document_id character varying(128),
    strategy character varying(64),
    conflicts_resolved integer DEFAULT 0,
    conflicts_pending integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.consolidations OWNER TO postgres;

--
-- Name: control_operations; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.control_operations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    operation_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    user_id character varying(255) NOT NULL,
    operation_type character varying(100) NOT NULL,
    target_agent_id uuid,
    target_agent_did character varying(255),
    command character varying(100) NOT NULL,
    parameters jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    result jsonb,
    error_message text,
    executed_at timestamp without time zone,
    completed_at timestamp without time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.control_operations OWNER TO postgres;

--
-- Name: dataset_examples; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.dataset_examples (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    dataset_id uuid,
    example_id uuid,
    split character varying(50) DEFAULT 'train'::character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.dataset_examples OWNER TO postgres;

--
-- Name: datasets; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.datasets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    version character varying(50) DEFAULT '1.0.0'::character varying,
    description text DEFAULT ''::text,
    tags text[] DEFAULT '{}'::text[],
    split_ratios jsonb DEFAULT '{"test": 0.1, "train": 0.8, "validation": 0.1}'::jsonb,
    lineage jsonb DEFAULT '{"filter_configs": [], "extraction_jobs": [], "source_datasets": [], "transformations": []}'::jsonb,
    statistics jsonb DEFAULT '{}'::jsonb,
    created_by character varying(255) DEFAULT 'L07 DatasetCurator'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.datasets OWNER TO postgres;

--
-- Name: documents; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.documents (
    id character varying(128) NOT NULL,
    source_path character varying(1024) NOT NULL,
    content_hash character varying(64) NOT NULL,
    format character varying(32) DEFAULT 'markdown'::character varying,
    document_type character varying(64) NOT NULL,
    title character varying(512),
    authority_level integer DEFAULT 5,
    raw_content text NOT NULL,
    frontmatter jsonb DEFAULT '{}'::jsonb,
    embedding public.vector(384),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT documents_authority_level_check CHECK (((authority_level >= 1) AND (authority_level <= 10)))
);


ALTER TABLE mcp_documents.documents OWNER TO postgres;

--
-- Name: sections; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.sections (
    id character varying(128) NOT NULL,
    document_id character varying(128) NOT NULL,
    header character varying(512),
    content text NOT NULL,
    level integer DEFAULT 1,
    section_order integer NOT NULL,
    start_line integer,
    end_line integer,
    embedding public.vector(384),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.sections OWNER TO postgres;

--
-- Name: document_summary; Type: VIEW; Schema: mcp_documents; Owner: postgres
--

CREATE VIEW mcp_documents.document_summary AS
 SELECT d.id,
    d.title,
    d.source_path,
    d.document_type,
    d.authority_level,
    d.created_at,
    count(DISTINCT s.id) AS section_count,
    count(DISTINCT c.id) AS claim_count
   FROM ((mcp_documents.documents d
     LEFT JOIN mcp_documents.sections s ON (((d.id)::text = (s.document_id)::text)))
     LEFT JOIN mcp_documents.claims c ON (((d.id)::text = (c.document_id)::text)))
  GROUP BY d.id, d.title, d.source_path, d.document_type, d.authority_level, d.created_at;


ALTER VIEW mcp_documents.document_summary OWNER TO postgres;

--
-- Name: document_tags; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.document_tags (
    document_id character varying(128) NOT NULL,
    tag character varying(128) NOT NULL
);


ALTER TABLE mcp_documents.document_tags OWNER TO postgres;

--
-- Name: entities; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.entities (
    id character varying(128) NOT NULL,
    canonical_id character varying(128) NOT NULL,
    name character varying(512) NOT NULL,
    type character varying(64),
    aliases text[],
    properties jsonb DEFAULT '{}'::jsonb,
    embedding public.vector(384),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.entities OWNER TO postgres;

--
-- Name: evaluations; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.evaluations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid,
    task_id uuid,
    evaluation_type character varying(100) NOT NULL,
    score numeric(5,4),
    metrics jsonb DEFAULT '{}'::jsonb,
    feedback text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.evaluations OWNER TO postgres;

--
-- Name: events; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_type character varying(255) NOT NULL,
    aggregate_type character varying(100) NOT NULL,
    aggregate_id uuid NOT NULL,
    payload jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    version integer DEFAULT 1
);


ALTER TABLE mcp_documents.events OWNER TO postgres;

--
-- Name: feedback; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.feedback (
    id character varying(128) NOT NULL,
    claim_id character varying(128),
    conflict_id character varying(128),
    document_id character varying(128),
    feedback_type character varying(64) NOT NULL,
    content text,
    user_id character varying(128),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.feedback OWNER TO postgres;

--
-- Name: feedback_entries; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.feedback_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid,
    task_id uuid,
    feedback_type character varying(100) NOT NULL,
    rating integer,
    content text,
    metadata jsonb DEFAULT '{}'::jsonb,
    processed boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.feedback_entries OWNER TO postgres;

--
-- Name: goals; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.goals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    goal_id character varying(255) NOT NULL,
    agent_id uuid,
    agent_did character varying(255) NOT NULL,
    goal_text text NOT NULL,
    goal_type character varying(50) DEFAULT 'compound'::character varying,
    status character varying(50) DEFAULT 'pending'::character varying,
    constraints_max_token_budget integer,
    constraints_max_execution_time_sec integer,
    constraints_max_parallelism integer DEFAULT 10,
    constraints_deadline_unix_ms bigint,
    constraints_priority integer DEFAULT 5,
    constraints_require_approval boolean DEFAULT false,
    constraints_allowed_agent_types text[],
    constraints_forbidden_tools text[],
    constraints_cost_limit_usd numeric(10,2),
    metadata jsonb DEFAULT '{}'::jsonb,
    parent_goal_id character varying(255),
    decomposition_strategy character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.goals OWNER TO postgres;

--
-- Name: metrics; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    metric_name character varying(255) NOT NULL,
    metric_type character varying(50) DEFAULT 'gauge'::character varying,
    value numeric(20,6) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    labels jsonb DEFAULT '{}'::jsonb,
    agent_id uuid,
    tenant_id character varying(255),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.metrics OWNER TO postgres;

--
-- Name: model_usage; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.model_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    request_id character varying(255) NOT NULL,
    agent_id uuid,
    agent_did character varying(255),
    tenant_id character varying(255),
    session_id character varying(255),
    model_provider character varying(100) NOT NULL,
    model_name character varying(255) NOT NULL,
    model_id character varying(255),
    input_tokens integer DEFAULT 0,
    output_tokens integer DEFAULT 0,
    cached_tokens integer DEFAULT 0,
    total_tokens integer DEFAULT 0,
    latency_ms integer,
    cached boolean DEFAULT false,
    cost_estimate numeric(10,6),
    cost_input_cents numeric(10,6),
    cost_output_cents numeric(10,6),
    cost_cached_cents numeric(10,6),
    finish_reason character varying(50),
    error_message text,
    response_status character varying(50) DEFAULT 'success'::character varying,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.model_usage OWNER TO postgres;

--
-- Name: plans; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    plan_id character varying(255) NOT NULL,
    goal_id character varying(255) NOT NULL,
    agent_id uuid,
    tasks jsonb DEFAULT '[]'::jsonb,
    dependency_graph jsonb DEFAULT '{}'::jsonb,
    status character varying(50) DEFAULT 'draft'::character varying,
    resource_budget jsonb,
    created_at timestamp without time zone DEFAULT now(),
    validated_at timestamp without time zone,
    execution_started_at timestamp without time zone,
    execution_completed_at timestamp without time zone,
    signature character varying(255),
    decomposition_strategy character varying(50) DEFAULT 'hybrid'::character varying,
    decomposition_latency_ms numeric(10,2),
    cache_hit boolean DEFAULT false,
    llm_provider character varying(100),
    llm_model character varying(255),
    total_tokens_used integer DEFAULT 0,
    validation_time_ms numeric(10,2),
    execution_time_ms numeric(10,2),
    parallelism_achieved integer DEFAULT 1,
    tags text[],
    metadata jsonb DEFAULT '{}'::jsonb,
    error text,
    completed_task_count integer DEFAULT 0,
    failed_task_count integer DEFAULT 0
);


ALTER TABLE mcp_documents.plans OWNER TO postgres;

--
-- Name: provenance; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.provenance (
    id character varying(128) NOT NULL,
    document_id character varying(128) NOT NULL,
    event_type character varying(64) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    "timestamp" timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.provenance OWNER TO postgres;

--
-- Name: quality_scores; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.quality_scores (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    score_id character varying(255) NOT NULL,
    agent_id uuid,
    agent_did character varying(255),
    tenant_id character varying(255),
    "timestamp" timestamp without time zone NOT NULL,
    overall_score numeric(5,4) NOT NULL,
    assessment character varying(50) NOT NULL,
    data_completeness numeric(5,4) DEFAULT 1.0,
    cached boolean DEFAULT false,
    dimensions jsonb DEFAULT '{}'::jsonb,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.quality_scores OWNER TO postgres;

--
-- Name: rate_limit_events; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.rate_limit_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    consumer_id character varying(255) NOT NULL,
    tenant_id character varying(255),
    rate_limit_tier character varying(50) NOT NULL,
    endpoint character varying(1000),
    tokens_requested integer DEFAULT 1,
    tokens_remaining integer NOT NULL,
    tokens_limit integer NOT NULL,
    window_start timestamp without time zone NOT NULL,
    window_end timestamp without time zone NOT NULL,
    exceeded boolean DEFAULT false,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.rate_limit_events OWNER TO postgres;

--
-- Name: saga_executions; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.saga_executions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    saga_id character varying(255) NOT NULL,
    saga_name character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'running'::character varying,
    started_at timestamp without time zone NOT NULL,
    completed_at timestamp without time zone,
    steps_total integer NOT NULL,
    steps_completed integer DEFAULT 0,
    steps_failed integer DEFAULT 0,
    current_step character varying(255),
    context jsonb DEFAULT '{}'::jsonb,
    compensation_mode boolean DEFAULT false,
    error_message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.saga_executions OWNER TO postgres;

--
-- Name: saga_steps; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.saga_steps (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    step_id character varying(255) NOT NULL,
    saga_id character varying(255) NOT NULL,
    step_name character varying(255) NOT NULL,
    step_index integer NOT NULL,
    service_id character varying(255) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    request jsonb DEFAULT '{}'::jsonb,
    response jsonb,
    error_message text,
    compensation_executed boolean DEFAULT false,
    compensation_result jsonb,
    retry_count integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.saga_steps OWNER TO postgres;

--
-- Name: service_registry_events; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.service_registry_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    service_id character varying(255) NOT NULL,
    event_type character varying(50) NOT NULL,
    layer character varying(50),
    host character varying(255),
    port integer,
    health_status character varying(50),
    capabilities text[] DEFAULT '{}'::text[],
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.service_registry_events OWNER TO postgres;

--
-- Name: sessions; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.sessions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_id uuid,
    session_type character varying(100) DEFAULT 'conversation'::character varying,
    status character varying(50) DEFAULT 'active'::character varying,
    context jsonb DEFAULT '{}'::jsonb,
    checkpoint jsonb,
    runtime_backend character varying(50),
    runtime_metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.sessions OWNER TO postgres;

--
-- Name: supersessions; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.supersessions (
    id integer NOT NULL,
    old_document_id character varying(128) NOT NULL,
    new_document_id character varying(128) NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE mcp_documents.supersessions OWNER TO postgres;

--
-- Name: supersessions_id_seq; Type: SEQUENCE; Schema: mcp_documents; Owner: postgres
--

CREATE SEQUENCE mcp_documents.supersessions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE mcp_documents.supersessions_id_seq OWNER TO postgres;

--
-- Name: supersessions_id_seq; Type: SEQUENCE OWNED BY; Schema: mcp_documents; Owner: postgres
--

ALTER SEQUENCE mcp_documents.supersessions_id_seq OWNED BY mcp_documents.supersessions.id;


--
-- Name: tasks; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id character varying(255) NOT NULL,
    plan_id character varying(255) NOT NULL,
    agent_id uuid,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    task_type character varying(50) DEFAULT 'atomic'::character varying,
    status character varying(50) DEFAULT 'pending'::character varying,
    dependencies jsonb DEFAULT '[]'::jsonb,
    inputs jsonb DEFAULT '{}'::jsonb,
    outputs jsonb DEFAULT '{}'::jsonb,
    assigned_agent character varying(255),
    timeout_seconds integer DEFAULT 300,
    retry_policy jsonb,
    retry_count integer DEFAULT 0,
    tool_name character varying(255),
    llm_prompt text,
    metadata jsonb DEFAULT '{}'::jsonb,
    error text,
    created_at timestamp without time zone DEFAULT now(),
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE mcp_documents.tasks OWNER TO postgres;

--
-- Name: tool_definitions; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.tool_definitions (
    tool_id character varying(255) NOT NULL,
    tool_name character varying(255) NOT NULL,
    description text NOT NULL,
    category character varying(100) NOT NULL,
    tags text[],
    latest_version character varying(50) NOT NULL,
    source_type character varying(50) NOT NULL,
    source_metadata jsonb,
    deprecation_state character varying(20) DEFAULT 'active'::character varying,
    deprecation_date timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    requires_approval boolean DEFAULT false,
    default_timeout_seconds integer DEFAULT 30,
    default_cpu_millicore_limit integer DEFAULT 500,
    default_memory_mb_limit integer DEFAULT 1024,
    required_permissions jsonb,
    result_schema jsonb,
    retry_policy jsonb,
    circuit_breaker_config jsonb,
    description_embedding public.vector(768)
);


ALTER TABLE mcp_documents.tool_definitions OWNER TO postgres;

--
-- Name: tool_executions; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.tool_executions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invocation_id uuid NOT NULL,
    tool_id uuid,
    tool_name character varying(255) NOT NULL,
    tool_version character varying(50),
    agent_id uuid,
    agent_did character varying(255),
    tenant_id character varying(255),
    session_id character varying(255),
    parent_sandbox_id character varying(255),
    input_params jsonb NOT NULL,
    output_result jsonb,
    status character varying(50) DEFAULT 'pending'::character varying,
    error_code character varying(100),
    error_message text,
    error_details jsonb,
    retryable boolean DEFAULT false,
    duration_ms integer,
    cpu_used_millicore_seconds integer,
    memory_peak_mb integer,
    network_bytes_sent integer,
    network_bytes_received integer,
    documents_accessed jsonb DEFAULT '[]'::jsonb,
    checkpoints_created jsonb DEFAULT '[]'::jsonb,
    checkpoint_ref character varying(255),
    async_mode boolean DEFAULT false,
    priority integer DEFAULT 5,
    idempotency_key character varying(255),
    require_approval boolean DEFAULT false,
    cpu_millicore_limit integer,
    memory_mb_limit integer,
    timeout_seconds integer,
    created_at timestamp without time zone DEFAULT now(),
    started_at timestamp without time zone,
    completed_at timestamp without time zone
);


ALTER TABLE mcp_documents.tool_executions OWNER TO postgres;

--
-- Name: tool_invocations; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.tool_invocations (
    id integer NOT NULL,
    invocation_id character varying(255) NOT NULL,
    tool_id character varying(255) NOT NULL,
    tool_version character varying(50) NOT NULL,
    agent_did character varying(255) NOT NULL,
    tenant_id character varying(255) NOT NULL,
    session_id character varying(255),
    parameters json NOT NULL,
    result json,
    error json,
    status character varying(50) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    duration_ms integer,
    resource_usage json,
    documents_accessed json,
    checkpoints_created integer NOT NULL
);


ALTER TABLE mcp_documents.tool_invocations OWNER TO postgres;

--
-- Name: tool_invocations_id_seq; Type: SEQUENCE; Schema: mcp_documents; Owner: postgres
--

CREATE SEQUENCE mcp_documents.tool_invocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE mcp_documents.tool_invocations_id_seq OWNER TO postgres;

--
-- Name: tool_invocations_id_seq; Type: SEQUENCE OWNED BY; Schema: mcp_documents; Owner: postgres
--

ALTER SEQUENCE mcp_documents.tool_invocations_id_seq OWNED BY mcp_documents.tool_invocations.id;


--
-- Name: tool_versions; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.tool_versions (
    version_id uuid DEFAULT gen_random_uuid() NOT NULL,
    tool_id character varying(255),
    version character varying(50) NOT NULL,
    manifest jsonb NOT NULL,
    compatibility_range character varying(100),
    release_notes text,
    deprecated_in_favor_of character varying(50),
    created_at timestamp without time zone DEFAULT now(),
    removed_at timestamp without time zone
);


ALTER TABLE mcp_documents.tool_versions OWNER TO postgres;

--
-- Name: tools; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.tools (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    tool_type character varying(100) DEFAULT 'function'::character varying,
    schema_def jsonb NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    enabled boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.tools OWNER TO postgres;

--
-- Name: training_examples; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.training_examples (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    execution_id character varying(255),
    task_id character varying(255),
    agent_id uuid,
    source_type character varying(100) DEFAULT 'execution_trace'::character varying,
    source_trace_hash character varying(255),
    input_text text NOT NULL,
    input_structured jsonb DEFAULT '{}'::jsonb,
    output_text text DEFAULT ''::text,
    expected_actions jsonb DEFAULT '[]'::jsonb,
    final_answer text DEFAULT ''::text,
    quality_score numeric(5,2) DEFAULT 0.0,
    confidence numeric(5,4) DEFAULT 0.0,
    labels text[] DEFAULT '{}'::text[],
    domain character varying(100) DEFAULT 'general'::character varying,
    task_type character varying(100) DEFAULT 'single_step'::character varying,
    difficulty numeric(5,4) DEFAULT 0.5,
    metadata jsonb DEFAULT '{}'::jsonb,
    extracted_by character varying(255) DEFAULT 'L07 TrainingDataExtractor'::character varying,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.training_examples OWNER TO postgres;

--
-- Name: user_interactions; Type: TABLE; Schema: mcp_documents; Owner: postgres
--

CREATE TABLE mcp_documents.user_interactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    interaction_id character varying(255) NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    user_id character varying(255),
    interaction_type character varying(100) NOT NULL,
    target_type character varying(100),
    target_id character varying(255),
    action character varying(100) NOT NULL,
    parameters jsonb DEFAULT '{}'::jsonb,
    result character varying(50),
    error_message text,
    client_ip character varying(45),
    user_agent text,
    session_id character varying(255),
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE mcp_documents.user_interactions OWNER TO postgres;

--
-- Name: snapshots; Type: TABLE; Schema: shared; Owner: postgres
--

CREATE TABLE shared.snapshots (
    id bigint NOT NULL,
    snapshot_id uuid DEFAULT gen_random_uuid() NOT NULL,
    aggregate_type character varying(64) NOT NULL,
    aggregate_id character varying(128) NOT NULL,
    version integer NOT NULL,
    state jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE shared.snapshots OWNER TO postgres;

--
-- Name: snapshots_id_seq; Type: SEQUENCE; Schema: shared; Owner: postgres
--

CREATE SEQUENCE shared.snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE shared.snapshots_id_seq OWNER TO postgres;

--
-- Name: snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: shared; Owner: postgres
--

ALTER SEQUENCE shared.snapshots_id_seq OWNED BY shared.snapshots.id;


--
-- Name: supersessions id; Type: DEFAULT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.supersessions ALTER COLUMN id SET DEFAULT nextval('mcp_documents.supersessions_id_seq'::regclass);


--
-- Name: tool_invocations id; Type: DEFAULT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_invocations ALTER COLUMN id SET DEFAULT nextval('mcp_documents.tool_invocations_id_seq'::regclass);


--
-- Name: snapshots id; Type: DEFAULT; Schema: shared; Owner: postgres
--

ALTER TABLE ONLY shared.snapshots ALTER COLUMN id SET DEFAULT nextval('shared.snapshots_id_seq'::regclass);


--
-- Data for Name: agent_state; Type: TABLE DATA; Schema: l02_runtime; Owner: postgres
--

COPY l02_runtime.agent_state (agent_id, session_id, state, context, last_updated, metadata) FROM stdin;
test_agent_002	test_session_002	pending	{"agent": "test", "ready": true}	2026-01-15 00:21:54.569841+00	{"version": "1.0"}
\.


--
-- Data for Name: checkpoints; Type: TABLE DATA; Schema: l02_runtime; Owner: postgres
--

COPY l02_runtime.checkpoints (checkpoint_id, agent_id, session_id, state, context_data, metadata, created_at, size_bytes, compressed) FROM stdin;
ckpt_test_agent_001_1768436514.553681	test_agent_001	test_session_001	running	\\x1f8b08002233686902ffab562a492d2e51b252504a492c4954d251502a4b2d2acecccf030a19d602008bf67f361e000000	{"test": "checkpoint"}	2026-01-15 00:21:54.548438+00	49	t
\.


--
-- Data for Name: active_sessions; Type: TABLE DATA; Schema: mcp_contexts; Owner: postgres
--

COPY mcp_contexts.active_sessions (id, session_id, task_id, status, started_at, last_heartbeat, ended_at, context_snapshot, recovery_needed, recovery_type, conversation_summary, unsaved_changes, project_dir, git_branch) FROM stdin;
\.


--
-- Data for Name: checkpoints; Type: TABLE DATA; Schema: mcp_contexts; Owner: postgres
--

COPY mcp_contexts.checkpoints (id, checkpoint_id, label, description, checkpoint_type, task_id, scope, included_tasks, snapshot, es_memory_id, created_by, session_id, created_at) FROM stdin;
22ef7eab-d49a-498e-a23f-289da848007c	cp-1768409346686-e1780d03	integration-test-checkpoint	Checkpoint for integration testing	manual	test-task-001	task	["test-task-001"]	{"tasks": {"test-task-001": {"name": "Integration Test Task", "status": "in_progress", "taskId": "test-task-001", "version": 2, "keyFiles": [], "iteration": 0, "resumePrompt": "Continue integration testing", "lockedElements": [], "immediateContext": {"blockers": [], "nextStep": "Verify save works", "workingOn": "Running integration tests", "lastAction": "Seeded database"}, "technicalDecisions": []}}, "global": {"keyPaths": {"contexts": ".claude/contexts/", "electricity": "src/components/electricity/ortho/"}, "services": {"redis": "localhost:6379", "ollama": "localhost:11434", "postgres": "localhost:5432"}, "hardRules": ["Canvas 2D is DEPRECATED - use ElectricityOrtho only", "Animation timing via React Spring"], "techStack": ["React 19", "Three.js", "PostgreSQL", "Redis"], "activeTaskId": "test-e2e-task"}, "createdAt": "2026-01-14T16:49:06.687Z", "projectId": "agentic-platform"}	\N	\N	\N	2026-01-14 16:49:06.691426+00
00baee3f-f9a2-418c-8607-4f1e9b1221a9	cp-1768410097382-6f663f7c	integration-test-full	Full integration test checkpoint	manual	test-task-001	task	["test-task-001"]	{"tasks": {"test-task-001": {"name": "Integration Test Task", "status": "in_progress", "taskId": "test-task-001", "version": 4, "keyFiles": [], "iteration": 0, "resumePrompt": "Continue integration testing", "lockedElements": [], "immediateContext": {"blockers": [], "nextStep": "Verify save works", "workingOn": "Full integration test", "lastAction": "Running test suite"}, "technicalDecisions": []}}, "global": {"keyPaths": {"contexts": ".claude/contexts/", "electricity": "src/components/electricity/ortho/"}, "services": {"redis": "localhost:6379", "ollama": "localhost:11434", "postgres": "localhost:5432"}, "hardRules": ["Canvas 2D is DEPRECATED - use ElectricityOrtho only", "Animation timing via React Spring"], "techStack": ["React 19", "Three.js", "PostgreSQL", "Redis"], "activeTaskId": "test-task-integration"}, "createdAt": "2026-01-14T17:01:37.382Z", "projectId": "agentic-platform"}	\N	\N	\N	2026-01-14 17:01:37.384926+00
034cab85-ad49-4279-bf97-eb00d9c9f9bb	cp-1768410727613-e2573419	Phase 16 Tool Test	Checkpoint created during integration testing	manual	test-task-integration	task	["test-task-integration"]	{"tasks": {"test-task-integration": {"name": "L01 Integration Task", "status": "pending", "taskId": "test-task-integration", "version": 1, "keyFiles": [], "iteration": 0, "resumePrompt": "Start L01 service tests", "lockedElements": [], "immediateContext": {"blockers": [], "nextStep": "Begin testing", "workingOn": null, "lastAction": null}, "technicalDecisions": []}}, "global": {"keyPaths": {"contexts": ".claude/contexts/", "electricity": "src/components/electricity/ortho/"}, "services": {"redis": "localhost:6379", "ollama": "localhost:11434", "postgres": "localhost:5432"}, "hardRules": ["Canvas 2D is DEPRECATED - use ElectricityOrtho only", "Animation timing via React Spring"], "techStack": ["React 19", "Three.js", "PostgreSQL", "Redis"], "activeTaskId": "test-task-integration"}, "createdAt": "2026-01-14T17:12:07.613Z", "projectId": "agentic-platform"}	\N	\N	\N	2026-01-14 17:12:07.61692+00
\.


--
-- Data for Name: context_conflicts; Type: TABLE DATA; Schema: mcp_contexts; Owner: postgres
--

COPY mcp_contexts.context_conflicts (id, task_a_id, task_b_id, conflict_type, description, severity, strength, evidence, resolution_status, resolution, resolved_by, detected_at, resolved_at, detected_by, detection_method) FROM stdin;
\.


--
-- Data for Name: context_versions; Type: TABLE DATA; Schema: mcp_contexts; Owner: postgres
--

COPY mcp_contexts.context_versions (id, task_id, version, snapshot, change_summary, change_type, created_by, session_id, created_at) FROM stdin;
f8e03e2a-0c33-489e-8723-52fe3987ac0d	test-task-001	2	{"id": "ff274a10-ab7f-49d2-b0f1-9fa2bbf01bdc", "name": "Integration Test Task", "score": null, "status": "in_progress", "task_id": "test-task-001", "version": 2, "keywords": [], "priority": 50, "iteration": 0, "key_files": [], "agent_type": null, "created_at": "2026-01-14T16:48:32.648169+00:00", "updated_at": "2026-01-14T16:48:51.981912+00:00", "description": "Test task for MCP integration testing", "current_phase": null, "resume_prompt": "Continue integration testing", "token_estimate": null, "last_session_at": "2026-01-14T16:48:51.981912+00:00", "locked_elements": [], "immediate_context": {"blockers": [], "nextStep": "Verify save works", "workingOn": "Running integration tests", "lastAction": "Seeded database"}, "technical_decisions": []}	Auto-saved on significant state change	auto_save	\N	\N	2026-01-14 16:48:51.981912+00
6dd56130-281c-4713-866c-c1f6aec8f942	test-task-001	3	{"id": "ff274a10-ab7f-49d2-b0f1-9fa2bbf01bdc", "name": "Integration Test Task", "score": null, "status": "in_progress", "task_id": "test-task-001", "version": 3, "keywords": [], "priority": 50, "iteration": 0, "key_files": [], "agent_type": null, "created_at": "2026-01-14T16:48:32.648169+00:00", "updated_at": "2026-01-14T16:49:08.556187+00:00", "description": "Test task for MCP integration testing", "current_phase": null, "resume_prompt": "Continue integration testing", "token_estimate": null, "last_session_at": "2026-01-14T16:49:08.556187+00:00", "locked_elements": [], "immediate_context": {"blockers": [], "nextStep": "Verify save works", "workingOn": "Completed test cycle", "lastAction": "Ran all tests"}, "technical_decisions": []}	Auto-saved on significant state change	auto_save	\N	\N	2026-01-14 16:49:08.556187+00
1b3b58ed-8063-4778-a289-622d1ee37948	test-task-001	4	{"id": "ff274a10-ab7f-49d2-b0f1-9fa2bbf01bdc", "name": "Integration Test Task", "score": null, "status": "in_progress", "task_id": "test-task-001", "version": 4, "keywords": [], "priority": 50, "iteration": 0, "key_files": [], "agent_type": null, "created_at": "2026-01-14T16:48:32.648169+00:00", "updated_at": "2026-01-14T17:01:37.267363+00:00", "description": "Test task for MCP integration testing", "current_phase": null, "resume_prompt": "Continue integration testing", "token_estimate": null, "last_session_at": "2026-01-14T17:01:37.267363+00:00", "locked_elements": [], "immediate_context": {"blockers": [], "nextStep": "Verify save works", "workingOn": "Full integration test", "lastAction": "Running test suite"}, "technical_decisions": []}	Auto-saved on significant state change	auto_save	\N	\N	2026-01-14 17:01:37.267363+00
ec21c8f0-cf7b-422e-b293-b39cc4d93b2b	test-task-integration	2	{"id": "3fb0019e-cfc4-470a-bbab-781d69b0332b", "name": "L01 Integration Task", "score": null, "status": "in_progress", "task_id": "test-task-integration", "version": 2, "keywords": [], "priority": 50, "iteration": 0, "key_files": [], "agent_type": null, "created_at": "2026-01-14T16:48:32.648169+00:00", "updated_at": "2026-01-14T17:12:09.205216+00:00", "description": "Task for L01 service testing", "current_phase": null, "resume_prompt": "Start L01 service tests", "token_estimate": null, "last_session_at": "2026-01-14T17:12:09.205216+00:00", "locked_elements": [], "immediate_context": {"blockers": [], "nextStep": "Test remaining tools", "workingOn": "Phase 16 tool testing", "lastAction": "Ran create_checkpoint test"}, "technical_decisions": []}	Auto-saved on significant state change	auto_save	\N	\N	2026-01-14 17:12:09.205216+00
5ebe48f2-b28c-4d1e-b688-981d51cf70b8	test-task-integration	3	{"id": "3fb0019e-cfc4-470a-bbab-781d69b0332b", "name": "L01 Integration Task", "score": null, "status": "pending", "task_id": "test-task-integration", "version": 3, "keywords": [], "priority": 50, "iteration": 0, "key_files": [], "agent_type": null, "created_at": "2026-01-14T16:48:32.648169+00:00", "updated_at": "2026-01-14T17:13:06.980902+00:00", "description": "Task for L01 service testing", "current_phase": null, "resume_prompt": "Start L01 service tests", "token_estimate": null, "last_session_at": "2026-01-14T17:13:06.980902+00:00", "locked_elements": [], "immediate_context": {"blockers": [], "nextStep": "Begin testing", "workingOn": null, "lastAction": null}, "technical_decisions": []}	Auto-saved on significant state change	auto_save	\N	\N	2026-01-14 17:13:06.980902+00
00a53acb-824c-467a-b396-d55897babc3d	test-task-integration	4	{"id": "3fb0019e-cfc4-470a-bbab-781d69b0332b", "name": "L01 Integration Task", "score": null, "status": "in_progress", "task_id": "test-task-integration", "version": 4, "keywords": [], "priority": 50, "iteration": 0, "key_files": [], "agent_type": null, "created_at": "2026-01-14T16:48:32.648169+00:00", "updated_at": "2026-01-14T17:32:39.295157+00:00", "description": "Task for L01 service testing", "current_phase": null, "resume_prompt": "Start L01 service tests", "token_estimate": null, "last_session_at": "2026-01-14T17:32:39.295157+00:00", "locked_elements": [], "immediate_context": {"blockers": [], "nextStep": "Begin testing", "workingOn": "Python integration test", "lastAction": "Testing save_context_checkpoint"}, "technical_decisions": []}	Auto-saved on significant state change	auto_save	\N	\N	2026-01-14 17:32:39.295157+00
\.


--
-- Data for Name: global_context; Type: TABLE DATA; Schema: mcp_contexts; Owner: postgres
--

COPY mcp_contexts.global_context (id, project_id, project_name, description, hard_rules, tech_stack, key_paths, services, active_task_id, orchestrator_context, created_at, updated_at, version) FROM stdin;
20436f92-1bcb-4acd-9d60-3a85aa26c70f	agentic-platform	Agentic Platform	Unified agentic platform with MCP services	["Canvas 2D is DEPRECATED - use ElectricityOrtho only", "Animation timing via React Spring"]	["React 19", "Three.js", "PostgreSQL", "Redis"]	{"contexts": ".claude/contexts/", "electricity": "src/components/electricity/ortho/"}	{"redis": "localhost:6379", "ollama": "localhost:11434", "postgres": "localhost:5432"}	test-e2e-task	{}	2026-01-14 15:11:54.861368+00	2026-01-14 22:54:00.511054+00	1
\.


--
-- Data for Name: task_contexts; Type: TABLE DATA; Schema: mcp_contexts; Owner: postgres
--

COPY mcp_contexts.task_contexts (id, task_id, name, description, agent_type, status, priority, current_phase, iteration, score, locked_elements, immediate_context, key_files, technical_decisions, resume_prompt, keywords, token_estimate, created_at, updated_at, last_session_at, version) FROM stdin;
fb6f45d5-4d7e-433c-9a01-f2f3114bd30b	test-task-planning	L05 Planning Task	Task for L05 planning context testing	\N	pending	50	\N	0	\N	[]	{"blockers": [], "nextStep": "Query planning context", "workingOn": null, "lastAction": null}	[]	[]	Start planning context tests	[]	\N	2026-01-14 16:48:32.648169+00	2026-01-14 16:48:32.648169+00	\N	1
ff274a10-ab7f-49d2-b0f1-9fa2bbf01bdc	test-task-001	Integration Test Task	Test task for MCP integration testing	\N	in_progress	50	\N	0	\N	[]	{"blockers": [], "nextStep": "Verify save works", "workingOn": "Full integration test", "lastAction": "Running test suite"}	[]	[]	Continue integration testing	[]	\N	2026-01-14 16:48:32.648169+00	2026-01-14 17:01:37.267363+00	2026-01-14 17:01:37.267363+00	4
3fb0019e-cfc4-470a-bbab-781d69b0332b	test-task-integration	L01 Integration Task	Task for L01 service testing	\N	in_progress	50	\N	0	\N	[]	{"blockers": [], "nextStep": "Begin testing", "workingOn": "Python integration test", "lastAction": "Testing save_context_checkpoint"}	[]	[]	Start L01 service tests	[]	\N	2026-01-14 16:48:32.648169+00	2026-01-14 17:34:12.672913+00	2026-01-14 17:34:12.672913+00	5
\.


--
-- Data for Name: task_relationships; Type: TABLE DATA; Schema: mcp_contexts; Owner: postgres
--

COPY mcp_contexts.task_relationships (id, source_task_id, target_task_id, relationship_type, metadata, strength, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: agents; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.agents (id, did, name, agent_type, status, configuration, metadata, resource_limits, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.alerts (id, alert_id, "timestamp", severity, type, metric, message, channels, delivery_attempts, delivered, last_attempt, agent_id, agent_did, tenant_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: anomalies; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.anomalies (id, anomaly_id, metric_name, severity, baseline_value, current_value, z_score, deviation_percent, confidence, status, detected_at, resolved_at, alert_sent, agent_id, agent_did, tenant_id, created_at) FROM stdin;
\.


--
-- Data for Name: api_requests; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.api_requests (id, request_id, trace_id, span_id, "timestamp", method, path, consumer_id, tenant_id, authenticated, auth_method, status_code, latency_ms, request_size_bytes, response_size_bytes, rate_limit_tier, idempotency_key, idempotent_cache_hit, error_code, error_message, client_ip, user_agent, headers, query_params, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: authentication_events; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.authentication_events (id, event_id, "timestamp", consumer_id, tenant_id, auth_method, success, failure_reason, client_ip, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: circuit_breaker_events; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.circuit_breaker_events (id, event_id, "timestamp", service_id, circuit_name, event_type, state_from, state_to, failure_count, success_count, failure_threshold, timeout_seconds, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: claims; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.claims (id, document_id, section_id, subject, predicate, object, qualifier, confidence, original_text, claim_type, deprecated, deprecated_at, source_document_id, embedding, created_at) FROM stdin;
e17c0c84-0c50-4ef0-b7ea-bd3f7b5586a5	eb97556c-8fd9-4483-acb1-fcea72679609	fa5a4e15-4383-4692-a3ad-6ad95657797c	tokens	expire after	24 hours	\N	0.8	All tokens expire after 24 hours.	factual	f	\N	\N	\N	2026-01-14 17:55:58.558596+00
bd088427-25d9-4f28-9e03-925ab8abbe26	eb97556c-8fd9-4483-acb1-fcea72679609	fa5a4e15-4383-4692-a3ad-6ad95657797c	users	must refresh token	before expiration	\N	0.8	Users must refresh their tokens before expiration to maintain access.	factual	f	\N	\N	\N	2026-01-14 17:55:58.570337+00
9fb7f973-255b-43af-a072-74f59fa42772	eb97556c-8fd9-4483-acb1-fcea72679609	fa5a4e15-4383-4692-a3ad-6ad95657797c	passwords	must have minimum length	12 characters	\N	0.8	Passwords must be at least 12 characters.	factual	f	\N	\N	\N	2026-01-14 17:55:58.573904+00
07b44c0a-a08b-479a-a9e5-5ffccc2fa75c	eb97556c-8fd9-4483-acb1-fcea72679609	fa5a4e15-4383-4692-a3ad-6ad95657797c	login attempts	are limited to	5 per hour	\N	0.8	Failed login attempts are limited to 5 per hour.	factual	f	\N	\N	\N	2026-01-14 17:55:58.576831+00
f66f2284-861e-4087-8538-54ba31010f32	eb97556c-8fd9-4483-acb1-fcea72679609	fa5a4e15-4383-4692-a3ad-6ad95657797c	admin accounts	require two-factor auth		\N	0.8	Two-factor authentication is mandatory for admin accounts.	factual	f	\N	\N	\N	2026-01-14 17:55:58.581664+00
ed5b1b1c-04be-4f98-9fe6-071fb818ccdb	eb97556c-8fd9-4483-acb1-fcea72679609	fa5a4e15-4383-4692-a3ad-6ad95657797c	users	are limited to	100 requests per minute	\N	0.8	The API enforces rate limiting of 100 requests per minute per user.	factual	f	\N	\N	\N	2026-01-14 17:55:58.584663+00
39731028-6e18-4c7f-81c9-8b85d470e65b	eb97556c-8fd9-4483-acb1-fcea72679609	fa5a4e15-4383-4692-a3ad-6ad95657797c		results in	429 status code	\N	0.8	Exceeding this limit results in a 429 status code.	factual	f	\N	\N	\N	2026-01-14 17:55:58.587327+00
80040ab4-8afc-4db6-8707-d9170a8d5141	5941db0b-8fbf-44c8-ac52-5ac688ac8422	30f69bc7-041f-49c3-b85a-35da3368d4c5	platform	uses	PostgreSQL 15	\N	0.8	The platform uses PostgreSQL 15 as the primary database.	factual	f	\N	\N	\N	2026-01-14 17:58:47.310016+00
f084fbd6-6119-49c5-9d44-5926ef4ec629	5941db0b-8fbf-44c8-ac52-5ac688ac8422	30f69bc7-041f-49c3-b85a-35da3368d4c5	Redis	provides	caching with a 1-hour TTL	\N	0.8	Redis provides caching with a 1-hour TTL.	factual	f	\N	\N	\N	2026-01-14 17:58:47.31664+00
74c03c38-f360-4dc3-adf2-ab8ae293905c	5941db0b-8fbf-44c8-ac52-5ac688ac8422	30f69bc7-041f-49c3-b85a-35da3368d4c5	API responses	must complete	within 500ms	\N	0.8	All API responses must complete within 500ms.	factual	f	\N	\N	\N	2026-01-14 17:58:47.319775+00
109fdd46-3350-49ae-9d92-5b4acfb9c21a	5941db0b-8fbf-44c8-ac52-5ac688ac8422	30f69bc7-041f-49c3-b85a-35da3368d4c5	semantic search	will use	pgvector	\N	0.8	We will use pgvector for semantic search instead of Elasticsearch.	factual	f	\N	\N	\N	2026-01-14 17:58:47.322351+00
4ad8f864-fa04-4eaa-8334-cb5ba68deafa	5941db0b-8fbf-44c8-ac52-5ac688ac8422	30f69bc7-041f-49c3-b85a-35da3368d4c5	embedding dimension	is	384	\N	0.8	The embedding dimension is 384.	factual	f	\N	\N	\N	2026-01-14 17:58:47.325282+00
6203f90e-f37a-43d8-8422-dea538a769fa	cdf3dfed-eb8c-4b07-b9f8-255ecd10e0dd	e8416ffe-a993-47e2-b1a7-48b7ffe11ad6	platform	uses	PostgreSQL 15	\N	0.8	The platform uses PostgreSQL 15 as the primary database.	factual	f	\N	\N	\N	2026-01-14 18:01:21.089922+00
d143088e-5c5a-4f26-a755-f81275b1f6ab	cdf3dfed-eb8c-4b07-b9f8-255ecd10e0dd	e8416ffe-a993-47e2-b1a7-48b7ffe11ad6	Redis	provides	caching with 1 hour TTL	\N	0.8	Redis provides caching with a 1-hour TTL.	factual	f	\N	\N	\N	2026-01-14 18:01:21.096911+00
e34ff21a-8ce9-48fb-8a95-5b460dd3d7c3	cdf3dfed-eb8c-4b07-b9f8-255ecd10e0dd	e8416ffe-a993-47e2-b1a7-48b7ffe11ad6	API responses	must complete within	500ms	\N	0.8	All API responses must complete within 500ms.	factual	f	\N	\N	\N	2026-01-14 18:01:21.100278+00
abfc0611-6195-4c52-883c-a78c8678602c	cdf3dfed-eb8c-4b07-b9f8-255ecd10e0dd	e8416ffe-a993-47e2-b1a7-48b7ffe11ad6	semantic search	will use	pgvector	\N	0.8	We will use pgvector for semantic search instead of Elasticsearch.	factual	f	\N	\N	\N	2026-01-14 18:01:21.103263+00
ec7a2cf3-f69d-41cc-9b87-83b097bc4d91	cdf3dfed-eb8c-4b07-b9f8-255ecd10e0dd	e8416ffe-a993-47e2-b1a7-48b7ffe11ad6	embedding dimension	is	384	\N	0.8	The embedding dimension is 384.	factual	f	\N	\N	\N	2026-01-14 18:01:21.106803+00
a69f0997-304d-4792-81e5-fc3143594e59	74127424-1760-47e1-9899-e85a540de669	84cb55c2-c7de-4761-a041-7186719fd6fc	platform	uses	PostgreSQL 14	\N	0.8	The platform uses PostgreSQL 14 as the primary database.	factual	f	\N	\N	\N	2026-01-14 18:02:41.879339+00
1edaf5e0-cbd1-41a7-9d99-13e2dab09e90	74127424-1760-47e1-9899-e85a540de669	84cb55c2-c7de-4761-a041-7186719fd6fc	Elasticsearch	provides	semantic search capabilities	\N	0.8	Elasticsearch provides semantic search capabilities.	factual	f	\N	\N	\N	2026-01-14 18:02:41.884699+00
fe1c38ca-eb67-47d5-82e9-1a1fce3611fa	74127424-1760-47e1-9899-e85a540de669	84cb55c2-c7de-4761-a041-7186719fd6fc	embedding dimension	is	768	\N	0.8	The embedding dimension is 768.	factual	f	\N	\N	\N	2026-01-14 18:02:41.886991+00
cd8a2662-3404-4978-a24a-54f81d72b4f0	74127424-1760-47e1-9899-e85a540de669	84cb55c2-c7de-4761-a041-7186719fd6fc	API response	must complete	within 200ms	\N	0.8	All API responses must complete within 200ms.	factual	f	\N	\N	\N	2026-01-14 18:02:41.890138+00
fde8fdc6-d93a-49fd-b81f-e38f37b7be8f	2fa32237-731b-4393-9a06-b914b012db84	dec67824-6f3a-46fe-8c35-c9f31a81f7aa	platform	uses	PostgreSQL 15	\N	0.8	The platform uses PostgreSQL 15 as the primary database.	factual	f	\N	\N	\N	2026-01-14 18:11:24.297876+00
df81c153-7af7-46f7-8d95-e6ac9b600b4c	2fa32237-731b-4393-9a06-b914b012db84	dec67824-6f3a-46fe-8c35-c9f31a81f7aa	Redis	provides	caching with 1 hour TTL	\N	0.8	Redis provides caching with a 1-hour TTL.	factual	f	\N	\N	\N	2026-01-14 18:11:24.332107+00
24e46799-0424-4f38-b264-6467cc3fe3fd	2fa32237-731b-4393-9a06-b914b012db84	dec67824-6f3a-46fe-8c35-c9f31a81f7aa	API responses	must complete	within 500ms	\N	0.8	All API responses must complete within 500ms.	factual	f	\N	\N	\N	2026-01-14 18:11:24.339164+00
c4c3aa7b-be23-416a-94bd-10e00af96acf	2fa32237-731b-4393-9a06-b914b012db84	dec67824-6f3a-46fe-8c35-c9f31a81f7aa	semantic search	will use	pgvector	\N	0.8	We will use pgvector for semantic search instead of Elasticsearch.	factual	f	\N	\N	\N	2026-01-14 18:11:24.345007+00
0a43969c-8f3c-4571-ac71-c4a774852018	2fa32237-731b-4393-9a06-b914b012db84	dec67824-6f3a-46fe-8c35-c9f31a81f7aa	embedding dimension	is	384	\N	0.8	The embedding dimension is 384.	factual	f	\N	\N	\N	2026-01-14 18:11:24.349284+00
ddaa9582-aba0-45fb-89a0-76eb5792b931	71704e2b-6e44-4b92-b94f-62657082a2ef	af6e7b9d-aca1-42be-ba86-151e94556ec0	platform	uses database	PostgreSQL 14	\N	0.8	The platform uses PostgreSQL 14 as the primary database.	factual	f	\N	\N	\N	2026-01-14 18:12:37.967917+00
d7dfd7be-8114-485d-82a9-dc21bfa65705	71704e2b-6e44-4b92-b94f-62657082a2ef	af6e7b9d-aca1-42be-ba86-151e94556ec0	Elasticsearch	provides search capabilities		\N	0.8	Elasticsearch provides semantic search capabilities.	factual	f	\N	\N	\N	2026-01-14 18:12:37.974778+00
89dc4836-8a3d-4ba4-9b60-ef356bf406a8	71704e2b-6e44-4b92-b94f-62657082a2ef	af6e7b9d-aca1-42be-ba86-151e94556ec0	embedding dimension	is	768	\N	0.8	The embedding dimension is 768.	factual	f	\N	\N	\N	2026-01-14 18:12:37.979045+00
765124f2-5ae3-494b-bbca-4e173069b746	71704e2b-6e44-4b92-b94f-62657082a2ef	af6e7b9d-aca1-42be-ba86-151e94556ec0	API responses	must complete within time limit	200ms	\N	0.8	All API responses must complete within 200ms.	factual	f	\N	\N	\N	2026-01-14 18:12:37.981415+00
abf66347-1dd7-4dd7-97b8-5a425d0b3df7	555b21c5-e167-4634-8ced-cfe541301183	ae130918-ff8c-4066-8039-796cdbab1eeb	PostgreSQL	is	the database	\N	0.8	PostgreSQL is the database	factual	f	\N	\N	\N	2026-01-14 18:24:25.616734+00
bf4512a2-7a27-4d1b-b71e-9a9a816bf0d3	555b21c5-e167-4634-8ced-cfe541301183	ae130918-ff8c-4066-8039-796cdbab1eeb	Redis	is	the cache	\N	0.8	Redis is the cache	factual	f	\N	\N	\N	2026-01-14 18:24:25.625435+00
162f1a6f-45ea-4450-95b1-01b04810b39b	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	platform	uses database	PostgreSQL 15	\N	0.8	The platform uses PostgreSQL 15 as the primary database for structured data.	factual	f	\N	\N	\N	2026-01-14 18:27:08.387157+00
8426bcf5-e3bd-402f-b28f-50caca3e4746	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	Redis	provides caching	1-hour TTL	\N	0.8	Redis provides caching with a 1-hour TTL for session data.	factual	f	\N	\N	\N	2026-01-14 18:27:08.392996+00
fcb8913e-3bca-41b3-9fd1-2325cef6a125	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	API responses	must complete within time limit	500ms	\N	0.8	All API responses must complete within 500ms for optimal user experience.	factual	f	\N	\N	\N	2026-01-14 18:27:08.39614+00
32bc2ba4-27d6-4e78-8f56-9e549cd131b2	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	PostgreSQL	handles transactions	ACID transactions	\N	0.8	PostgreSQL handles ACID transactions	factual	f	\N	\N	\N	2026-01-14 18:27:08.398883+00
f741f883-df64-4207-9398-bd8aecce5493	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	PostgreSQL	uses connection pooling	PgBouncer	\N	0.8	Connection pooling via PgBouncer	factual	f	\N	\N	\N	2026-01-14 18:27:08.403292+00
a9298969-7609-4282-b008-6fda95424687	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	PostgreSQL	has automatic failover	streaming replication	\N	0.8	Automatic failover with streaming replication	factual	f	\N	\N	\N	2026-01-14 18:27:08.405729+00
b48ce47d-bc65-4add-b662-800f8a60b659	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	Redis	uses cluster	high availability	\N	0.8	Redis cluster for high availability	factual	f	\N	\N	\N	2026-01-14 18:27:08.407736+00
94290922-e8af-47c2-9579-e6784f10f68d	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	Redis	uses write-through cache	user sessions	\N	0.8	Write-through cache for user sessions	factual	f	\N	\N	\N	2026-01-14 18:27:08.409642+00
e72778d7-60c8-414e-bf50-f15597cae870	bb5b5b7d-3921-4036-98b2-a00d334568f5	38bba5ac-9373-430a-945e-2e4c4eb80273	Redis	has cache invalidation	data updates	\N	0.8	Cache invalidation on data updates	factual	f	\N	\N	\N	2026-01-14 18:27:08.412454+00
\.


--
-- Data for Name: compliance_results; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.compliance_results (id, result_id, execution_id, agent_id, agent_did, tenant_id, "timestamp", compliant, violations, constraints_checked, created_at) FROM stdin;
\.


--
-- Data for Name: configurations; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.configurations (id, namespace, key, value, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: conflicts; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.conflicts (id, claim_a_id, claim_b_id, conflict_type, strength, resolution_status, resolution_details, created_at) FROM stdin;
\.


--
-- Data for Name: consolidations; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.consolidations (id, source_document_ids, result_document_id, strategy, conflicts_resolved, conflicts_pending, created_at) FROM stdin;
e5f15f4c-3abe-4f7d-998d-ea7c9e3d7992	{045eab50-7e02-4320-a6f4-34328cb9a22f,32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a}	40f8ef34-7307-4fd9-8741-2652f5e10b88	authority_wins	0	0	2026-01-14 17:04:34.304683+00
414c6eb1-e1f7-4a52-8ab5-610be734663c	{045eab50-7e02-4320-a6f4-34328cb9a22f,32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a}	d68c9fcc-2bf0-4399-af0b-94b87cfe0079	merge_all	0	0	2026-01-14 17:05:16.456418+00
\.


--
-- Data for Name: control_operations; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.control_operations (id, operation_id, "timestamp", user_id, operation_type, target_agent_id, target_agent_did, command, parameters, status, result, error_message, executed_at, completed_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: dataset_examples; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.dataset_examples (id, dataset_id, example_id, split, created_at) FROM stdin;
\.


--
-- Data for Name: datasets; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.datasets (id, name, version, description, tags, split_ratios, lineage, statistics, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document_tags; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.document_tags (document_id, tag) FROM stdin;
9346f52b-5a4e-4289-ad95-b99b5be260f9	test
9346f52b-5a4e-4289-ad95-b99b5be260f9	architecture
9346f52b-5a4e-4289-ad95-b99b5be260f9	mcp
bf1cdfed-8414-467f-b17e-419c62126d61	test
bf1cdfed-8414-467f-b17e-419c62126d61	architecture
bf1cdfed-8414-467f-b17e-419c62126d61	mcp
3a7a2b80-7bb3-497c-b93e-fcda657829b8	test
3a7a2b80-7bb3-497c-b93e-fcda657829b8	architecture
3a7a2b80-7bb3-497c-b93e-fcda657829b8	mcp
184e9500-3652-4baa-8897-678974eceb64	test
184e9500-3652-4baa-8897-678974eceb64	pgvector
184e9500-3652-4baa-8897-678974eceb64	embeddings
3c76eb98-b4d6-4588-b390-e51ab7274862	database
3c76eb98-b4d6-4588-b390-e51ab7274862	postgresql
3c76eb98-b4d6-4588-b390-e51ab7274862	architecture
af43a4f7-967f-45ee-8baa-e7f9ab759984	vectors
af43a4f7-967f-45ee-8baa-e7f9ab759984	pgvector
af43a4f7-967f-45ee-8baa-e7f9ab759984	search
bcc97702-2be6-440b-a10e-6050fb8da050	frontend
bcc97702-2be6-440b-a10e-6050fb8da050	react
bcc97702-2be6-440b-a10e-6050fb8da050	components
ce28fd71-dfb4-4b99-b6aa-4f96265dde29	database
ce28fd71-dfb4-4b99-b6aa-4f96265dde29	postgresql
ce28fd71-dfb4-4b99-b6aa-4f96265dde29	performance
2e560d15-2a8a-45dd-a1e3-23b5b821c13a	test
2e560d15-2a8a-45dd-a1e3-23b5b821c13a	deprecation
045eab50-7e02-4320-a6f4-34328cb9a22f	authentication
045eab50-7e02-4320-a6f4-34328cb9a22f	security
045eab50-7e02-4320-a6f4-34328cb9a22f	api
32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	security
32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	api
32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	authentication
d1aec79c-878f-4ab4-98aa-f53ce6d80178	test
d1aec79c-878f-4ab4-98aa-f53ce6d80178	l02
d1aec79c-878f-4ab4-98aa-f53ce6d80178	runtime
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.documents (id, source_path, content_hash, format, document_type, title, authority_level, raw_content, frontmatter, embedding, created_at, updated_at) FROM stdin;
9346f52b-5a4e-4289-ad95-b99b5be260f9	inline-1768399277985	43dbe828d5919d5149e265ca743a14fad361f86430447e86b703cbd05036f9cc	text	spec	Content	7	# Test Specification Document\n\n## Overview\nThis is a test document for the MCP Document Consolidator.\n\n## Architecture\nThe system uses PostgreSQL with pgvector for embeddings storage.\nRedis is used for caching and session management.\n\n## Key Components\n1. **Embedding Pipeline**: Uses sentence-transformers for generating embeddings\n2. **Claim Extractor**: Extracts factual claims from documents\n3. **Conflict Detector**: Identifies contradictions between documents\n\n## Configuration\n- Database: PostgreSQL 16 with pgvector extension\n- Vector dimensions: 384\n- Similarity threshold: 0.8\n\n## Notes\nThis document was created for testing the ingest_document tool.\n	{}	\N	2026-01-14 14:01:18.000653+00	2026-01-14 14:01:18.000653+00
bf1cdfed-8414-467f-b17e-419c62126d61	inline-1768399321686	43dbe828d5919d5149e265ca743a14fad361f86430447e86b703cbd05036f9cc	text	spec	Content	7	# Test Specification Document\n\n## Overview\nThis is a test document for the MCP Document Consolidator.\n\n## Architecture\nThe system uses PostgreSQL with pgvector for embeddings storage.\nRedis is used for caching and session management.\n\n## Key Components\n1. **Embedding Pipeline**: Uses sentence-transformers for generating embeddings\n2. **Claim Extractor**: Extracts factual claims from documents\n3. **Conflict Detector**: Identifies contradictions between documents\n\n## Configuration\n- Database: PostgreSQL 16 with pgvector extension\n- Vector dimensions: 384\n- Similarity threshold: 0.8\n\n## Notes\nThis document was created for testing the ingest_document tool.\n	{}	\N	2026-01-14 14:02:01.691039+00	2026-01-14 14:02:01.691039+00
3a7a2b80-7bb3-497c-b93e-fcda657829b8	inline-1768399375969	43dbe828d5919d5149e265ca743a14fad361f86430447e86b703cbd05036f9cc	text	spec	Content	7	# Test Specification Document\n\n## Overview\nThis is a test document for the MCP Document Consolidator.\n\n## Architecture\nThe system uses PostgreSQL with pgvector for embeddings storage.\nRedis is used for caching and session management.\n\n## Key Components\n1. **Embedding Pipeline**: Uses sentence-transformers for generating embeddings\n2. **Claim Extractor**: Extracts factual claims from documents\n3. **Conflict Detector**: Identifies contradictions between documents\n\n## Configuration\n- Database: PostgreSQL 16 with pgvector extension\n- Vector dimensions: 384\n- Similarity threshold: 0.8\n\n## Notes\nThis document was created for testing the ingest_document tool.\n	{}	\N	2026-01-14 14:02:55.97373+00	2026-01-14 14:02:55.97373+00
184e9500-3652-4baa-8897-678974eceb64	inline-1768399967101	11e3869aeeee003b5ed07696f875c6612d62f3426432fa83fd34ff9cbaa5b319	text	spec	Content	7	# pgvector Test Document\n\n## Overview\nThis document tests the pgvector embedding pipeline.\n\n## Purpose\nWe are validating that embeddings are generated correctly and stored in PostgreSQL using pgvector.\n\n## Technical Details\n- Vector dimensions: 384\n- Model: all-MiniLM-L6-v2\n- Storage: PostgreSQL with pgvector extension\n	{}	[0.044021618,-0.034307875,0.004164182,0.028646426,-0.004893963,0.066490784,-0.17046177,0.020512525,-0.018573327,-0.027354034,-0.029502515,0.041813407,0.00010644553,-0.05063667,-0.090092376,0.044196367,0.057202183,0.05191621,-0.022910245,0.019769574,-0.06595312,-0.027548932,-0.004933531,-0.016126169,0.0054034446,-0.02450014,-0.06261957,0.025262397,0.027345689,-0.013867222,0.083124354,0.025635792,-0.011451332,0.11339403,-0.005961402,0.08290653,0.032397315,-0.0629881,-0.062208176,-0.0041949945,0.06282287,-0.0006007635,-0.083734155,0.054038808,-0.009660556,-0.059649304,-0.07791371,-0.046375133,-0.09075574,-0.042934,-0.018004213,-0.0047305212,-0.017910725,-0.014884598,-0.099287905,-0.034065176,-0.05583168,-0.05534182,0.07652604,0.03407608,-0.015197323,-0.048439734,0.0900225,-0.01093883,-0.026858969,-0.03356639,-0.004001803,0.0037357507,-0.018062165,-0.022512777,-0.035813164,0.06860972,-0.13566378,0.011328313,-0.042089805,0.030134285,0.046246964,-0.008639419,0.058786973,-0.039143696,-0.0071883774,-0.052373167,-0.034764457,-0.012123723,-0.06728319,0.028635962,0.0039390437,-0.05118056,-0.035811715,-0.016314788,0.044057813,0.019055257,-0.02145806,0.076844916,0.04020726,-0.047192823,0.050670404,0.035614874,0.08272911,-0.04488267,0.056987047,0.0216896,0.07062111,0.031214839,-0.03851618,-0.044179324,-0.020925265,0.0054161493,-0.013742426,-0.056958903,0.026325056,0.054914653,-0.0070660147,-0.008176808,0.05585289,-0.0130213015,-0.062223576,-0.051921573,0.053928994,-0.015794823,0.039110083,0.07408795,0.003481191,0.002522027,-0.04502521,-0.02462877,-0.00044089826,6.569085e-33,-0.018623438,-0.0655839,0.1323039,0.07064226,0.016532186,0.044617154,0.042162344,0.069653004,-0.049851157,0.027215589,-0.100794844,-0.030482478,-0.012363575,0.08503251,0.03681019,0.051871657,-0.03735607,0.002988499,-0.017148085,-0.0035403613,0.04052745,0.012270879,-0.011426864,-0.017636804,-0.026793983,0.022999465,0.04038602,-0.11546146,-0.0596403,0.0020185774,-0.11066956,-0.030843351,0.038310092,0.0778701,0.043797616,0.017511925,0.079233535,0.018660907,-0.14433125,-0.06552443,0.06279344,-0.00342677,-0.005929683,-0.08042003,-0.06501698,0.03188039,0.100861885,-0.025086587,-0.027180854,-0.038723316,0.02699551,0.061986703,-0.04097559,0.0059072976,0.034329847,0.007796662,-0.0029696943,-0.008186454,0.045045827,-0.00209005,-0.022605658,0.044084698,0.0178387,-0.006004943,-0.0381984,-0.025929881,0.007866913,-0.0067481464,0.050933346,0.0796012,0.0044956882,0.071907476,-0.0315103,-0.019251335,0.06317009,-0.036585648,-0.044312626,-0.024006974,0.012335105,0.05109054,-0.018335942,-0.03779686,-0.0014052878,-0.030114954,-0.03968592,-0.11370449,0.0066772136,-0.046452135,-0.008931987,0.04297984,-0.0144715365,0.032781776,-0.010088028,0.046299506,0.07973389,-8.842319e-33,-0.033842288,-0.023701522,-0.05435696,0.079642795,-0.035449937,-0.05401062,0.018532615,0.050506637,-0.06753589,-0.026030459,-0.012091787,-0.019948492,0.07661354,-0.010277126,0.05403985,0.029004049,-0.110940315,-0.09005497,0.018613547,0.020554377,-0.030867117,0.018679067,0.008290949,0.062286995,0.11808627,-0.0054218546,0.07727103,-0.10171498,-0.00027791545,-0.04720853,0.05350037,-0.00695324,-0.030516488,0.056515634,-0.08883581,-0.02913913,-0.016205894,-0.05319195,0.07609248,-0.029235996,-0.0340351,0.09073087,-0.01391196,-0.011753399,0.005760578,0.010256975,0.061382964,-0.026259044,0.09498973,-0.0417242,-0.01971892,-0.02941587,-0.05218271,0.034277953,0.07295942,-0.008971167,-0.09433151,-0.018461162,0.009825576,-0.047011197,-0.0149637675,-0.012588638,-0.016287275,-0.099668734,-0.020914923,-0.0744469,0.051722962,0.036845673,-0.014780534,-0.07655661,0.07428123,0.015812129,-0.00073306053,0.06903209,0.016504304,-0.051098917,0.002162631,0.0678496,0.057439283,-0.0076207127,0.01615707,0.02721551,0.04823479,0.059440035,0.0900292,-0.03872618,0.047491446,0.07116905,-0.08338214,0.0865915,0.020539692,0.06935892,-0.09990408,0.07572184,0.006302698,-4.3263437e-08,-0.06619451,-0.033069856,-0.09000437,-0.038436014,-0.049442284,-0.08310981,0.11566468,0.069554396,-0.014011695,0.058473933,0.000670144,-0.045897536,-0.042877555,0.007023531,0.002021141,-0.060040876,-0.016618667,-0.029569251,0.025035864,0.0017581122,-0.063634455,0.02428854,-0.01666338,0.039877847,-0.03946005,-0.04771046,0.060552686,0.052905682,0.1367553,-0.040339097,-0.003594417,0.04332225,-0.014014118,-0.08435983,0.015903559,0.071768135,0.082584605,0.0020919102,0.03536992,-0.009044961,-0.044086628,-0.06608119,0.02856693,-0.08734692,-0.029160982,-0.0079814475,-0.036351223,0.0029626223,-0.030133573,0.08933831,-0.01995612,-0.077366166,-0.06173174,0.09570158,0.085432455,-0.014948845,-0.020385297,-0.019816484,0.0097639505,-0.10009582,0.019694597,0.06634521,0.046345256,-0.011343128]	2026-01-14 14:12:47.106897+00	2026-01-14 14:12:47.106897+00
3c76eb98-b4d6-4588-b390-e51ab7274862	inline-1768400114859	ff68ddf9c2c1dc831ea971accc4209d323532ac91a474b131b5394e0d9cfa2ee	text	guide	Content	7	# Database Architecture Guide\n\n## Overview\nThis document describes PostgreSQL database architecture best practices.\n\n## Connection Pooling\nUse PgBouncer or built-in connection pooling for optimal performance.\nConfigure max_connections based on available memory.\n\n## Indexing Strategy\nCreate B-tree indexes for equality and range queries.\nUse GIN indexes for full-text search and JSONB columns.\nConsider partial indexes for frequently filtered subsets.	{}	[0.037663963,0.016162347,-0.048098125,0.022914331,-0.14000155,0.044706143,0.015760949,-0.012933741,-0.051111042,-0.03757773,-0.07450653,0.05621613,-0.03501358,-0.043574344,-0.029308852,0.09776041,0.081443705,0.055143416,-0.02871935,-0.09776078,-0.006443992,-0.07539528,-0.009821041,0.01753493,-0.101507984,-0.0021935927,0.0010468741,-0.03527803,0.033280563,0.023343336,-0.05015812,0.006819744,0.0032354407,0.08251066,-0.15540196,-0.006447923,0.011665287,-0.09100527,-0.0042641833,-0.042528607,0.032753035,0.038509138,-0.05146997,0.05717378,-0.002775175,0.03310861,-0.03847387,0.030344239,0.03264575,0.007901514,-0.058788244,0.026605023,-0.015153136,-0.0010794887,-5.3060616e-05,0.016052721,-0.07064574,-0.05901542,0.001216926,0.04582064,0.04422859,-0.015964141,-0.05045548,-0.027295846,-0.06890897,-0.022256179,0.07572805,0.016999086,0.0918972,-0.02510393,0.08186069,0.12204206,-0.13897556,0.021870093,-0.1250067,0.05414963,0.018486036,-0.05930128,-0.025305195,0.01210013,-0.034681585,0.0036357108,0.03578195,0.027203508,-0.041920103,-0.09858611,-0.0426839,-0.07098479,-0.0063444623,0.037931584,0.03640844,0.0011521555,0.038066383,-0.06993443,0.03509653,0.04546405,0.007911065,-0.037021585,0.04216283,-0.015890358,0.015927238,0.020768825,0.08535061,0.07403001,-0.08902787,0.0033095425,-0.041080944,-0.001521011,-0.02083276,-0.03626243,0.038498305,0.05982016,-0.023962468,-0.021143828,0.047809545,0.007601922,-0.0021610742,-1.9591527e-05,0.06617032,0.09709318,0.009146524,0.020982562,0.014303773,-0.04083855,-0.008694002,-0.00071419834,-0.06335658,6.829762e-33,0.018685922,0.024187572,0.064741716,-0.028954448,-0.10876584,-0.029972417,0.05006809,0.027661512,-0.048282843,0.03591109,-0.051951118,0.037404817,-0.06653974,0.02674337,0.10321025,-0.04446226,0.0116691645,0.065732375,0.06569822,-0.058321938,0.020740505,-0.039310608,-0.010132447,0.06168451,0.08370871,-0.046779968,0.008968849,-0.039037514,-0.009548617,0.011110097,-0.02844129,-0.000510873,-0.007720859,0.052210767,0.08699943,0.055980485,-0.054212797,0.03974258,0.0032780257,-0.042698923,-0.04396392,0.023519635,-0.011318814,-0.0748549,0.0035069005,0.046550807,-0.032750987,-0.007836857,-0.040041246,0.04112873,0.03441771,0.025009813,-0.050201163,0.16538368,0.055974487,0.0055626454,0.066784136,0.044478077,0.032624368,0.16862127,0.043580987,-0.07974299,-0.037922967,0.06481629,0.059669226,0.037005395,-0.07154952,0.012472708,0.057579286,0.0026308752,0.013627071,0.030205783,0.045600943,0.0014236488,-0.06804121,-0.025591055,-0.04863907,0.027396863,-0.034176286,-0.0077687716,-0.020037197,-0.0002914631,0.032782998,0.022264576,-0.07601625,-0.0063238842,0.06439597,0.013071592,-0.07459298,-0.027053552,-0.050004896,0.09533498,0.097277574,-0.057271726,0.033559304,-7.5227546e-33,-0.0010978745,-0.13185617,0.057411954,0.06086446,0.04758753,-0.07209758,0.04250194,-0.070767835,0.038764168,-0.029692307,-0.030045362,0.0042103664,0.106591366,-0.05529931,-0.055660076,0.040918335,-0.047815524,-0.030326277,-0.026994973,0.07617197,-0.076385304,0.05822648,0.05441257,-0.0069882753,0.038415022,-0.078060344,-0.04844364,-0.075852804,-0.031149505,0.01811663,-0.029302096,-0.01850787,0.06723456,-0.047928803,-0.04200957,-0.006723373,0.037821915,-0.028223531,0.070638224,0.06885246,0.0013156396,0.07818942,0.032397967,0.0020133986,0.012471171,0.037929475,-0.15336712,-0.026774345,-0.064761944,-0.006127279,-0.098225094,-0.005101101,-0.018653145,-0.031094192,0.068942204,-0.07903871,-0.04159453,0.01997641,-0.015283047,0.00411129,-0.041278094,0.01984285,-0.013221102,0.047771204,0.0004946108,-0.09616086,0.012666187,-0.027338527,0.013220789,-0.055786435,-0.025966698,0.014379225,0.054384228,0.06876589,-0.059210014,-0.03189393,-0.020891182,-0.008323009,0.018487394,0.08767639,-0.07262044,0.10825175,-0.03277042,0.09549738,0.014013311,0.006831266,0.01894973,-0.034828484,-0.006500062,-0.0046536764,-0.048189815,-0.024253024,-0.054257836,-0.0026248966,-0.01848425,-3.7310745e-08,-0.03977234,-0.047649346,-0.053722806,0.009414296,0.07842738,-0.04579753,-0.05025483,0.11058357,0.00041567537,0.0053517395,0.07952022,-0.01002829,-0.045666702,0.054518264,0.019625358,-0.043576125,0.03325919,-0.050569393,-0.03954952,0.03378317,-0.015468889,0.048269454,0.0010296792,0.022971626,0.068554185,-0.056617014,0.003878837,-0.014192801,-0.00018149389,0.034509268,0.012460856,-0.035814457,-0.01539514,-0.025895135,0.085589044,0.016374864,0.011633603,0.069305435,-0.10293644,0.040448815,0.0424364,-0.035009567,0.040921386,0.01328063,0.02848726,-0.009852583,-0.03541222,0.031855125,0.009774099,0.044534724,-0.038011704,-0.035049297,-0.031759173,0.0032912937,0.09703864,0.0034741317,-0.023010708,0.035557307,0.05462038,-0.06125311,0.0133676715,-0.006452205,-0.08580795,-0.006293019]	2026-01-14 14:15:14.862766+00	2026-01-14 14:15:14.862766+00
af43a4f7-967f-45ee-8baa-e7f9ab759984	inline-1768400114946	6cb9e4ec4aa108c2089d6f026372aaedcc147e8145310eec66644f7d28c18572	text	spec	Content	7	# Vector Search Implementation\n\n## Overview\nThis specification covers vector similarity search using pgvector.\n\n## Embedding Storage\nStore embeddings as vector(384) columns in PostgreSQL.\nUse IVFFlat indexes for approximate nearest neighbor search.\n\n## Query Patterns\nUse cosine distance operator <=> for similarity queries.\nORDER BY embedding <=> query_vector LIMIT k for top-k retrieval.	{}	[0.018514218,-0.011508709,-0.06940539,-0.050412517,-0.034636255,0.04953341,-0.048225507,-0.0114189675,-0.018590556,-0.028197167,-0.021083504,0.06910326,0.036078315,-0.012615899,-0.07674938,-0.01922897,0.092246525,0.10577303,0.014959401,-0.053657677,-0.020142604,-0.028343279,0.0046519097,0.018378025,-0.058828194,-0.019040974,0.043589327,-0.04768529,0.014893247,0.008733251,-0.0039822394,-0.00056323566,0.028615866,0.10008997,-0.15203835,0.039106406,-0.024410646,-0.058994513,-0.07448544,-0.032418385,0.0001637528,0.0420691,-0.072988726,0.08289378,-0.0054779015,0.0398802,-0.10717499,0.018015759,0.021223236,-0.03023582,-0.11175769,0.02831602,-0.03127495,-0.030684736,-0.014473577,-0.04264391,-0.03214972,-0.07588726,0.045713313,-0.019543108,0.028798824,-0.088654704,0.07788835,-0.054702032,-0.004994032,-0.060826007,0.081016526,0.02384407,0.052710354,-0.061524052,0.027707925,0.09137281,-0.12257836,0.039558332,-0.12302342,0.10879319,-0.0082017835,-0.009011316,-0.004888013,-0.010135466,-0.048452724,0.010679984,0.05409522,0.0012773924,-0.027209273,-0.037761495,0.022554811,-0.062401947,0.03220445,-0.021253455,0.041079756,0.03718505,-0.012100619,-0.078012764,0.019046938,-0.0464249,0.054153655,0.0450468,0.05486941,-0.06234896,0.03606029,0.03704782,0.05066216,0.017433776,-0.06269887,0.020580739,-0.04149546,-0.0020322541,0.074188836,-0.077996306,-0.025486724,0.005502412,-0.07863441,-0.01782435,0.045995902,-0.026102249,0.05622875,-0.00921638,0.072821975,-0.03422478,-0.0005136076,0.017680218,-0.052981615,-0.02785052,-0.04509846,-0.0066941804,-0.024263408,9.4089595e-33,-0.020053068,0.016198626,0.07604615,-0.019956606,-0.081292436,-0.045742165,0.02346939,0.084754884,-0.021219486,0.046105254,-0.08896373,0.10720365,0.016471256,0.057522893,0.026047856,-0.002675676,0.006851853,-0.047585413,-0.001984821,-0.04094863,0.08635875,-0.05735651,0.02809981,0.07050852,0.013902427,-0.052440118,-0.019983208,-0.1490788,0.036286652,-0.016217634,-0.05239618,-0.0034066597,0.0058095567,0.056996204,0.052890226,0.032377828,0.012278463,-0.0030563225,-0.042055957,-0.053387947,-0.003160968,-0.044201292,-0.019674802,-0.075846575,-0.023550699,0.027673308,-0.008611503,-0.012001645,0.030969005,-0.022297123,0.04749211,0.03491917,-0.07975978,0.077727996,0.07446319,-0.012707657,0.029137488,0.025143914,0.028054986,0.09582269,0.03062287,-0.03615871,0.053767357,-0.0072662,-0.02335719,-0.06554771,-0.03903419,0.03348494,0.06436956,0.119953625,0.04499652,0.085540146,-0.010652942,-0.027473545,-0.007998017,-0.007757413,-0.04707934,-0.034628786,-0.009857762,0.002414545,-0.089425586,-0.06316757,0.017324913,-0.013203972,-0.04325479,-0.11533002,0.073694095,-0.038290244,-0.046242017,-0.022663534,-0.0036321732,0.08984859,0.051778473,0.0046324134,0.033250198,-9.755256e-33,-0.033585288,-0.08273861,0.023197198,0.025340032,-0.020755304,-0.02643987,-0.008152151,-0.042117953,-0.04689026,-0.06161308,-0.07145263,-0.04244707,0.14040585,-0.054148853,-0.013206165,0.12584755,-0.050081614,-0.0026651542,-0.108244576,0.07337572,-0.050866414,-0.008216138,-0.002343139,0.03549491,0.08141551,-0.019214643,0.09887545,-0.059652448,-0.030039834,-0.061191823,-0.020255398,-0.018399099,0.023446528,-0.011767861,-0.07062516,-0.01970526,0.03172066,-0.04884532,0.00095157116,0.017818691,-0.053800542,0.072964646,0.053348746,-0.007897585,-0.0070894645,0.04001985,-0.093214765,0.005296362,0.06611359,-0.024761345,0.061257053,0.021645814,-0.05160723,0.011656689,0.099695556,0.004745694,-0.09029908,0.08273226,-0.0058466354,-0.008363336,0.015009152,-0.011522367,0.022403693,0.040053565,0.036452085,-0.059212435,0.03658455,0.0501133,-0.041011147,-0.017040778,0.020877466,0.036453575,0.058103822,0.04550748,-0.034862895,-0.02007901,0.051402893,0.037909016,0.008786593,0.012590975,0.026941983,0.055551462,0.051901005,0.054336645,-0.023717897,0.041142497,0.017585851,0.0037849501,-0.006842172,0.020015448,-0.021340873,-0.0037434353,-0.08867902,-0.00050051074,0.037594806,-3.7453624e-08,-0.06925475,-0.059018664,-0.0235964,-0.04777863,0.040757403,0.0020517563,0.07017932,0.08875166,-0.09776251,0.03389053,0.016753929,-0.018224364,0.0059598666,0.039920732,0.039837692,-0.037311856,0.0065873074,-0.08914033,0.038464602,0.026129616,-0.07196469,0.05995121,0.004551563,0.077923246,0.009631791,-0.0052168877,-0.017184686,0.019864056,0.14592783,0.010551218,0.002484034,-0.006982759,0.025543325,-0.11418892,0.058034196,0.028235955,0.027501564,0.040928278,-0.08386762,0.043095924,0.05458129,-0.046552777,0.03629584,-0.019971848,0.013876498,0.0056591616,0.056386176,-0.0047487374,0.001493535,0.042943746,-0.053385984,-0.057076447,-0.079404466,0.05220333,0.024915015,-0.03316493,-0.09412523,-0.03308165,0.08272948,-0.1203712,0.00927231,-0.020805167,0.037097678,0.05559987]	2026-01-14 14:15:14.946353+00	2026-01-14 14:15:14.946353+00
bcc97702-2be6-440b-a10e-6050fb8da050	inline-1768400115005	61d8e5e25a50bded3e8eedec8bb7fa89ea92ba071a6912b95ff41b5c7373af27	text	guide	Content	7	# Frontend React Components\n\n## Overview\nGuidelines for building React components in the application.\n\n## Component Structure\nUse functional components with hooks.\nImplement proper prop typing with TypeScript.\n\n## State Management\nUse React Context for global state.\nPrefer local state for component-specific data.\nConsider React Query for server state.	{}	[0.011188581,-0.046553813,0.019468347,-0.014245992,-0.0277189,0.069694765,0.031614374,0.12261348,-0.04112358,0.013624039,-0.07749823,0.0151102515,-0.04789103,0.061268345,0.06716992,0.039276022,0.06920674,-0.053360477,0.04457615,-0.005330935,0.06902271,-0.09441496,0.080276616,0.03755667,-0.00587929,0.0546543,0.08270866,-0.037301634,0.0512039,0.0106126,-0.0036823878,0.046552323,-0.031817224,-0.022284511,-0.16545223,0.051766533,-0.07416041,-0.04253071,-0.0402157,-0.07883616,0.027927684,0.018332895,0.0017670407,-0.0076196734,0.050678186,-0.0015125811,0.030332105,-0.05216789,-0.06580005,-0.034670986,-0.044662274,0.02247055,0.010792173,0.047842085,0.00471608,-0.055159006,-0.020395745,-0.02387508,0.013158974,-0.05429819,-0.0126624005,-0.01731067,0.02330542,-0.042787608,0.062317975,0.043131437,-0.028697696,0.007900719,0.0978269,-0.07156446,-0.019229108,0.010160816,0.074322715,-0.06737122,-0.04219836,-0.1090647,-0.0075827404,-0.0073070982,0.041043025,0.030074822,-0.03280134,0.0067873066,-0.058345806,0.033989564,-0.015230148,0.078172594,0.028504675,-0.012430808,-0.053969257,-0.015966604,0.029749066,-0.05419107,0.09435892,-0.020374205,0.012462837,0.043195397,-0.049068686,0.041044567,0.03127663,-0.04461458,0.07501418,-0.0146059515,0.014368626,0.095583625,-0.062415183,-0.029740438,-0.032160655,-0.024775462,0.013196625,0.01949601,-0.04535052,0.03948553,-0.0039020572,-0.03284824,-0.019712165,-0.04496549,0.032936506,-0.094091214,0.025723817,0.028077757,-0.017340211,-0.020468028,0.032525245,-0.023710517,0.056514997,0.05587574,-0.046032663,5.5518352e-33,-0.027099095,0.029688023,-0.021986734,0.10573832,-0.0053650076,0.014458047,0.035567567,-0.03307894,0.0068071047,-0.001116916,0.05645011,0.05376413,-0.039169695,0.03407763,0.017608987,-0.04237282,0.08010308,0.00360853,0.05330391,-0.054773565,-0.04292726,0.005326605,0.001126525,0.06794052,0.113978356,-0.0068475003,-0.02629263,0.13088343,-0.12479874,-0.049649436,0.1008705,-0.046346482,-0.035649236,0.0739771,0.01209841,-0.06094397,-0.0564112,-0.049362097,-0.03715143,-0.04478056,0.03976614,0.025892692,-0.032747325,0.08073679,0.04254017,-0.026876668,-0.020748938,-0.009200134,0.04195855,0.06353034,-0.042725664,0.003992736,0.099853896,-0.024279606,0.046069767,0.042150892,0.054412697,0.00089318445,0.047522437,0.03594026,-0.07186125,-0.059519272,0.007421078,-0.03385445,-0.031765804,0.058431953,-0.025690459,-0.019563658,0.017377358,-0.016233275,0.053926893,0.013248273,0.030223086,0.063746676,0.015967738,0.042691585,-0.05701784,-0.0040656137,0.025503723,-0.0076636,-0.03496414,0.0027111918,-0.06365675,0.16613169,0.07367736,0.0042952388,-0.04684716,-0.04412597,0.017664874,0.088984184,-0.02302811,-0.057433438,0.05481211,0.011522789,-0.009101059,-5.954209e-33,0.007862729,-0.027668577,-0.043092187,-0.023803433,-0.03258705,-0.040078476,-0.10107425,-0.020782858,0.022156758,-0.031366765,-0.023217127,-0.005730165,0.15670872,-0.0065911645,-0.13502757,0.12952259,-0.026844747,-0.07233472,0.03725351,-0.0069842758,-0.041091602,-0.021101704,-0.041173916,0.058356073,-0.033826876,0.027707811,0.0036108887,-0.06561783,0.0014390448,-0.020294059,-0.05104344,-0.06774797,0.04665651,-0.017022613,-0.09089636,-0.041903615,0.04547155,-0.04523619,-0.036255375,-0.045040905,0.016495308,-0.022366025,0.037365615,-0.00021640962,-0.08844447,-0.02725896,-0.1109961,0.047965676,-0.034734093,0.012417816,-0.05370896,-0.07252288,-0.015042836,-0.10462652,-0.038493205,-0.020759623,0.004280619,0.0004099731,0.061543226,-0.0039848182,-0.0233135,-0.06866195,0.03340272,0.08087144,-0.052947536,-0.08612849,-0.11010256,-0.006915284,0.036049183,0.031707574,0.04130325,0.038258675,0.050791096,0.03215282,0.036067575,0.00053106813,0.042866323,0.02597607,0.10607965,0.07854104,0.01501053,0.04287599,-0.038026955,0.028982295,-0.032836366,0.06596501,-0.017701186,0.00091661914,0.020575974,-0.032826312,-0.07325029,0.012680503,-0.10280419,-0.0070661823,-0.05563529,-3.526513e-08,-0.016454944,-0.047486316,-0.0063391426,-0.034388155,-0.031182582,0.039925285,-0.0338587,-0.039002147,-0.024707451,0.08122189,-0.010659619,0.053782485,-0.021188287,-0.047109686,0.011649546,0.008873658,0.009843745,0.070858456,-0.07501691,-0.026522372,0.028728737,0.022641353,-0.027839279,0.10698211,0.15546854,-0.028162168,0.08623244,0.017204806,-0.011945976,0.025609534,-0.027630478,0.0021653438,0.024444636,-0.013731246,0.025652962,0.042024266,0.023606375,-0.047690134,0.018492406,0.05930046,0.03539039,0.034131605,-0.06867544,0.016201489,-0.04159053,0.08570517,-0.052793607,-0.0033368834,-0.01564614,-0.04224339,-0.012039622,-0.037370153,-0.14665322,0.060455065,0.004687783,0.029094676,0.029290656,0.020246694,0.10984419,-0.08087972,0.026660407,0.040676076,-0.004002621,-0.048661307]	2026-01-14 14:15:15.004622+00	2026-01-14 14:15:15.004622+00
ce28fd71-dfb4-4b99-b6aa-4f96265dde29	inline-1768400115062	39418c1b434190582de972096b6d9417ed57996081cc95cc4c9f6dbe02315e07	text	guide	Content	7	# PostgreSQL Query Optimization\n\n## Overview\nBest practices for optimizing PostgreSQL queries.\n\n## EXPLAIN ANALYZE\nAlways use EXPLAIN ANALYZE to understand query plans.\nLook for sequential scans on large tables.\n\n## Index Usage\nEnsure indexes are being used with proper selectivity.\nConsider covering indexes for frequently accessed columns.\nMonitor index bloat and schedule regular maintenance.	{}	[0.07799927,0.065358,-0.015016293,0.010776996,-0.031294566,-0.014218876,0.026175182,-0.0067990553,-0.070468605,0.046647117,-0.09201568,0.078790404,-0.1037307,-0.055496976,-0.086512506,0.002105514,0.0485798,0.0367459,-0.059938975,-0.071099885,-0.008429903,-0.10542838,0.03833308,0.024697531,-0.099792205,0.015992682,0.025827946,-0.008931142,0.029191379,-0.008100195,-0.058551915,0.030970274,0.067912616,0.08121032,-0.12358356,0.047522523,0.03886784,-0.031921875,0.019957304,-0.021629455,-0.03779854,-0.018236477,-0.07355745,0.0035904718,0.0055662594,-0.041356422,-0.0376389,-0.050862066,-0.04140166,-0.0016508497,-0.12607662,0.01308896,-0.017843947,-0.08368438,0.022886284,-0.006930407,-0.016428266,-0.11180453,0.09045544,-0.0068197874,-0.014406662,0.030062763,-0.029253174,0.00101017,-0.042370643,-0.01783439,0.09343584,0.0341101,0.05905075,0.07044525,0.03451775,0.10044195,-0.10108246,-0.024145972,-0.06402502,0.025562877,-0.04487972,-0.052262515,-0.010292948,-0.031200338,-0.0036260115,0.035945684,-9.9569595e-05,0.033485774,-0.032660887,-0.07428143,-0.06243805,-0.083732516,-0.006883152,-0.00610166,0.06843183,0.04245091,-0.016372146,-0.047941823,0.087114476,0.065178744,-0.04451768,-0.09343859,0.056836985,-0.021942684,0.07219266,0.03312891,0.08777993,0.060126267,-0.117076784,-0.047341466,0.043817177,0.04602251,-9.576471e-05,0.002179836,0.059125394,0.047176305,-0.04325174,-0.017638661,0.095851645,0.03445043,-0.009593722,0.018037034,0.045049448,0.082506254,0.041900203,0.010573237,0.010056043,-0.08538127,0.023564188,0.042895578,-0.07003182,7.7236804e-33,-0.029663276,0.017501997,0.012692117,0.0012023784,-0.13655071,0.0021508876,0.05393222,0.067199506,0.0023767825,0.028383626,0.038017485,0.07765807,-0.04745539,0.046072293,0.058904983,-0.018431704,0.015423999,0.11804055,-0.042502552,-0.026484758,0.04960169,-0.089157656,-0.031149914,0.05757617,0.06662777,-0.0011698619,-0.0067220824,-0.062871,-0.030295046,0.0094516,-0.0019523344,0.018380102,-0.0794173,0.059232138,0.04425265,0.05650163,-0.046751454,0.069525376,-0.019922942,-0.057469115,-0.037162274,-0.021306418,-0.010105989,-0.040382337,0.01662,0.051403884,-0.03683388,-0.016693583,0.034408327,0.05432244,0.02383808,-0.007351419,0.026950618,0.11206381,0.021437211,0.024077248,0.058249854,-0.057753973,0.00035244712,0.1412253,0.010601469,-0.106012695,-0.012743074,-0.032945216,0.0058704414,0.01106866,-0.053767394,0.07914789,0.038399346,0.030448332,-0.058703523,0.040341876,0.10023922,-0.002602079,0.026886364,-0.03762001,-0.044800058,0.07320891,-0.029558677,-0.03905146,-0.009999234,0.031161059,0.06796794,-0.04180941,-0.07893928,-0.041786723,0.07253589,0.058447298,-0.0690955,-0.011973327,-0.013446738,0.103771515,-0.0049436553,-0.0040098573,0.0015635767,-9.841162e-33,-0.004396457,-0.017561017,-0.022895379,0.057402205,0.0042064693,-0.0052187443,-0.0069992864,-0.09276003,0.035477277,-0.08761414,-0.090357125,-0.030373631,0.043636296,-0.03653649,-0.07912205,0.0237733,-0.009321361,-0.082147814,-0.028075524,0.057648454,-0.098966986,0.069309056,0.010371435,-0.057962578,0.008507839,-0.005968143,-0.015458154,-0.031901333,0.013571586,0.03917779,-0.054708887,0.033849586,0.049143154,0.032554112,0.014969269,0.015416204,0.03801695,-0.066018686,0.028791405,0.08201168,0.055647142,0.08985561,0.12540063,-0.0025539754,-0.0067827776,0.05103239,-0.07368972,-0.013838221,-0.058222234,0.029703584,-0.02406212,-0.010493385,-0.03777508,-0.028940102,0.009472639,-0.005192285,-0.055622686,-0.035617482,-0.034645133,0.021630574,-0.065289535,0.08161284,-0.029737828,0.073050715,-0.022744037,-0.056065373,0.04540743,-0.08039475,0.030501813,-0.034497663,-0.06860292,-0.000545074,0.022747573,0.031206012,-0.029064376,0.019655604,-0.02309101,-0.00719087,0.007713638,0.021094093,0.014976742,0.039352845,-0.050938986,0.0025287464,-0.09375847,0.032814354,-0.043231048,-0.019987809,-0.038107786,-0.006039109,-0.059258334,-0.09011852,-0.07526099,-0.042093135,-0.0028805418,-3.9674187e-08,-0.04096081,-0.045953635,0.0676712,-0.00077992375,0.08700019,-0.039510112,-0.02593714,0.1176395,-0.0063608377,-0.011005018,0.06437878,-0.038070332,-0.040357593,0.048685297,0.023340393,-0.0597066,-0.01579713,-0.015349632,-0.09029709,-0.03427718,-0.12165185,0.012363425,-0.047989454,-0.005592714,0.059798658,-0.0347665,0.03355077,0.031124571,0.039236344,0.03498761,-0.0052301073,-0.0075766495,-0.01206714,-0.030959414,0.053187802,0.009712985,0.0039033887,-0.011979259,-0.02900252,0.059126094,0.0019994199,0.016678508,0.0040276726,-0.010443753,-0.035085645,-0.043650307,-0.08318777,0.057094,0.039322704,-0.017129324,-0.028434549,-0.0827306,-0.05286304,0.076389454,0.036705464,0.06517403,0.025720999,0.041030385,0.050207343,-0.012639084,0.031548373,0.045490056,-0.06999177,0.02873958]	2026-01-14 14:15:15.060584+00	2026-01-14 14:15:15.060584+00
2e560d15-2a8a-45dd-a1e3-23b5b821c13a	inline-1768401213372	ab1e8e99a339f8680db8e04aeedf442c44f5d3b0ce4c1845187382fc28882d95	text	guide	Content	5	# Deprecation Test\n\nThis document will be deprecated for testing purposes.\n\n## Features\n\n- Feature A\n- Feature B	{"deprecated": true, "deprecated_at": "2026-01-14T14:33:33.447Z", "deprecation_reason": "Test deprecation - verifying pgvector migration"}	\N	2026-01-14 14:33:33.391033+00	2026-01-14 14:33:33.446833+00
045eab50-7e02-4320-a6f4-34328cb9a22f	/tmp/test-doc-to-ingest.md	82fd1a566c5c4d9e4ba8d068bddeaa4fd45b95fc865406431637efc69da6a2a3	markdown	spec	Authentication System Design	8	# Authentication System Design\n\n## Overview\nThis document describes the authentication system for the Agentic Platform.\n\n## Authentication Methods\nThe platform supports multiple authentication methods:\n- JWT-based authentication for API access\n- OAuth 2.0 for third-party integrations\n- Session-based authentication for web UI\n\n## Security Requirements\n- All tokens must be signed using RS256\n- Token expiration: 1 hour for access tokens, 7 days for refresh tokens\n- Rate limiting: 100 requests per minute per user\n\n## Implementation Details\nThe auth service is implemented in TypeScript using the `jsonwebtoken` library.\nUser credentials are stored in PostgreSQL with bcrypt hashing.\n\n## API Endpoints\n- POST /auth/login - Authenticate user\n- POST /auth/refresh - Refresh access token\n- POST /auth/logout - Invalidate session\n	{}	[0,0.039751325,-0.063408114,0.06254655,-0.040407162,0.010297064,0.010832211,-0.010551586,-0.013050472,0.050419606,-0.0850892,0.10155307,-0.09268281,0.06313379,-0.02710676,0.001538519,0.0020135306,0.017098114,-0.048317008,0.07496591,-0.082269594,0.06447018,-0.027622927,-0.013268492,0.041404426,-0.0462005,0.028317327,0.0007022667,-0.024013832,0.027593268,-0.007005219,-0.030428026,0.06909771,-0.09255617,0.091370426,-0.0676168,0.033861943,-0.0071191876,0.00067829125,-0.017726125,0.049817137,-0.08092696,0.09514552,-0.08432091,0.05198869,-0.011702469,-0.019434372,0.028934812,-0.014877372,-0.013213555,0.03897765,-0.0471079,0.030735796,0.005229258,-0.04640812,0.07580174,-0.081898965,0.0641557,-0.033218727,0.0057876664,0.0034210156,0.01124557,-0.04364711,0.07878031,-0.09996424,0.096835785,-0.07032165,0.032202933,0.00051905325,-0.013754566,0.0030561714,0.024278376,-0.05273889,0.06607681,-0.05513635,0.02228735,0.019666264,-0.053579777,0.06614186,-0.054211073,0.026277311,0.0016519299,-0.0137673,0.0020752987,0.029735113,-0.06803145,0.09574889,-0.10055215,0.08073506,-0.04602932,0.012934899,0.0031890566,0.00451947,-0.03114874,0.06238719,-0.0814094,0.0769721,-0.048837963,0.007926212,0.028882897,-0.046799075,0.04016907,-0.015141539,-0.01332721,0.028690288,-0.020789,-0.009232941,0.04943667,-0.08277431,0.095228255,-0.082501605,0.05205237,-0.01949648,0.001104635,-0.005990707,0.03173732,-0.065556064,0.09042607,-0.0932675,0.071230926,-0.03308664,-0.0049524885,0.026972322,-0.02495166,0.002568709,0.026604624,-0.045654222,0.042479053,-0.015639402,-0.024906784,0.062533155,-0.081873044,0.076145716,-0.050368793,0.018917125,0.0014008536,0.00057087175,-0.024964929,0.060810212,-0.09128091,0.101758376,-0.08684044,0.05293751,-0.015210461,-0.009681472,0.011546084,0.008482045,-0.038517095,0.06165639,-0.06412362,0.04191588,-0.0027667494,-0.037516363,0.06258535,-0.06334366,0.042262416,-0.012151461,-0.010024561,0.011319544,0.010950842,-0.047890015,0.08325843,-0.10123703,0.09399436,-0.06542916,0.029294495,-0.002602636,-0.0025269105,-0.015332201,0.046245333,-0.07370155,0.08255638,-0.06632391,0.030321429,0.01084173,-0.040227644,0.046647534,-0.02998131,0.0011891838,0.022989614,-0.0281084,0.008984161,0.027774915,-0.06689805,0.09173712,-0.09221616,0.0696339,-0.036017384,0.008336643,-0.0003548669,0.016021734,-0.047577746,0.07927853,-0.09495333,0.085773505,-0.054506004,0.014212118,0.017984997,-0.029076198,0.016366087,0.011275413,-0.03770907,0.047309496,-0.032502934,-0.0025551633,0.04392677,-0.074529506,0.082284294,-0.065866575,0.035304166,-0.007135722,-0.0035483728,-0.00963398,0.041276988,-0.07676466,0.099270076,-0.09782048,0.0725612,-0.034694485,0.0011225721,0.0136370035,-0.0043875286,-0.02228444,0.051200595,-0.06590557,0.056597076,-0.024868604,-0.017010005,0.051929805,-0.06609977,0.055613287,-0.02827634,-0.00017840373,0.013675758,-0.0035433997,-0.027295796,0.06569509,-0.09456186,0.101032466,-0.08262479,0.048418723,-0.014698622,-0.002852683,-0.0033341888,0.029099036,-0.06056533,0.080817275,-0.07803884,0.051211953,-0.010641163,-0.026947295,0.046382833,-0.041279994,0.017054487,0.011719661,-0.028343907,0.022046762,0.006808051,-0.046854705,0.08113644,-0.095200926,0.08399883,-0.054278515,0.021328948,-0.0016329756,0.0049536442,-0.029648151,0.063456304,-0.08938545,0.09387009,-0.07329375,0.035745803,0.002829582,-0.026246116,0.025800336,-0.004405406,-0.02484764,0.045010693,-0.043450113,0.0179503,0.022177916,-0.06051619,0.08136689,-0.07723789,0.052395854,-0.02078497,-0.0006905167,0.00029852893,0.02287334,-0.058463253,0.08979167,-0.1018527,0.08850875,-0.055438805,0.01742673,0.008710489,-0.012164064,-0.0067108953,0.03659692,-0.06067582,0.0647312,-0.044006318,0.005528538,0.035214845,-0.061656237,0.06404525,-0.044078223,0.014040661,0.009125445,-0.011984281,-0.008915514,0.045353677,-0.08135168,0.10081077,-0.095212735,0.06769154,-0.031523682,0.0037612373,0.002939571,0.013623527,-0.04415864,0.072355896,-0.082733475,-0.040898338,0.0014840225,0.024536226,-0.027185608,0.007873425,0.021322316,-0.043489754,0.045037206,-0.022256045,-0.016855016,0.056379568,-0.08007087,0.07909958,-0.056247875,0.024539413,-0.0009627643,-0.0017018524,-0.01896675,0.05385206,-0.08665862,0.10171849,-0.09150264,0.060235586,-0.021880452,-0.00654002,0.0130840475,0.0034096488,-0.032795787,0.05852166,-0.06560195,0.047844965,-0.0108648315,-0.0305652,0.059550095,-0.06512753,0.04747833,-0.017795408,-0.0071253804,0.0129782,0.0051569017,-0.04042216,0.0774416,-0.09966955,0.09730502,-0.07197771,0.035958856,-0.0062756026,-0.0034492407,-0.010480554,0.040077433,-0.069520205,0.08276517,-0.071268536,0.03811704,0.0034143678,-0.03618669,0.047371395,-0.034556437,0.0068568923,0.019501649,-0.029008538]	2026-01-14 17:02:37.857521+00	2026-01-14 17:02:37.857521+00
40f8ef34-7307-4fd9-8741-2652f5e10b88	consolidated-e5f15f4c-3abe-4f7d-998d-ea7c9e3d7992	29cc8cae	markdown	reference	Consolidated: Authentication System Design + API Security Guidelines	5	# Consolidated Document\n\n> Generated: 2026-01-14T17:04:34.301Z\n\n## Source Documents\n\n- **Authentication System Design** (045eab50-7e02-4320-a6f4-34328cb9a22f)\n- **API Security Guidelines** (32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a)\n\n---\n	{"strategy": "authority_wins", "consolidation_id": "e5f15f4c-3abe-4f7d-998d-ea7c9e3d7992", "consolidated_from": ["045eab50-7e02-4320-a6f4-34328cb9a22f", "32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a"]}	\N	2026-01-14 17:04:34.300185+00	2026-01-14 17:04:34.300185+00
d68c9fcc-2bf0-4399-af0b-94b87cfe0079	consolidated-414c6eb1-e1f7-4a52-8ab5-610be734663c	5f1a4452	markdown	reference	Consolidated: Authentication System Design + API Security Guidelines	5	# Consolidated Document\n\n> Generated: 2026-01-14T17:05:16.452Z\n\n## Source Documents\n\n- **Authentication System Design** (045eab50-7e02-4320-a6f4-34328cb9a22f)\n- **API Security Guidelines** (32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a)\n\n---\n	{"strategy": "merge_all", "consolidation_id": "414c6eb1-e1f7-4a52-8ab5-610be734663c", "consolidated_from": ["045eab50-7e02-4320-a6f4-34328cb9a22f", "32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a"]}	\N	2026-01-14 17:05:16.45241+00	2026-01-14 17:05:16.45241+00
32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	/tmp/test-doc-conflict.md	eb43781dcdf4f056326a14affa1f0024d678370f78bae30b6c0397b99964dfbd	markdown	guide	API Security Guidelines	6	# API Security Guidelines\n\n## Overview\nSecurity guidelines for the Agentic Platform API layer.\n\n## Authentication Configuration\nThe platform uses the following authentication settings:\n- JWT tokens signed with HS256 algorithm\n- Token expiration: 24 hours for access tokens, 30 days for refresh tokens\n- Rate limiting: 1000 requests per minute per API key\n\n## Session Management\nSessions are stored in Redis with a 48-hour TTL.\nAll sessions require re-authentication after password change.\n\n## Password Requirements\n- Minimum 12 characters\n- Must include uppercase, lowercase, number, and special character\n- Passwords hashed using Argon2id\n	{"deprecated": true, "deprecated_at": "2026-01-14T17:06:32.390Z", "deprecation_reason": "Consolidated into unified authentication specification"}	[0,0.039751325,-0.063408114,0.06254655,-0.040407162,0.010297064,0.010832211,-0.010551586,-0.013050472,0.050419606,-0.0850892,0.10155307,-0.09268281,0.06313379,-0.02710676,0.001538519,0.0020135306,0.017098114,-0.048317008,0.07496591,-0.082269594,0.06447018,-0.027622927,-0.013268492,0.041404426,-0.0462005,0.028317327,0.0007022667,-0.024013832,0.027593268,-0.007005219,-0.030428026,0.06909771,-0.09255617,0.091370426,-0.0676168,0.033861943,-0.0071191876,0.00067829125,-0.017726125,0.049817137,-0.08092696,0.09514552,-0.08432091,0.05198869,-0.011702469,-0.019434372,0.028934812,-0.014877372,-0.013213555,0.03897765,-0.0471079,0.030735796,0.005229258,-0.04640812,0.07580174,-0.081898965,0.0641557,-0.033218727,0.0057876664,0.0034210156,0.01124557,-0.04364711,0.07878031,-0.09996424,0.096835785,-0.07032165,0.032202933,0.00051905325,-0.013754566,0.0030561714,0.024278376,-0.05273889,0.06607681,-0.05513635,0.02228735,0.019666264,-0.053579777,0.06614186,-0.054211073,0.026277311,0.0016519299,-0.0137673,0.0020752987,0.029735113,-0.06803145,0.09574889,-0.10055215,0.08073506,-0.04602932,0.012934899,0.0031890566,0.00451947,-0.03114874,0.06238719,-0.0814094,0.0769721,-0.048837963,0.007926212,0.028882897,-0.046799075,0.04016907,-0.015141539,-0.01332721,0.028690288,-0.020789,-0.009232941,0.04943667,-0.08277431,0.095228255,-0.082501605,0.05205237,-0.01949648,0.001104635,-0.005990707,0.03173732,-0.065556064,0.09042607,-0.0932675,0.071230926,-0.03308664,-0.0049524885,0.026972322,-0.02495166,0.002568709,0.026604624,-0.045654222,0.042479053,-0.015639402,-0.024906784,0.062533155,-0.081873044,0.076145716,-0.050368793,0.018917125,0.0014008536,0.00057087175,-0.024964929,0.060810212,-0.09128091,0.101758376,-0.08684044,0.05293751,-0.015210461,-0.009681472,0.011546084,0.008482045,-0.038517095,0.06165639,-0.06412362,0.04191588,-0.0027667494,-0.037516363,0.06258535,-0.06334366,0.042262416,-0.012151461,-0.010024561,0.011319544,0.010950842,-0.047890015,0.08325843,-0.10123703,0.09399436,-0.06542916,0.029294495,-0.002602636,-0.0025269105,-0.015332201,0.046245333,-0.07370155,0.08255638,-0.06632391,0.030321429,0.01084173,-0.040227644,0.046647534,-0.02998131,0.0011891838,0.022989614,-0.0281084,0.008984161,0.027774915,-0.06689805,0.09173712,-0.09221616,0.0696339,-0.036017384,0.008336643,-0.0003548669,0.016021734,-0.047577746,0.07927853,-0.09495333,0.085773505,-0.054506004,0.014212118,0.017984997,-0.029076198,0.016366087,0.011275413,-0.03770907,0.047309496,-0.032502934,-0.0025551633,0.04392677,-0.074529506,0.082284294,-0.065866575,0.035304166,-0.007135722,-0.0035483728,-0.00963398,0.041276988,-0.07676466,0.099270076,-0.09782048,0.0725612,-0.034694485,0.0011225721,0.0136370035,-0.0043875286,-0.02228444,0.051200595,-0.06590557,0.056597076,-0.024868604,-0.017010005,0.051929805,-0.06609977,0.055613287,-0.02827634,-0.00017840373,0.013675758,-0.0035433997,-0.027295796,0.06569509,-0.09456186,0.101032466,-0.08262479,0.048418723,-0.014698622,-0.002852683,-0.0033341888,0.029099036,-0.06056533,0.080817275,-0.07803884,0.051211953,-0.010641163,-0.026947295,0.046382833,-0.041279994,0.017054487,0.011719661,-0.028343907,0.022046762,0.006808051,-0.046854705,0.08113644,-0.095200926,0.08399883,-0.054278515,0.021328948,-0.0016329756,0.0049536442,-0.029648151,0.063456304,-0.08938545,0.09387009,-0.07329375,0.035745803,0.002829582,-0.026246116,0.025800336,-0.004405406,-0.02484764,0.045010693,-0.043450113,0.0179503,0.022177916,-0.06051619,0.08136689,-0.07723789,0.052395854,-0.02078497,-0.0006905167,0.00029852893,0.02287334,-0.058463253,0.08979167,-0.1018527,0.08850875,-0.055438805,0.01742673,0.008710489,-0.012164064,-0.0067108953,0.03659692,-0.06067582,0.0647312,-0.044006318,0.005528538,0.035214845,-0.061656237,0.06404525,-0.044078223,0.014040661,0.009125445,-0.011984281,-0.008915514,0.045353677,-0.08135168,0.10081077,-0.095212735,0.06769154,-0.031523682,0.0037612373,0.002939571,0.013623527,-0.04415864,0.072355896,-0.082733475,-0.040898338,0.0014840225,0.024536226,-0.027185608,0.007873425,0.021322316,-0.043489754,0.045037206,-0.022256045,-0.016855016,0.056379568,-0.08007087,0.07909958,-0.056247875,0.024539413,-0.0009627643,-0.0017018524,-0.01896675,0.05385206,-0.08665862,0.10171849,-0.09150264,0.060235586,-0.021880452,-0.00654002,0.0130840475,0.0034096488,-0.032795787,0.05852166,-0.06560195,0.047844965,-0.0108648315,-0.0305652,0.059550095,-0.06512753,0.04747833,-0.017795408,-0.0071253804,0.0129782,0.0051569017,-0.04042216,0.0774416,-0.09966955,0.09730502,-0.07197771,0.035958856,-0.0062756026,-0.0034492407,-0.010480554,0.040077433,-0.069520205,0.08276517,-0.071268536,0.03811704,0.0034143678,-0.03618669,0.047371395,-0.034556437,0.0068568923,0.019501649,-0.029008538]	2026-01-14 17:03:53.963792+00	2026-01-14 17:06:32.389123+00
5026dbba-9135-4930-99ff-7852b4243c03	inline-1768412851080	0f71075b940c0c7e0ea6bb8b0248e31a40d27b1378b5c3ecdb1c394da7ae8a30	text	decision	Content	7	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.\n\n## Consequences\nMemory usage will decrease by approximately 40%.\nQuery latency may increase by 10-20ms for complex searches.\n	{}	[0.047602434,-0.03525335,0.037918285,-0.053530313,0.07333075,-0.086088486,0.083511956,-0.06425853,0.0356952,-0.016468275,-0.011177419,0.04029732,-0.030463615,0.006914509,0.013484652,-0.010993847,-0.0011434488,-0.014269915,-0.042817276,0.096458904,-0.12376107,0.11414927,-0.074399434,0.011019891,0.030778956,-0.018630216,-0.023140889,0.07360825,-0.10736842,0.10673954,-0.07026252,0.013427986,0.03871993,-0.01676237,-0.0026181694,0.037507184,-0.06842343,0.07757261,-0.057425432,0.014376509,0.03427088,-0.06854928,0.075348675,-0.054650597,0.019486595,0.010358316,-0.017877452,-0.0029614093,0.04428603,-0.08806125,0.114708655,-0.11247187,0.083037555,-0.040717132,0.0055818106,0.006157528,0.0100869285,-0.04509639,0.08028782,-0.09665191,0.083900645,-0.04543809,-0.0032296411,0.04188342,-0.05523715,0.04021648,-0.0073811025,-0.024190499,0.036100462,-0.025761046,-0.019312283,0.065523535,-0.09336453,0.091932215,-0.0641183,0.025188498,0.0045669395,-0.009587029,-0.0134787895,0.054149497,-0.09312882,0.11155406,-0.10004285,0.06320025,-0.01742499,-0.016933564,0.025307437,-0.00586532,-0.029643333,0.061559554,-0.071781695,0.05248813,-0.009932913,-0.03850627,0.07261311,-0.078979,0.057386268,-0.020868465,-0.010580499,0.019631473,3.614532e-05,-0.040673073,0.06727088,-0.08627688,0.06511704,-0.032089323,-0.0045181923,0.02806157,-0.03917062,0.0223452,0.006196207,-0.029983278,0.03485299,-0.015783219,-0.020657487,0.04535136,-0.05539808,0.03481373,-0.029063022,0.02144795,-0.018159766,0.023087934,-0.03591927,0.052256253,-0.06569819,0.070887916,-0.058803048,0.03669559,-0.03897275,0.031989787,-0.032359917,0.03772755,-0.043021988,0.04292749,-0.034475185,0.028298708,-0.002311183,-0.016250161,0.021765282,-0.014951114,0.0024655529,0.0063375244,-0.0039455234,-0.011659624,0.035984643,-0.064342655,0.08674326,-0.095252596,0.087248415,-0.0675728,0.046194974,-0.03342296,0.034960374,-0.049178187,0.067909695,-0.08038718,0.101829894,-0.08756659,0.05652567,-0.020352818,-0.0071873125,0.03697146,-0.033540804,0.014114051,-0.0014047711,-0.012281646,0.010505372,0.008816954,0.002093313,-6.30052e-05,-0.0071789785,0.017038157,-0.025570964,0.029363386,-0.02715735,0.020445213,-0.0127474675,0.007920077,-0.008303083,0.017365795,-0.035395887,0.031876694,-0.00817265,0.01670627,-0.025451215,0.036252603,-0.04149621,0.035209417,-5.3353586e-05,-0.015985508,0.04314883,-0.026724892,0.001686464,0.018255202,-0.032642506,0.029153459,-0.008695576,-0.01964108,0.042931136,-0.05994583,0.04526509,-0.026708402,-0.010462081,0.038553778,-0.043802004,0.023462582,0.01286885,-0.04785523,0.06472938,-0.041062467,0.027101632,0.0022697332,-0.054412473,0.0723996,-0.038721107,0.010465524,0.016520157,-0.03532093,0.038326576,-0.025482424,0.004294019,-0.0048972503,0.01570301,-0.0011907879,-0.0063450215,0.0043248287,0.010543777,-0.029414203,0.04119959,-0.03825375,0.019915571,0.007141762,-0.03207739,0.045047496,-0.041892268,0.026098404,-0.0070966287,-0.004288925,0.0010572078,0.016588978,-0.041319277,0.062172882,-0.069799975,0.06093458,-0.039954435,0.016780004,-0.0021200962,0.0023435638,0.006961495,0.009345548,-0.027095074,0.03626885,-0.030891793,0.011921363,0.013186316,-0.034025945,0.04220668,-0.03535039,0.01820789,-0.0003583135,-0.008404942,0.0027890496,0.015443528,-0.038305625,0.055403233,-0.05891029,0.04731527,-0.026143244,0.005307336,0.025856923,-0.02776969,0.011649614,0.051653836,-0.0853513,0.094231695,-0.07389784,0.05392791,-0.017997852,-0.004246341,0.00040250653,0.027514117,-0.06412152,0.089530475,-0.08891713,0.07343054,-0.026462182,-0.02518018,-0.013713672,-0.013001226,0.018772647,-0.0048175943,-0.018021906,0.034541775,-0.041876797,0.014473236,0.032677386,-0.08170999,0.11358425,-0.11714437,0.09440376,-0.05952184,0.03196438,-0.027127646,0.05241741,-0.08485515,0.112765945,-0.1219527,0.10664631,-0.07229304,0.032972664,-0.0046847393,-0.0022782416,-0.011785023,0.03618443,-0.05502543,0.054895215,-0.03136185,-0.008830854,0.050926227,-0.07540433,0.06633032,-0.065331176,0.026501209,-0.032043703,0.023655977,-0.030085312,0.050384857,-0.07651743,0.09718278,-0.10321652,0.09197269,-0.07484608,0.066550925,-0.03520305,0.021719845,-0.03191198,0.05699957,-0.05754166,0.07198968,-0.062495857,0.06704401,-0.010744494,-0.04675933,0.08153677,-0.080558516,0.04896397,0.0015301689,-0.037159618,0.026470644,0.016003923,-0.07098611,0.11288711,-0.12206432,0.094232425,-0.042516265,0.0056820763,0.001690956,0.018671507,-0.056744587,0.093597114,-0.11047906,0.09782839,-0.05987863,0.012657465,0.023664312,-0.034405682,0.01737199,0.016138755,-0.046801597,0.056581028,-0.037430298,-0.004798199,0.053107195,-0.08745369,0.09431045,-0.07310616,0.036457162,-0.00408016,-0.006694658,-0.010738985,0.049073555,-0.09057509,0.115576066,-0.11190177]	2026-01-14 17:47:31.100922+00	2026-01-14 17:47:31.100922+00
c36a563a-057e-4d04-a8a1-8937e8c78a5b	inline-1768413016726	be1d5b9c8df774af70f892d10622a42e7e41273ea8167bb81a307e84737372db	text	spec	Content	5	# Authentication API Specification\n\n## Overview\n\nThis document specifies the authentication system for our platform.\n\n## Authentication Methods\n\nThe API supports JWT-based authentication. All tokens expire after 24 hours.\nUsers must refresh their tokens before expiration to maintain access.\n\n## Security Requirements\n\n- All API endpoints require HTTPS\n- Passwords must be at least 12 characters\n- Failed login attempts are limited to 5 per hour\n- Two-factor authentication is mandatory for admin accounts\n\n## Rate Limiting\n\nThe API enforces rate limiting of 100 requests per minute per user.\nExceeding this limit results in a 429 status code.\n	{}	\N	2026-01-14 17:50:16.732325+00	2026-01-14 17:50:16.732325+00
eb97556c-8fd9-4483-acb1-fcea72679609	inline-1768413226905	be1d5b9c8df774af70f892d10622a42e7e41273ea8167bb81a307e84737372db	text	spec	Content	5	# Authentication API Specification\n\n## Overview\n\nThis document specifies the authentication system for our platform.\n\n## Authentication Methods\n\nThe API supports JWT-based authentication. All tokens expire after 24 hours.\nUsers must refresh their tokens before expiration to maintain access.\n\n## Security Requirements\n\n- All API endpoints require HTTPS\n- Passwords must be at least 12 characters\n- Failed login attempts are limited to 5 per hour\n- Two-factor authentication is mandatory for admin accounts\n\n## Rate Limiting\n\nThe API enforces rate limiting of 100 requests per minute per user.\nExceeding this limit results in a 429 status code.\n	{}	[-0.09031829,0.0051225885,0.00013385293,-0.034198172,-0.025381496,-0.049171895,-0.03944435,-0.008471834,0.043821048,-0.010257135,-0.01289736,0.036070608,0.044324826,0.010834743,0.08356941,0.016633166,0.011605002,0.018229892,-0.044116315,-0.060436822,0.08471102,-0.015221178,-0.06890839,0.017328592,-0.028584994,-0.049373478,0.01998672,-0.029790454,-0.026807638,0.07683681,-0.020583361,-0.016316267,-0.018428113,0.037796237,-0.0887178,-0.015395499,-0.002922717,-0.078839764,0.032691974,-0.06810807,-0.09319614,-0.025667502,-0.08678415,0.0401402,-0.041559003,-0.004132458,-0.039565608,-0.03528487,-0.08088737,0.0860608,0.028362373,0.021059414,0.056961946,-0.020720117,-0.08635012,-0.09421536,-0.07460613,0.03550514,-0.00018955737,0.10884458,0.022355193,-0.07461335,-0.008578467,-0.018351097,0.01532052,-0.040970173,-0.06569724,-0.0601339,0.09974146,0.016064763,-0.08889563,-0.006776174,-0.124443956,0.0040594684,-0.012037299,-0.021414407,-0.06383048,-0.022069862,0.076616526,-0.06728554,-0.019802101,-0.016263945,0.06376453,0.0878232,0.057606816,0.02607879,-0.027863055,0.11605425,-0.03859385,0.031436536,0.06652511,0.033168662,0.0046740468,-0.012950719,0.041039024,0.007550477,-0.06831829,-0.010049325,-0.1057292,0.007625723,-0.067657866,0.0012108965,-0.034654945,-0.026832921,0.08057162,-0.009559654,0.020878714,0.020756781,0.052162237,0.08334033,0.01210369,-0.034251686,-0.004955312,-0.037464064,0.0066244137,0.09827382,-0.03145537,0.027593607,0.07964238,0.03595453,0.06779379,0.042643145,0.03467882,-0.10180502,0.017032849,0.0132814385,0.05414444,1.1433071e-32,-0.046342846,0.06616522,0.01117746,0.017975735,-0.014290558,-0.033406727,-0.005760724,-0.0039221453,-0.015623649,-0.01824483,-0.004022295,0.033328455,-0.00801335,-0.011519834,0.058245026,-0.038923576,0.016450629,0.0029443833,0.09547693,0.03303515,0.054197893,-0.13004267,0.08295408,0.027351616,-0.036402795,-0.0037794642,0.025133526,0.035397504,-0.026962368,0.023737352,-0.01030931,-0.009058219,-0.040815603,-0.009623566,0.011411475,0.019221332,0.08566123,-0.02834767,0.03509432,-0.066065915,-0.048375383,0.030534532,-0.057499982,0.05718464,-0.02174285,-0.031639386,0.01852456,0.011610856,0.04704122,0.10071449,-0.073299006,0.07740573,-0.033137836,-0.0807366,0.024800545,-0.031109538,-0.022583129,0.012171819,-0.08351617,-0.020568177,0.012938339,-0.06636024,0.013976495,-0.044916883,-0.019698793,0.051900133,0.0009479372,0.011895624,-0.03385256,0.0341931,0.06086616,0.053467147,0.037839334,-0.0614689,-0.13955784,-0.035726126,0.1752279,0.075445406,0.044452243,0.024070632,0.07380859,-0.05641917,-0.0053843944,0.061755765,0.03217296,0.013219079,0.019668864,0.004536449,-0.08213318,-0.00983269,0.03657454,-0.07240017,0.057892278,0.0523532,-0.036059387,-1.01387144e-32,-0.00920365,-0.048630223,0.029285878,0.021904977,0.025801757,-0.027132494,-0.038544677,0.11763239,-0.031397875,0.026208758,0.008850296,-0.0037269336,0.067648284,0.013762017,-0.027506761,0.009570519,-0.04515917,-0.0006887052,0.022716835,-0.037297912,-0.0058547924,0.04052301,-0.038082413,0.012427971,0.016231027,0.032209363,-0.09909269,-0.023235448,-0.0072609033,-0.048706576,0.074130684,-0.058293592,-0.010928548,0.011631685,0.007307366,-0.15734546,0.07913769,0.14596504,0.02138761,0.01790754,0.08799271,-0.057588503,0.025005667,-0.021324571,0.006561268,0.02511148,-0.0074157557,0.0071881595,-0.08942312,-0.0019629553,0.01693877,-0.05903723,0.017113551,-0.0016241478,-0.022210078,-0.012054484,0.018393008,0.02869278,0.031967815,-0.023406472,-0.004283344,-0.051125515,0.03493542,0.14818355,-0.00636873,-0.04008479,-0.049048264,0.10563831,-0.07023423,0.03455783,0.040575176,-0.04386478,-0.030950574,0.045451205,0.028752841,-0.042080425,0.016549788,-0.092349604,-0.00023267488,0.0057495204,-0.073386356,0.047159158,-0.057441153,0.022348043,0.06391899,-0.087614484,0.008418213,0.029020274,0.04070462,0.04807121,0.033489753,0.0021363464,-0.06447025,0.043879457,0.00928012,-5.0457043e-08,0.009121322,-0.01203923,0.015240588,-0.035981603,0.012888943,0.08392665,-0.01293182,-0.043769866,0.018505149,0.039574146,0.10164322,0.020893332,-0.035557702,-0.07282307,-0.0787128,-0.026665313,-0.044845544,-0.026557853,0.010287314,-0.046067394,-0.07995422,-0.027193831,0.028771255,-0.067462556,-0.02792328,0.037638724,0.07325985,0.11899623,-0.04303376,-0.012186848,-0.09900412,0.041836865,-0.004102721,-0.07506652,-0.087428175,0.011194008,-0.051519707,-0.08565266,-0.06650224,0.0044136117,-0.030602619,-0.044118192,0.02057343,0.014730599,0.041951165,0.033368178,-0.0149644185,0.025732666,0.037414473,0.00052712235,-0.001777291,0.041876495,0.012172521,0.06962655,-0.03820857,0.065834925,-0.0018782207,0.011512415,0.08617241,-0.05230007,0.10888802,0.07443421,0.036731124,-0.035764124]	2026-01-14 17:53:46.910369+00	2026-01-14 17:53:46.910369+00
5941db0b-8fbf-44c8-ac52-5ac688ac8422	inline-1768413427028	2c5d1b8e1719ca316db92a88d2528a6670812ef091747d36591f67aa651e0e51	text	decision	Content	7	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.	{}	[0.019177882,-0.018898759,-0.04426501,0.033431903,-0.019915188,-0.05163123,-0.0796716,0.018727584,0.044522785,0.021913847,-0.083917506,0.04763559,-0.01660692,-0.03994266,-0.0015625198,-0.012262027,0.04773461,0.00799227,-0.05572599,-0.09389394,0.03156081,-0.020484721,-0.012421968,-0.06515133,-0.07347579,-0.04839906,-0.03253597,-0.019132616,-0.013932071,-0.040666018,0.008338815,-0.015178445,0.068746336,0.08208873,-0.07696376,0.10315318,0.00095837587,-0.14066522,-0.05912433,-0.008712068,0.030668283,-0.0039098766,-0.06551486,0.045439504,0.03409974,-0.057165746,-0.038693033,0.053132694,0.017657854,-0.015605455,-0.021396061,-0.009125348,-0.027349297,0.016800351,-0.0412514,0.068833545,-0.06790402,-0.053339764,-0.037571084,-0.06371681,0.055114742,-0.09197821,-0.026811017,-0.030393096,-0.0675832,0.0042271977,0.05832411,-0.09083766,0.09243547,-0.030935442,-0.001974594,0.0029972543,-0.06246038,-0.022545941,-0.025775153,0.017578702,0.08875414,0.04349829,0.04091676,-0.036860384,-0.018601447,-0.0057502845,-0.008365264,0.043200668,0.009814699,-0.039770875,0.020196252,-0.058878303,-0.003908051,-0.0061999615,0.0574618,-0.000739722,0.062884666,-0.03674477,-0.016301118,0.009239243,-0.016060824,-0.002385244,0.017394736,-0.0024885177,-0.030840192,0.045471117,0.048310984,0.0706624,-0.1212178,-0.036729246,-0.08422325,0.032396495,-0.0086961,-0.038275305,0.049727116,0.022724468,0.048063606,-0.027111605,-7.341316e-05,0.08510487,-0.07493397,-0.08693954,0.06523588,0.009916491,0.09386403,0.03509409,-0.03499985,-0.09185595,-0.0036730948,-0.03445356,-0.053064167,7.286481e-33,-0.023776557,0.065199256,0.029153524,-0.019542092,-0.033680364,0.04047401,0.026073046,0.07160516,-0.0605181,-0.018026156,-0.07882502,0.09200167,-0.028901968,0.050911732,0.07836532,0.07893845,0.06206762,0.0638576,-0.005010709,-0.01906934,0.07500853,-0.0055499976,-0.02166101,-0.03139301,0.04182693,-0.020818885,0.010954957,-0.09788385,0.008022182,-0.0006392268,-0.011517488,-0.016671108,0.0007103269,0.11993714,0.047761347,0.04603592,-0.034652386,0.065880746,-0.020382183,-0.023785954,-0.018862573,0.08345605,-0.024359554,-0.043060053,-0.036779806,-0.015457436,-0.025612785,-0.023223989,0.051671114,0.03485986,0.07999302,0.079734266,0.06601179,0.057706535,0.06764428,0.013637296,0.04193446,0.048317146,-0.0019557467,0.106698096,0.00059689215,-0.05856683,0.10029938,0.06358869,0.049112424,0.09914984,0.040303137,-0.01170407,0.061378982,0.061395414,0.029827997,0.11761413,0.114597805,-0.07279317,-0.018996015,-0.099004425,0.0075839832,-0.009213184,-0.005816692,0.0664553,-0.03432171,-0.051268958,-0.050512616,0.08223947,-0.029189631,-0.11882415,0.018588727,0.004718547,-0.011999662,-0.020704074,-0.055349182,0.0138881,-0.002283727,-0.026166337,0.041592795,-5.9660493e-33,0.0027732584,-0.14697075,-0.06825139,0.09735653,0.0065213093,-0.09043365,0.04009372,0.06936787,-0.07249697,0.0006946538,0.031373385,-0.038478598,0.039345026,0.032523498,-0.015288751,0.097338445,-0.026951363,-0.11651126,-0.06912807,0.054203283,-0.0457737,0.031093795,-0.068957016,0.04955592,0.066066824,-0.026540432,-0.0151753845,-0.078136206,-0.12257644,-0.10041546,-0.02395376,-0.018302174,-0.033820856,-0.027126048,-0.057456676,0.046757374,0.017088553,0.027001016,-0.013053394,0.037317205,0.051330816,0.0476096,-0.025529481,-0.033728473,0.03427679,0.015912566,-0.116734125,0.066386916,0.022126082,-0.028874371,0.03734107,0.034051903,-0.01461365,-0.018734004,0.09378762,-0.035759594,-0.054096375,0.068804495,-0.06979585,0.07331263,0.014664017,-0.01438006,-0.0043133995,0.05269717,0.037416894,-0.06750742,0.007864568,-0.011815919,-0.08256545,-0.0041485787,0.049767163,0.008094295,0.0010543495,0.09568427,-0.0085436115,-0.010811496,0.031589907,-0.00071638724,0.001965036,0.049332086,-0.074007414,0.03240105,0.029581705,0.08608283,0.045498595,0.04269553,0.023930758,0.0054241563,-0.0037122807,0.030044027,0.021415247,-0.049466863,-0.12886862,0.036351353,0.0022177107,-3.8379113e-08,0.0008602611,0.024018237,-0.0655583,0.026329665,0.038519755,0.041001044,0.03338665,0.088383175,-0.057021968,0.033934575,0.053829495,-0.022812461,-0.052525748,0.0056563746,0.017115006,0.009386039,0.010102626,-0.034756195,-0.02478354,-0.054226797,-0.029829398,0.08003891,-0.05149248,-0.030754091,0.06439553,-0.05317883,0.065622434,0.028727874,0.054334477,-0.033097863,0.026289336,-0.022087798,0.0025625606,-0.03196879,0.04735988,-0.061339214,-0.025914097,0.078263395,-0.079759896,0.021985415,0.027882526,0.014786013,0.012425547,-0.023377901,-0.011807707,-0.004371339,-0.07857975,-0.015013009,0.07890694,0.027458696,-0.023971956,-0.07001574,-0.040358987,0.04140173,0.03432889,-0.0055097924,0.00040052785,-0.01863178,0.04616672,-0.012028091,0.072636224,-0.06798893,-0.058588896,0.035552092]	2026-01-14 17:57:07.037402+00	2026-01-14 17:57:07.037402+00
cdf3dfed-eb8c-4b07-b9f8-255ecd10e0dd	inline-1768413585030	2c5d1b8e1719ca316db92a88d2528a6670812ef091747d36591f67aa651e0e51	text	decision	Content	7	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.	{}	[0.019177882,-0.018898759,-0.04426501,0.033431903,-0.019915188,-0.05163123,-0.0796716,0.018727584,0.044522785,0.021913847,-0.083917506,0.04763559,-0.01660692,-0.03994266,-0.0015625198,-0.012262027,0.04773461,0.00799227,-0.05572599,-0.09389394,0.03156081,-0.020484721,-0.012421968,-0.06515133,-0.07347579,-0.04839906,-0.03253597,-0.019132616,-0.013932071,-0.040666018,0.008338815,-0.015178445,0.068746336,0.08208873,-0.07696376,0.10315318,0.00095837587,-0.14066522,-0.05912433,-0.008712068,0.030668283,-0.0039098766,-0.06551486,0.045439504,0.03409974,-0.057165746,-0.038693033,0.053132694,0.017657854,-0.015605455,-0.021396061,-0.009125348,-0.027349297,0.016800351,-0.0412514,0.068833545,-0.06790402,-0.053339764,-0.037571084,-0.06371681,0.055114742,-0.09197821,-0.026811017,-0.030393096,-0.0675832,0.0042271977,0.05832411,-0.09083766,0.09243547,-0.030935442,-0.001974594,0.0029972543,-0.06246038,-0.022545941,-0.025775153,0.017578702,0.08875414,0.04349829,0.04091676,-0.036860384,-0.018601447,-0.0057502845,-0.008365264,0.043200668,0.009814699,-0.039770875,0.020196252,-0.058878303,-0.003908051,-0.0061999615,0.0574618,-0.000739722,0.062884666,-0.03674477,-0.016301118,0.009239243,-0.016060824,-0.002385244,0.017394736,-0.0024885177,-0.030840192,0.045471117,0.048310984,0.0706624,-0.1212178,-0.036729246,-0.08422325,0.032396495,-0.0086961,-0.038275305,0.049727116,0.022724468,0.048063606,-0.027111605,-7.341316e-05,0.08510487,-0.07493397,-0.08693954,0.06523588,0.009916491,0.09386403,0.03509409,-0.03499985,-0.09185595,-0.0036730948,-0.03445356,-0.053064167,7.286481e-33,-0.023776557,0.065199256,0.029153524,-0.019542092,-0.033680364,0.04047401,0.026073046,0.07160516,-0.0605181,-0.018026156,-0.07882502,0.09200167,-0.028901968,0.050911732,0.07836532,0.07893845,0.06206762,0.0638576,-0.005010709,-0.01906934,0.07500853,-0.0055499976,-0.02166101,-0.03139301,0.04182693,-0.020818885,0.010954957,-0.09788385,0.008022182,-0.0006392268,-0.011517488,-0.016671108,0.0007103269,0.11993714,0.047761347,0.04603592,-0.034652386,0.065880746,-0.020382183,-0.023785954,-0.018862573,0.08345605,-0.024359554,-0.043060053,-0.036779806,-0.015457436,-0.025612785,-0.023223989,0.051671114,0.03485986,0.07999302,0.079734266,0.06601179,0.057706535,0.06764428,0.013637296,0.04193446,0.048317146,-0.0019557467,0.106698096,0.00059689215,-0.05856683,0.10029938,0.06358869,0.049112424,0.09914984,0.040303137,-0.01170407,0.061378982,0.061395414,0.029827997,0.11761413,0.114597805,-0.07279317,-0.018996015,-0.099004425,0.0075839832,-0.009213184,-0.005816692,0.0664553,-0.03432171,-0.051268958,-0.050512616,0.08223947,-0.029189631,-0.11882415,0.018588727,0.004718547,-0.011999662,-0.020704074,-0.055349182,0.0138881,-0.002283727,-0.026166337,0.041592795,-5.9660493e-33,0.0027732584,-0.14697075,-0.06825139,0.09735653,0.0065213093,-0.09043365,0.04009372,0.06936787,-0.07249697,0.0006946538,0.031373385,-0.038478598,0.039345026,0.032523498,-0.015288751,0.097338445,-0.026951363,-0.11651126,-0.06912807,0.054203283,-0.0457737,0.031093795,-0.068957016,0.04955592,0.066066824,-0.026540432,-0.0151753845,-0.078136206,-0.12257644,-0.10041546,-0.02395376,-0.018302174,-0.033820856,-0.027126048,-0.057456676,0.046757374,0.017088553,0.027001016,-0.013053394,0.037317205,0.051330816,0.0476096,-0.025529481,-0.033728473,0.03427679,0.015912566,-0.116734125,0.066386916,0.022126082,-0.028874371,0.03734107,0.034051903,-0.01461365,-0.018734004,0.09378762,-0.035759594,-0.054096375,0.068804495,-0.06979585,0.07331263,0.014664017,-0.01438006,-0.0043133995,0.05269717,0.037416894,-0.06750742,0.007864568,-0.011815919,-0.08256545,-0.0041485787,0.049767163,0.008094295,0.0010543495,0.09568427,-0.0085436115,-0.010811496,0.031589907,-0.00071638724,0.001965036,0.049332086,-0.074007414,0.03240105,0.029581705,0.08608283,0.045498595,0.04269553,0.023930758,0.0054241563,-0.0037122807,0.030044027,0.021415247,-0.049466863,-0.12886862,0.036351353,0.0022177107,-3.8379113e-08,0.0008602611,0.024018237,-0.0655583,0.026329665,0.038519755,0.041001044,0.03338665,0.088383175,-0.057021968,0.033934575,0.053829495,-0.022812461,-0.052525748,0.0056563746,0.017115006,0.009386039,0.010102626,-0.034756195,-0.02478354,-0.054226797,-0.029829398,0.08003891,-0.05149248,-0.030754091,0.06439553,-0.05317883,0.065622434,0.028727874,0.054334477,-0.033097863,0.026289336,-0.022087798,0.0025625606,-0.03196879,0.04735988,-0.061339214,-0.025914097,0.078263395,-0.079759896,0.021985415,0.027882526,0.014786013,0.012425547,-0.023377901,-0.011807707,-0.004371339,-0.07857975,-0.015013009,0.07890694,0.027458696,-0.023971956,-0.07001574,-0.040358987,0.04140173,0.03432889,-0.0055097924,0.00040052785,-0.01863178,0.04616672,-0.012028091,0.072636224,-0.06798893,-0.058588896,0.035552092]	2026-01-14 17:59:45.039146+00	2026-01-14 17:59:45.039146+00
74127424-1760-47e1-9899-e85a540de669	inline-1768413681185	744db3f670057cb476c893152f5983153cfb33c230e45f4d4b0aa8ce7d5bb7a6	text	decision	Content	5	# Updated Architecture\n\n## Database\nThe platform uses PostgreSQL 14 as the primary database.\nElasticsearch provides semantic search capabilities.\nThe embedding dimension is 768.\n\n## Performance\nAll API responses must complete within 200ms.	{}	[0.08391698,-0.010777362,-0.0021018821,0.026613971,-0.018926496,0.027070327,-0.12805837,0.028142313,0.025391664,0.006704039,-0.07012442,0.013466578,0.012801172,0.013087034,-0.031557653,0.04024981,0.020025624,-0.03135806,-0.025475305,-0.0037206823,0.02822967,-0.015103459,0.011867645,-0.05228068,-0.051973157,-0.0086677745,-0.058366466,0.0064449087,0.00060559873,-0.0225405,0.03383642,-0.012856819,0.07062503,0.14031962,-0.065732285,0.014808858,0.03490629,-0.112876154,-0.055738714,-0.047752846,0.007007055,-0.007599291,-0.068089485,0.02108612,0.02707085,-0.031158727,-0.014314096,-0.006283797,-0.019144151,0.020738823,-0.027418826,-0.033104714,-0.0030521224,0.010821681,0.028463602,0.0038309277,-0.10013149,-0.0025150597,-0.052692823,-0.029618831,0.08809206,-0.071755596,0.004505614,-0.01009053,-0.05148112,-0.009224379,0.0391045,-0.068948686,0.07453467,-0.08550462,-0.0018298503,-0.0103785135,-0.070499726,0.045667816,0.012784155,0.027540017,0.055863507,0.043026302,0.09252684,0.0012938506,-0.011045052,-0.026186489,-0.09018714,0.04669084,-0.016508382,-0.074765064,0.01703075,-0.054346636,-0.020447372,0.026564885,0.07141719,-0.05734268,0.03525992,0.008184222,0.015250178,0.007657095,-0.031304087,-0.016744444,0.02605042,-0.008321306,0.014817261,0.07391082,0.06457795,0.05732878,-0.098037414,0.0027134563,-0.02643965,0.05052689,0.001206436,-0.026441678,0.05577893,-0.004864508,0.020389432,0.0021883058,0.040893015,0.04516551,-0.063904285,-0.074548736,0.09668407,0.030130139,0.05501262,0.028810654,0.0060138977,-0.08838949,-0.044025242,0.060088616,-0.049126256,7.263086e-33,0.06708352,0.06393219,0.03560729,-0.0339295,-0.015513892,0.028468184,0.047627028,0.09371136,-0.08487986,-0.010037183,-0.09746391,0.0957109,0.026847387,0.044943273,0.079382755,0.062507525,0.024643218,0.06937001,0.03341635,0.012451459,0.08676683,0.043505955,-0.037459124,0.03011408,0.022683136,-0.013854872,0.0067386786,-0.074886635,0.020899734,0.0043103932,-0.07947995,-0.0385435,-0.045776032,0.06014151,0.06028243,0.0059779435,-0.04416864,0.0320659,-0.018723844,-0.037498344,0.022691993,0.03366382,0.015338148,-0.05056695,-0.027814945,0.02350898,-0.028338032,-0.020927474,0.019852748,0.009086091,0.058565818,0.053575672,0.021614669,0.039027117,0.116462,0.056311496,0.03967383,0.04911579,0.040992834,0.06149817,-0.03180947,-0.09266316,0.08764048,0.06653402,0.06085895,0.036531985,0.0058217375,-0.0054982016,0.059361942,0.07901957,0.0355332,0.03932371,0.07256352,-0.031210586,-0.020504696,-0.10232256,-0.021448204,-0.064020306,-0.017272925,0.08556225,-0.06733217,-0.032895852,-0.02561691,0.052363116,-0.065375365,-0.07279207,-0.0036195575,-0.028053874,6.866304e-05,-0.044410788,-0.05923244,0.054403223,-0.025443261,-0.0030639993,0.0006614247,-5.5557896e-33,0.0010525085,-0.113098815,-0.028915942,0.068826795,-0.061751448,-0.0650592,0.05596378,0.08754164,-0.10258528,-0.024856592,0.041573443,-0.104514346,0.0883586,-0.05587289,-0.042951647,0.08063484,-0.05373352,-0.10469331,-0.017344745,0.015513001,-0.050115116,0.046695743,-0.047065195,0.067736015,0.064629234,-0.0583146,-0.04287299,-0.10402609,-0.08022679,-0.0334152,0.00598251,-0.06879356,0.033408176,0.023688914,-0.09412966,-0.019997748,0.06388545,-0.04368741,-0.005054573,-0.00901325,-0.005200728,0.06548291,-0.007030158,-0.008724281,0.0147526115,0.055430766,-0.087216,0.023469888,0.041035943,-0.08160887,-0.0052102106,0.012784422,0.028276274,-0.03696274,0.06996305,-0.030196454,-0.07947357,0.08999141,-0.024697732,0.034749784,0.051750083,0.0042285314,0.014488565,0.042418007,0.03630707,-0.022679962,-0.07663593,0.009023922,-0.18236582,-0.01872227,-0.025211824,-0.009346815,0.013935036,0.0792932,-0.009691522,0.0013173926,0.029708503,-0.016791362,0.016529508,-0.011081171,-0.057986893,0.045810994,0.052964997,0.06220601,0.0032290963,0.052637823,0.05964526,0.026985995,-0.072580844,0.06808726,-0.030970309,-0.050938938,-0.1412387,0.02954314,0.014477009,-3.4994528e-08,-0.038319394,0.025355179,-0.03853055,-0.0070691705,0.045304257,0.043316256,0.052673228,0.14423573,-0.008070836,0.039958883,0.04899388,-0.03515157,-0.09416005,0.08792909,0.014845303,-0.052122343,0.05369296,-0.02707181,-0.02298762,-0.006415391,-0.03647077,0.0739587,-0.02202476,-0.07502351,0.08345948,-0.03986165,0.0008768394,0.08624562,-0.0006846244,-0.060105097,-0.010879809,-0.029398328,0.004390525,-0.082000345,0.009343876,0.05449217,-0.0063418876,0.030118413,-0.103235014,-0.006504755,0.053698506,-0.010585661,0.010674281,-0.0348324,0.038184777,-0.036649235,-0.028975327,0.016925892,0.031793058,0.046505213,0.033390615,-0.04359697,-0.003952348,0.020616189,0.043012485,0.031155381,-0.062941335,-0.03575164,0.045484442,-0.010343316,0.100837566,-0.04946469,0.02160523,-0.005954635]	2026-01-14 18:01:21.185832+00	2026-01-14 18:01:21.185832+00
2fa32237-731b-4393-9a06-b914b012db84	inline-1768414156398	2c5d1b8e1719ca316db92a88d2528a6670812ef091747d36591f67aa651e0e51	text	decision	Content	7	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.	{}	[0.019177882,-0.018898759,-0.04426501,0.033431903,-0.019915188,-0.05163123,-0.0796716,0.018727584,0.044522785,0.021913847,-0.083917506,0.04763559,-0.01660692,-0.03994266,-0.0015625198,-0.012262027,0.04773461,0.00799227,-0.05572599,-0.09389394,0.03156081,-0.020484721,-0.012421968,-0.06515133,-0.07347579,-0.04839906,-0.03253597,-0.019132616,-0.013932071,-0.040666018,0.008338815,-0.015178445,0.068746336,0.08208873,-0.07696376,0.10315318,0.00095837587,-0.14066522,-0.05912433,-0.008712068,0.030668283,-0.0039098766,-0.06551486,0.045439504,0.03409974,-0.057165746,-0.038693033,0.053132694,0.017657854,-0.015605455,-0.021396061,-0.009125348,-0.027349297,0.016800351,-0.0412514,0.068833545,-0.06790402,-0.053339764,-0.037571084,-0.06371681,0.055114742,-0.09197821,-0.026811017,-0.030393096,-0.0675832,0.0042271977,0.05832411,-0.09083766,0.09243547,-0.030935442,-0.001974594,0.0029972543,-0.06246038,-0.022545941,-0.025775153,0.017578702,0.08875414,0.04349829,0.04091676,-0.036860384,-0.018601447,-0.0057502845,-0.008365264,0.043200668,0.009814699,-0.039770875,0.020196252,-0.058878303,-0.003908051,-0.0061999615,0.0574618,-0.000739722,0.062884666,-0.03674477,-0.016301118,0.009239243,-0.016060824,-0.002385244,0.017394736,-0.0024885177,-0.030840192,0.045471117,0.048310984,0.0706624,-0.1212178,-0.036729246,-0.08422325,0.032396495,-0.0086961,-0.038275305,0.049727116,0.022724468,0.048063606,-0.027111605,-7.341316e-05,0.08510487,-0.07493397,-0.08693954,0.06523588,0.009916491,0.09386403,0.03509409,-0.03499985,-0.09185595,-0.0036730948,-0.03445356,-0.053064167,7.286481e-33,-0.023776557,0.065199256,0.029153524,-0.019542092,-0.033680364,0.04047401,0.026073046,0.07160516,-0.0605181,-0.018026156,-0.07882502,0.09200167,-0.028901968,0.050911732,0.07836532,0.07893845,0.06206762,0.0638576,-0.005010709,-0.01906934,0.07500853,-0.0055499976,-0.02166101,-0.03139301,0.04182693,-0.020818885,0.010954957,-0.09788385,0.008022182,-0.0006392268,-0.011517488,-0.016671108,0.0007103269,0.11993714,0.047761347,0.04603592,-0.034652386,0.065880746,-0.020382183,-0.023785954,-0.018862573,0.08345605,-0.024359554,-0.043060053,-0.036779806,-0.015457436,-0.025612785,-0.023223989,0.051671114,0.03485986,0.07999302,0.079734266,0.06601179,0.057706535,0.06764428,0.013637296,0.04193446,0.048317146,-0.0019557467,0.106698096,0.00059689215,-0.05856683,0.10029938,0.06358869,0.049112424,0.09914984,0.040303137,-0.01170407,0.061378982,0.061395414,0.029827997,0.11761413,0.114597805,-0.07279317,-0.018996015,-0.099004425,0.0075839832,-0.009213184,-0.005816692,0.0664553,-0.03432171,-0.051268958,-0.050512616,0.08223947,-0.029189631,-0.11882415,0.018588727,0.004718547,-0.011999662,-0.020704074,-0.055349182,0.0138881,-0.002283727,-0.026166337,0.041592795,-5.9660493e-33,0.0027732584,-0.14697075,-0.06825139,0.09735653,0.0065213093,-0.09043365,0.04009372,0.06936787,-0.07249697,0.0006946538,0.031373385,-0.038478598,0.039345026,0.032523498,-0.015288751,0.097338445,-0.026951363,-0.11651126,-0.06912807,0.054203283,-0.0457737,0.031093795,-0.068957016,0.04955592,0.066066824,-0.026540432,-0.0151753845,-0.078136206,-0.12257644,-0.10041546,-0.02395376,-0.018302174,-0.033820856,-0.027126048,-0.057456676,0.046757374,0.017088553,0.027001016,-0.013053394,0.037317205,0.051330816,0.0476096,-0.025529481,-0.033728473,0.03427679,0.015912566,-0.116734125,0.066386916,0.022126082,-0.028874371,0.03734107,0.034051903,-0.01461365,-0.018734004,0.09378762,-0.035759594,-0.054096375,0.068804495,-0.06979585,0.07331263,0.014664017,-0.01438006,-0.0043133995,0.05269717,0.037416894,-0.06750742,0.007864568,-0.011815919,-0.08256545,-0.0041485787,0.049767163,0.008094295,0.0010543495,0.09568427,-0.0085436115,-0.010811496,0.031589907,-0.00071638724,0.001965036,0.049332086,-0.074007414,0.03240105,0.029581705,0.08608283,0.045498595,0.04269553,0.023930758,0.0054241563,-0.0037122807,0.030044027,0.021415247,-0.049466863,-0.12886862,0.036351353,0.0022177107,-3.8379113e-08,0.0008602611,0.024018237,-0.0655583,0.026329665,0.038519755,0.041001044,0.03338665,0.088383175,-0.057021968,0.033934575,0.053829495,-0.022812461,-0.052525748,0.0056563746,0.017115006,0.009386039,0.010102626,-0.034756195,-0.02478354,-0.054226797,-0.029829398,0.08003891,-0.05149248,-0.030754091,0.06439553,-0.05317883,0.065622434,0.028727874,0.054334477,-0.033097863,0.026289336,-0.022087798,0.0025625606,-0.03196879,0.04735988,-0.061339214,-0.025914097,0.078263395,-0.079759896,0.021985415,0.027882526,0.014786013,0.012425547,-0.023377901,-0.011807707,-0.004371339,-0.07857975,-0.015013009,0.07890694,0.027458696,-0.023971956,-0.07001574,-0.040358987,0.04140173,0.03432889,-0.0055097924,0.00040052785,-0.01863178,0.04616672,-0.012028091,0.072636224,-0.06798893,-0.058588896,0.035552092]	2026-01-14 18:09:16.402699+00	2026-01-14 18:09:16.402699+00
71704e2b-6e44-4b92-b94f-62657082a2ef	inline-1768414284643	744db3f670057cb476c893152f5983153cfb33c230e45f4d4b0aa8ce7d5bb7a6	text	decision	Content	5	# Updated Architecture\n\n## Database\nThe platform uses PostgreSQL 14 as the primary database.\nElasticsearch provides semantic search capabilities.\nThe embedding dimension is 768.\n\n## Performance\nAll API responses must complete within 200ms.	{}	[0.08391698,-0.010777362,-0.0021018821,0.026613971,-0.018926496,0.027070327,-0.12805837,0.028142313,0.025391664,0.006704039,-0.07012442,0.013466578,0.012801172,0.013087034,-0.031557653,0.04024981,0.020025624,-0.03135806,-0.025475305,-0.0037206823,0.02822967,-0.015103459,0.011867645,-0.05228068,-0.051973157,-0.0086677745,-0.058366466,0.0064449087,0.00060559873,-0.0225405,0.03383642,-0.012856819,0.07062503,0.14031962,-0.065732285,0.014808858,0.03490629,-0.112876154,-0.055738714,-0.047752846,0.007007055,-0.007599291,-0.068089485,0.02108612,0.02707085,-0.031158727,-0.014314096,-0.006283797,-0.019144151,0.020738823,-0.027418826,-0.033104714,-0.0030521224,0.010821681,0.028463602,0.0038309277,-0.10013149,-0.0025150597,-0.052692823,-0.029618831,0.08809206,-0.071755596,0.004505614,-0.01009053,-0.05148112,-0.009224379,0.0391045,-0.068948686,0.07453467,-0.08550462,-0.0018298503,-0.0103785135,-0.070499726,0.045667816,0.012784155,0.027540017,0.055863507,0.043026302,0.09252684,0.0012938506,-0.011045052,-0.026186489,-0.09018714,0.04669084,-0.016508382,-0.074765064,0.01703075,-0.054346636,-0.020447372,0.026564885,0.07141719,-0.05734268,0.03525992,0.008184222,0.015250178,0.007657095,-0.031304087,-0.016744444,0.02605042,-0.008321306,0.014817261,0.07391082,0.06457795,0.05732878,-0.098037414,0.0027134563,-0.02643965,0.05052689,0.001206436,-0.026441678,0.05577893,-0.004864508,0.020389432,0.0021883058,0.040893015,0.04516551,-0.063904285,-0.074548736,0.09668407,0.030130139,0.05501262,0.028810654,0.0060138977,-0.08838949,-0.044025242,0.060088616,-0.049126256,7.263086e-33,0.06708352,0.06393219,0.03560729,-0.0339295,-0.015513892,0.028468184,0.047627028,0.09371136,-0.08487986,-0.010037183,-0.09746391,0.0957109,0.026847387,0.044943273,0.079382755,0.062507525,0.024643218,0.06937001,0.03341635,0.012451459,0.08676683,0.043505955,-0.037459124,0.03011408,0.022683136,-0.013854872,0.0067386786,-0.074886635,0.020899734,0.0043103932,-0.07947995,-0.0385435,-0.045776032,0.06014151,0.06028243,0.0059779435,-0.04416864,0.0320659,-0.018723844,-0.037498344,0.022691993,0.03366382,0.015338148,-0.05056695,-0.027814945,0.02350898,-0.028338032,-0.020927474,0.019852748,0.009086091,0.058565818,0.053575672,0.021614669,0.039027117,0.116462,0.056311496,0.03967383,0.04911579,0.040992834,0.06149817,-0.03180947,-0.09266316,0.08764048,0.06653402,0.06085895,0.036531985,0.0058217375,-0.0054982016,0.059361942,0.07901957,0.0355332,0.03932371,0.07256352,-0.031210586,-0.020504696,-0.10232256,-0.021448204,-0.064020306,-0.017272925,0.08556225,-0.06733217,-0.032895852,-0.02561691,0.052363116,-0.065375365,-0.07279207,-0.0036195575,-0.028053874,6.866304e-05,-0.044410788,-0.05923244,0.054403223,-0.025443261,-0.0030639993,0.0006614247,-5.5557896e-33,0.0010525085,-0.113098815,-0.028915942,0.068826795,-0.061751448,-0.0650592,0.05596378,0.08754164,-0.10258528,-0.024856592,0.041573443,-0.104514346,0.0883586,-0.05587289,-0.042951647,0.08063484,-0.05373352,-0.10469331,-0.017344745,0.015513001,-0.050115116,0.046695743,-0.047065195,0.067736015,0.064629234,-0.0583146,-0.04287299,-0.10402609,-0.08022679,-0.0334152,0.00598251,-0.06879356,0.033408176,0.023688914,-0.09412966,-0.019997748,0.06388545,-0.04368741,-0.005054573,-0.00901325,-0.005200728,0.06548291,-0.007030158,-0.008724281,0.0147526115,0.055430766,-0.087216,0.023469888,0.041035943,-0.08160887,-0.0052102106,0.012784422,0.028276274,-0.03696274,0.06996305,-0.030196454,-0.07947357,0.08999141,-0.024697732,0.034749784,0.051750083,0.0042285314,0.014488565,0.042418007,0.03630707,-0.022679962,-0.07663593,0.009023922,-0.18236582,-0.01872227,-0.025211824,-0.009346815,0.013935036,0.0792932,-0.009691522,0.0013173926,0.029708503,-0.016791362,0.016529508,-0.011081171,-0.057986893,0.045810994,0.052964997,0.06220601,0.0032290963,0.052637823,0.05964526,0.026985995,-0.072580844,0.06808726,-0.030970309,-0.050938938,-0.1412387,0.02954314,0.014477009,-3.4994528e-08,-0.038319394,0.025355179,-0.03853055,-0.0070691705,0.045304257,0.043316256,0.052673228,0.14423573,-0.008070836,0.039958883,0.04899388,-0.03515157,-0.09416005,0.08792909,0.014845303,-0.052122343,0.05369296,-0.02707181,-0.02298762,-0.006415391,-0.03647077,0.0739587,-0.02202476,-0.07502351,0.08345948,-0.03986165,0.0008768394,0.08624562,-0.0006846244,-0.060105097,-0.010879809,-0.029398328,0.004390525,-0.082000345,0.009343876,0.05449217,-0.0063418876,0.030118413,-0.103235014,-0.006504755,0.053698506,-0.010585661,0.010674281,-0.0348324,0.038184777,-0.036649235,-0.028975327,0.016925892,0.031793058,0.046505213,0.033390615,-0.04359697,-0.003952348,0.020616189,0.043012485,0.031155381,-0.062941335,-0.03575164,0.045484442,-0.010343316,0.100837566,-0.04946469,0.02160523,-0.005954635]	2026-01-14 18:11:24.644646+00	2026-01-14 18:11:24.644646+00
555b21c5-e167-4634-8ced-cfe541301183	inline-1768415003680	0f237d358473ec1c7be458c03a6ac2ca90ca3a4ae83e42f8291b022a1ff4d5bf	text	reference	Content	5	Test document with a few claims. PostgreSQL is the database. Redis is the cache.	{}	[-0.047744904,-0.017868739,-0.13644251,0.057053193,-0.013372681,-0.07779018,-0.012832037,0.005063173,0.038735654,0.047461256,0.00038560876,0.092508234,-0.005549435,-0.07399491,-0.027336132,-0.016045053,0.08041792,-0.04511591,0.04783745,-0.07570851,-0.015330722,-0.029173097,-0.01737607,0.029534735,0.02295783,-0.041200824,-0.057359483,0.041403133,-0.04702351,-0.09929678,0.0015910515,0.01668765,0.032034215,0.03495935,0.032584105,0.08664325,0.04412073,-0.10671087,-0.0389511,0.0015319336,0.016313937,-0.04041701,-0.034053057,0.100386016,0.048741892,0.012338302,-0.04006438,0.06731675,-0.029933553,0.016188452,-0.021562565,0.012525402,-0.03506217,0.032352682,-0.01769071,0.072103545,0.025456162,0.0014225736,-0.0626317,0.016399253,0.024095109,-0.024904393,-0.055198807,0.071972325,-0.06621365,0.07186916,0.019794911,-0.07504405,0.10159421,-0.14704174,-0.032191157,0.017872926,-0.04991942,-0.01640474,0.008442472,0.020715797,0.060713124,-0.048032057,0.034113996,-0.110960804,-0.03592302,0.018717673,0.0022684957,0.017383773,0.00325023,0.033857524,0.09776776,-0.0029265627,-0.0060652336,-0.0014875121,0.07640924,0.015938561,-0.0034763173,0.011931357,-0.1009594,0.015644934,0.04035284,0.015279581,0.08438605,0.0151563855,0.04272327,0.05448901,0.07540883,0.011836891,-0.09919093,-0.009412521,-0.009253322,-0.051931586,-0.012203727,-0.064500555,0.010385492,-0.017051216,-0.041673735,-0.030197771,-0.017623043,-0.003242932,-0.09262074,-0.02278996,-0.06359837,-0.052069325,0.08008614,0.05880183,-0.026576944,-0.10673705,-0.03923464,-0.036248323,-0.011524623,-1.3039435e-33,0.009155358,0.0009977351,0.0389071,0.04795372,0.0006967087,0.012019621,-0.022745,0.08794395,-0.08399524,0.04994791,0.01661888,0.062971435,-0.051221836,0.03511211,0.052355796,0.118867986,-0.022393547,0.06929742,0.051894672,0.012549696,0.04568692,0.026948271,-0.015860185,-0.030534243,0.07683793,0.05354186,0.01101068,-0.00063659565,-0.019699514,-0.014827215,0.038316313,-0.026981436,-0.022935864,0.08276837,0.027071198,0.08180557,-0.0065732943,-0.03155398,-0.057502605,0.029024087,-0.018537909,0.049050085,0.021007668,0.020780833,-0.004940104,-0.06895797,-0.065221466,-0.02308783,0.103693426,0.06465518,-0.009893066,0.026607336,0.09409402,0.0663983,0.0041158367,0.03212407,0.035806965,-0.010059638,0.04875202,0.0950865,0.02014001,-0.003023886,-0.04315739,0.0067319865,-0.002580272,0.0824846,-0.021954592,-0.069364056,0.11735783,0.02743739,-0.0029735707,0.025272133,0.0839296,-0.05012474,-0.02147574,-0.073003784,-0.11583732,0.034525912,-0.0827311,0.012056064,0.02071923,-0.06613918,-0.08304509,0.0975253,-0.10402507,0.013527288,-0.024833372,0.008606979,-0.007309412,-0.016904077,-0.01855424,0.060276207,0.020517867,-0.016155297,0.09866746,-7.857494e-35,-0.033945594,-0.10200489,-0.06110145,0.1024321,0.022935059,-0.03697849,0.041434158,0.032994583,-0.0741054,0.010965054,0.04198466,-0.054856185,-0.02725756,0.011500799,0.0010381226,0.023053262,-0.011442189,-0.103328876,-0.07674775,0.059771616,-0.06181998,0.09927605,0.049169976,-0.0072913,0.038082004,-0.008447053,-0.059589323,-0.103709504,-0.08726063,-0.023990778,0.036412857,0.03881082,-0.12973578,-0.027454838,-0.010930512,-0.039853215,0.031518243,0.015012654,-0.010782388,0.01640051,0.061426252,0.06313318,0.03604849,-0.009648195,-0.0034928897,0.06583556,-0.055544063,0.0023363435,0.03595036,-0.03526117,0.05397152,-0.015903581,-0.0041846405,-0.033920627,0.062238783,0.029819313,-0.11961058,0.0025945723,-0.032691263,0.06832684,0.01893363,0.03818451,-0.058400765,0.09445692,-0.03672113,-0.03534092,0.0021972845,0.009327908,0.007544466,-0.022957252,0.036493387,0.017876454,0.014266948,0.004749351,0.0152815385,-0.027545776,-0.04489747,-0.04114515,-0.04565032,0.055582467,0.060905218,-0.03481812,-0.0010273454,0.046815183,0.02885196,-0.038492445,-0.059048865,-0.0801708,-0.04070945,0.021694187,-0.003909449,0.0014026529,-0.12211973,0.011897832,-0.03394635,-2.1782322e-08,-0.009486884,0.0094933035,0.02629645,-0.025504282,0.001221965,0.0027714027,0.07194216,0.07781571,-0.05461863,-0.0026252824,0.052619625,-0.05117646,-0.047696155,-0.031377066,-0.0035501323,-0.03070109,0.033117276,0.0040909164,-0.025840513,-0.0098683555,-0.0605865,0.048816074,-0.02366572,-0.044371568,0.02419053,0.013310319,0.10159103,0.051336225,0.050954442,-0.05290069,0.086467914,-0.0002283142,0.033094518,-0.045807917,0.112346426,0.011457069,0.025070503,0.11225393,-0.015442882,-0.03200601,-0.08220036,0.0221965,0.040634785,0.020641478,-0.019107433,-0.046109904,-0.11328746,-0.039693482,0.045975473,-0.046697818,-0.04703321,-0.09492504,0.004830601,0.048963994,-0.039336715,-0.02726472,0.07037312,-0.00834697,0.000594163,-0.0068763644,0.082638085,-0.03635063,0.03813341,0.04636609]	2026-01-14 18:23:23.68555+00	2026-01-14 18:23:23.68555+00
bb5b5b7d-3921-4036-98b2-a00d334568f5	inline-1768415065729	80c1f0cfe763362eb646b05aa40bc5cc8c9c3d3949b9a19c87fd47b858155ca0	text	reference	Content	5	# System Architecture\n\nThe platform uses PostgreSQL 15 as the primary database for structured data.\nRedis provides caching with a 1-hour TTL for session data.\nAll API responses must complete within 500ms for optimal user experience.\n\n## Database Layer\n- PostgreSQL handles ACID transactions\n- Connection pooling via PgBouncer\n- Automatic failover with streaming replication\n\n## Caching Strategy\n- Redis cluster for high availability\n- Write-through cache for user sessions\n- Cache invalidation on data updates	{}	[-0.029709885,-0.022140086,-0.06901228,0.004006857,-0.091975346,-0.0726436,-0.0031662018,0.009898265,0.049154736,0.024079205,-0.060176235,0.08283822,-0.043345228,-0.07747726,0.04011345,-0.023982344,0.12055628,-0.0059777433,-0.060655847,-0.14431024,-0.016421992,-0.05945614,-0.03118614,0.037347414,-0.054058645,-0.021065798,-0.02784849,-0.05062777,-0.029013338,-0.06711582,-0.033613816,-0.0024249633,0.036096837,0.05047067,-0.06990464,0.099598475,0.045637395,-0.10564246,-0.03965831,-0.05111285,0.017008346,-0.020484291,-0.075607516,0.0791229,0.015142715,-0.024048379,-0.06028357,0.071528785,-0.029929537,-0.0015702719,-0.006898111,0.036964618,0.022965275,0.068267055,-0.040421262,0.090096384,-0.028545655,-0.012509782,-0.027353115,0.025445608,0.015219433,-0.061468113,-0.051086843,0.008768078,-0.07090935,0.01358369,0.07937049,-0.07976684,0.10377377,-0.02670543,-0.049890384,0.009794592,-0.060139753,-0.04123701,-0.07400718,-0.035470746,0.06328419,-0.010199234,-0.008356835,-0.049452763,-0.024639482,0.060980376,0.02248143,0.04121403,-0.021226987,-0.047347665,0.0026820865,0.034608256,-0.05170117,-0.014230396,0.01880778,0.09165821,0.05807186,-0.043161787,-0.0789451,0.02446752,0.02026691,-0.025260812,0.052342292,0.003991799,0.014646279,0.06951893,0.038882397,0.07007517,-0.10527064,-0.050774656,-0.08520499,0.0011027611,-0.056213535,-0.009490127,0.012536789,0.011481524,0.02415535,-0.037265018,0.0020948811,0.052985985,-0.099147886,-0.063675426,0.017608289,-0.028171072,0.09313375,0.0015853298,-0.020823017,-0.08591866,0.025828404,-0.09699899,-0.0075998497,6.449111e-33,-0.031085255,0.037628744,0.03697521,-0.015392791,-0.029257081,0.005514507,-0.0033140026,0.01813232,-0.037988525,-0.0101532005,-0.016454611,0.02596585,-0.049080532,0.038941137,0.05856745,0.07048293,0.038401343,0.047395002,0.055563748,-0.026016776,0.039542563,0.011971161,0.0058269077,0.0012348327,0.07376715,0.034466032,-0.0012042786,-0.05520059,-0.005314208,-0.003511253,0.036913864,-0.006013955,-0.009288369,0.09603232,0.04247556,0.05505415,0.006372238,-0.0015922885,0.025715495,-0.0122916475,-0.01476923,0.11344101,-0.04274721,-0.00042358274,-0.033905335,-0.01565459,-0.028072089,0.0012266374,0.024319991,0.039514404,0.034653,0.05776982,0.04552545,0.06590249,0.014430334,0.026128799,0.029362272,-0.02003114,-0.010757053,0.15104586,0.02881174,-0.08036848,-0.009111042,0.02858275,0.012594559,0.0996773,0.023789825,-0.03262942,0.06811802,0.033847127,-0.03743813,0.110799655,0.09326252,-0.040465675,-0.03598467,-0.048529983,-0.00045584494,0.0013545583,-0.017294483,0.08137374,-0.014664958,-0.05696596,-0.09936289,0.105219714,-0.05451758,-0.06330941,0.04745982,0.033688545,-0.022227217,0.004462609,-0.07144386,-0.042985577,0.08827917,-0.024808196,0.04820897,-6.581042e-33,0.018905316,-0.1229301,-0.06056986,0.11075194,0.035679746,-0.049382858,0.019885799,0.02729683,-0.03996251,-0.013683151,-0.02021084,-0.0013178568,0.05612499,0.044900637,-0.017827088,0.044204652,0.021284688,-0.10287919,-0.08375215,0.04559909,-0.019769643,0.035913933,-0.008207807,-0.0019072645,0.072246045,-0.023997707,-0.087768584,-0.08472169,-0.06725826,-0.05937439,0.009079168,-0.0239773,0.0037648766,-0.06580814,-0.006018802,0.016446108,0.007537501,0.038177542,-0.024484834,0.011054053,0.0722138,0.009963018,-0.020349408,-0.050175067,0.030367931,0.061963823,-0.16479912,0.03917188,-0.08653881,0.019148033,0.043746244,0.003214036,-0.04532108,-0.045298494,0.103136174,-0.041375715,-0.049773213,0.038911358,-0.048493084,0.033572435,0.0012588712,-0.060545478,-0.011064848,0.0798316,0.021345159,-0.06268808,0.04535671,-0.036367565,0.007969462,0.014665379,0.066978626,0.007571448,0.019365367,0.08136201,-0.0076322816,-0.03454324,-0.053570777,-0.06885843,-0.017837482,0.07847079,-0.0854101,0.034719698,0.005669293,0.082959644,0.068407394,-0.00959183,0.0052880556,-0.036119938,0.023827132,-0.004801325,-0.006068628,-0.01955819,-0.13613886,0.06216042,-0.034175016,-3.8598937e-08,0.02400218,-0.028530437,-0.038180895,0.031140393,0.049294617,0.015912302,0.030944403,0.05563766,-0.006334646,0.039836932,0.076556906,-0.006259024,-0.0009024998,-0.062008906,0.016490594,0.06381448,0.04834029,-0.04420753,-0.020449135,-0.052044753,-0.03740487,0.054685373,-0.06993883,-0.053906493,0.04446198,-0.01799881,0.09772887,0.04341241,0.034381516,-0.031742867,0.057962917,-0.0448939,0.06598267,-0.02894394,0.11355293,-0.06658309,-0.02429118,0.10644805,-0.0091726845,-0.0025167004,-0.024370996,0.0066455505,0.01577891,0.019473525,-0.014592046,0.005460173,-0.13073687,0.011605746,0.050168075,0.030907769,-0.03181728,-0.035997514,-0.019631054,0.02699332,0.013105749,0.014396894,0.053627998,0.010634822,0.084602185,-0.06254652,0.06002443,-0.0061902734,-0.050255377,-0.0044375686]	2026-01-14 18:24:25.729566+00	2026-01-14 18:24:25.729566+00
d1aec79c-878f-4ab4-98aa-f53ce6d80178	inline-1768450381196	45633bbf8f6499da97f7a8be4a0b223c1ae86b7af125fb7ebe06173508a11ef6	text	guide	Content	7	This is a test document about the L02 Agent Runtime Layer. It provides core services for agent execution.	{}	\N	2026-01-15 04:13:01.20404+00	2026-01-15 04:13:01.20404+00
\.


--
-- Data for Name: entities; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.entities (id, canonical_id, name, type, aliases, properties, embedding, created_at) FROM stdin;
\.


--
-- Data for Name: evaluations; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.evaluations (id, agent_id, task_id, evaluation_type, score, metrics, feedback, created_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.events (id, event_type, aggregate_type, aggregate_id, payload, metadata, created_at, version) FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.feedback (id, claim_id, conflict_id, document_id, feedback_type, content, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: feedback_entries; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.feedback_entries (id, agent_id, task_id, feedback_type, rating, content, metadata, processed, created_at) FROM stdin;
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.goals (id, goal_id, agent_id, agent_did, goal_text, goal_type, status, constraints_max_token_budget, constraints_max_execution_time_sec, constraints_max_parallelism, constraints_deadline_unix_ms, constraints_priority, constraints_require_approval, constraints_allowed_agent_types, constraints_forbidden_tools, constraints_cost_limit_usd, metadata, parent_goal_id, decomposition_strategy, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: metrics; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.metrics (id, metric_name, metric_type, value, "timestamp", labels, agent_id, tenant_id, created_at) FROM stdin;
\.


--
-- Data for Name: model_usage; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.model_usage (id, request_id, agent_id, agent_did, tenant_id, session_id, model_provider, model_name, model_id, input_tokens, output_tokens, cached_tokens, total_tokens, latency_ms, cached, cost_estimate, cost_input_cents, cost_output_cents, cost_cached_cents, finish_reason, error_message, response_status, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.plans (id, plan_id, goal_id, agent_id, tasks, dependency_graph, status, resource_budget, created_at, validated_at, execution_started_at, execution_completed_at, signature, decomposition_strategy, decomposition_latency_ms, cache_hit, llm_provider, llm_model, total_tokens_used, validation_time_ms, execution_time_ms, parallelism_achieved, tags, metadata, error, completed_task_count, failed_task_count) FROM stdin;
\.


--
-- Data for Name: provenance; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.provenance (id, document_id, event_type, details, "timestamp") FROM stdin;
2f649657-7bb3-4790-8edc-c90a0e3b1e53	2e560d15-2a8a-45dd-a1e3-23b5b821c13a	deprecation	{"reason": "Test deprecation - verifying pgvector migration", "archive": false, "references_migrated": 0}	2026-01-14 14:33:33.45+00
4346dfb7-fa6f-47a2-883c-a8ef5eda5831	32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	deprecation	{"reason": "Consolidated into unified authentication specification", "archive": false, "references_migrated": 0}	2026-01-14 17:06:32.394+00
\.


--
-- Data for Name: quality_scores; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.quality_scores (id, score_id, agent_id, agent_did, tenant_id, "timestamp", overall_score, assessment, data_completeness, cached, dimensions, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: rate_limit_events; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.rate_limit_events (id, event_id, "timestamp", consumer_id, tenant_id, rate_limit_tier, endpoint, tokens_requested, tokens_remaining, tokens_limit, window_start, window_end, exceeded, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: saga_executions; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.saga_executions (id, saga_id, saga_name, status, started_at, completed_at, steps_total, steps_completed, steps_failed, current_step, context, compensation_mode, error_message, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: saga_steps; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.saga_steps (id, step_id, saga_id, step_name, step_index, service_id, status, started_at, completed_at, request, response, error_message, compensation_executed, compensation_result, retry_count, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sections; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.sections (id, document_id, header, content, level, section_order, start_line, end_line, embedding, created_at) FROM stdin;
02ded678-f1b0-4d96-8508-1ef91d8c7deb	9346f52b-5a4e-4289-ad95-b99b5be260f9	Content	# Test Specification Document\n\n## Overview\nThis is a test document for the MCP Document Consolidator.\n\n## Architecture\nThe system uses PostgreSQL with pgvector for embeddings storage.\nRedis is used for caching and session management.\n\n## Key Components\n1. **Embedding Pipeline**: Uses sentence-transformers for generating embeddings\n2. **Claim Extractor**: Extracts factual claims from documents\n3. **Conflict Detector**: Identifies contradictions between documents\n\n## Configuration\n- Database: PostgreSQL 16 with pgvector extension\n- Vector dimensions: 384\n- Similarity threshold: 0.8\n\n## Notes\nThis document was created for testing the ingest_document tool.\n	1	0	1	22	\N	2026-01-14 14:01:18.008086+00
07d81636-bf4d-4066-aa91-462ba6bb85f0	bf1cdfed-8414-467f-b17e-419c62126d61	Content	# Test Specification Document\n\n## Overview\nThis is a test document for the MCP Document Consolidator.\n\n## Architecture\nThe system uses PostgreSQL with pgvector for embeddings storage.\nRedis is used for caching and session management.\n\n## Key Components\n1. **Embedding Pipeline**: Uses sentence-transformers for generating embeddings\n2. **Claim Extractor**: Extracts factual claims from documents\n3. **Conflict Detector**: Identifies contradictions between documents\n\n## Configuration\n- Database: PostgreSQL 16 with pgvector extension\n- Vector dimensions: 384\n- Similarity threshold: 0.8\n\n## Notes\nThis document was created for testing the ingest_document tool.\n	1	0	1	22	\N	2026-01-14 14:02:01.697656+00
1cc9c443-3e50-48fb-8837-c14bd8c6e1c4	3a7a2b80-7bb3-497c-b93e-fcda657829b8	Content	# Test Specification Document\n\n## Overview\nThis is a test document for the MCP Document Consolidator.\n\n## Architecture\nThe system uses PostgreSQL with pgvector for embeddings storage.\nRedis is used for caching and session management.\n\n## Key Components\n1. **Embedding Pipeline**: Uses sentence-transformers for generating embeddings\n2. **Claim Extractor**: Extracts factual claims from documents\n3. **Conflict Detector**: Identifies contradictions between documents\n\n## Configuration\n- Database: PostgreSQL 16 with pgvector extension\n- Vector dimensions: 384\n- Similarity threshold: 0.8\n\n## Notes\nThis document was created for testing the ingest_document tool.\n	1	0	1	22	\N	2026-01-14 14:02:55.980435+00
90193616-fce2-4ee5-a24b-d98c7639324c	184e9500-3652-4baa-8897-678974eceb64	Content	# pgvector Test Document\n\n## Overview\nThis document tests the pgvector embedding pipeline.\n\n## Purpose\nWe are validating that embeddings are generated correctly and stored in PostgreSQL using pgvector.\n\n## Technical Details\n- Vector dimensions: 384\n- Model: all-MiniLM-L6-v2\n- Storage: PostgreSQL with pgvector extension\n	1	0	1	13	[0.044021618,-0.034307875,0.004164182,0.028646426,-0.004893963,0.066490784,-0.17046177,0.020512525,-0.018573327,-0.027354034,-0.029502515,0.041813407,0.00010644553,-0.05063667,-0.090092376,0.044196367,0.057202183,0.05191621,-0.022910245,0.019769574,-0.06595312,-0.027548932,-0.004933531,-0.016126169,0.0054034446,-0.02450014,-0.06261957,0.025262397,0.027345689,-0.013867222,0.083124354,0.025635792,-0.011451332,0.11339403,-0.005961402,0.08290653,0.032397315,-0.0629881,-0.062208176,-0.0041949945,0.06282287,-0.0006007635,-0.083734155,0.054038808,-0.009660556,-0.059649304,-0.07791371,-0.046375133,-0.09075574,-0.042934,-0.018004213,-0.0047305212,-0.017910725,-0.014884598,-0.099287905,-0.034065176,-0.05583168,-0.05534182,0.07652604,0.03407608,-0.015197323,-0.048439734,0.0900225,-0.01093883,-0.026858969,-0.03356639,-0.004001803,0.0037357507,-0.018062165,-0.022512777,-0.035813164,0.06860972,-0.13566378,0.011328313,-0.042089805,0.030134285,0.046246964,-0.008639419,0.058786973,-0.039143696,-0.0071883774,-0.052373167,-0.034764457,-0.012123723,-0.06728319,0.028635962,0.0039390437,-0.05118056,-0.035811715,-0.016314788,0.044057813,0.019055257,-0.02145806,0.076844916,0.04020726,-0.047192823,0.050670404,0.035614874,0.08272911,-0.04488267,0.056987047,0.0216896,0.07062111,0.031214839,-0.03851618,-0.044179324,-0.020925265,0.0054161493,-0.013742426,-0.056958903,0.026325056,0.054914653,-0.0070660147,-0.008176808,0.05585289,-0.0130213015,-0.062223576,-0.051921573,0.053928994,-0.015794823,0.039110083,0.07408795,0.003481191,0.002522027,-0.04502521,-0.02462877,-0.00044089826,6.569085e-33,-0.018623438,-0.0655839,0.1323039,0.07064226,0.016532186,0.044617154,0.042162344,0.069653004,-0.049851157,0.027215589,-0.100794844,-0.030482478,-0.012363575,0.08503251,0.03681019,0.051871657,-0.03735607,0.002988499,-0.017148085,-0.0035403613,0.04052745,0.012270879,-0.011426864,-0.017636804,-0.026793983,0.022999465,0.04038602,-0.11546146,-0.0596403,0.0020185774,-0.11066956,-0.030843351,0.038310092,0.0778701,0.043797616,0.017511925,0.079233535,0.018660907,-0.14433125,-0.06552443,0.06279344,-0.00342677,-0.005929683,-0.08042003,-0.06501698,0.03188039,0.100861885,-0.025086587,-0.027180854,-0.038723316,0.02699551,0.061986703,-0.04097559,0.0059072976,0.034329847,0.007796662,-0.0029696943,-0.008186454,0.045045827,-0.00209005,-0.022605658,0.044084698,0.0178387,-0.006004943,-0.0381984,-0.025929881,0.007866913,-0.0067481464,0.050933346,0.0796012,0.0044956882,0.071907476,-0.0315103,-0.019251335,0.06317009,-0.036585648,-0.044312626,-0.024006974,0.012335105,0.05109054,-0.018335942,-0.03779686,-0.0014052878,-0.030114954,-0.03968592,-0.11370449,0.0066772136,-0.046452135,-0.008931987,0.04297984,-0.0144715365,0.032781776,-0.010088028,0.046299506,0.07973389,-8.842319e-33,-0.033842288,-0.023701522,-0.05435696,0.079642795,-0.035449937,-0.05401062,0.018532615,0.050506637,-0.06753589,-0.026030459,-0.012091787,-0.019948492,0.07661354,-0.010277126,0.05403985,0.029004049,-0.110940315,-0.09005497,0.018613547,0.020554377,-0.030867117,0.018679067,0.008290949,0.062286995,0.11808627,-0.0054218546,0.07727103,-0.10171498,-0.00027791545,-0.04720853,0.05350037,-0.00695324,-0.030516488,0.056515634,-0.08883581,-0.02913913,-0.016205894,-0.05319195,0.07609248,-0.029235996,-0.0340351,0.09073087,-0.01391196,-0.011753399,0.005760578,0.010256975,0.061382964,-0.026259044,0.09498973,-0.0417242,-0.01971892,-0.02941587,-0.05218271,0.034277953,0.07295942,-0.008971167,-0.09433151,-0.018461162,0.009825576,-0.047011197,-0.0149637675,-0.012588638,-0.016287275,-0.099668734,-0.020914923,-0.0744469,0.051722962,0.036845673,-0.014780534,-0.07655661,0.07428123,0.015812129,-0.00073306053,0.06903209,0.016504304,-0.051098917,0.002162631,0.0678496,0.057439283,-0.0076207127,0.01615707,0.02721551,0.04823479,0.059440035,0.0900292,-0.03872618,0.047491446,0.07116905,-0.08338214,0.0865915,0.020539692,0.06935892,-0.09990408,0.07572184,0.006302698,-4.3263437e-08,-0.06619451,-0.033069856,-0.09000437,-0.038436014,-0.049442284,-0.08310981,0.11566468,0.069554396,-0.014011695,0.058473933,0.000670144,-0.045897536,-0.042877555,0.007023531,0.002021141,-0.060040876,-0.016618667,-0.029569251,0.025035864,0.0017581122,-0.063634455,0.02428854,-0.01666338,0.039877847,-0.03946005,-0.04771046,0.060552686,0.052905682,0.1367553,-0.040339097,-0.003594417,0.04332225,-0.014014118,-0.08435983,0.015903559,0.071768135,0.082584605,0.0020919102,0.03536992,-0.009044961,-0.044086628,-0.06608119,0.02856693,-0.08734692,-0.029160982,-0.0079814475,-0.036351223,0.0029626223,-0.030133573,0.08933831,-0.01995612,-0.077366166,-0.06173174,0.09570158,0.085432455,-0.014948845,-0.020385297,-0.019816484,0.0097639505,-0.10009582,0.019694597,0.06634521,0.046345256,-0.011343128]	2026-01-14 14:12:47.113884+00
b780b47b-a7da-4ac8-8fe7-f7cc8d0c41a4	3c76eb98-b4d6-4588-b390-e51ab7274862	Content	# Database Architecture Guide\n\n## Overview\nThis document describes PostgreSQL database architecture best practices.\n\n## Connection Pooling\nUse PgBouncer or built-in connection pooling for optimal performance.\nConfigure max_connections based on available memory.\n\n## Indexing Strategy\nCreate B-tree indexes for equality and range queries.\nUse GIN indexes for full-text search and JSONB columns.\nConsider partial indexes for frequently filtered subsets.	1	0	1	13	[0.037663963,0.016162347,-0.048098125,0.022914331,-0.14000155,0.044706143,0.015760949,-0.012933741,-0.051111042,-0.03757773,-0.07450653,0.05621613,-0.03501358,-0.043574344,-0.029308852,0.09776041,0.081443705,0.055143416,-0.02871935,-0.09776078,-0.006443992,-0.07539528,-0.009821041,0.01753493,-0.101507984,-0.0021935927,0.0010468741,-0.03527803,0.033280563,0.023343336,-0.05015812,0.006819744,0.0032354407,0.08251066,-0.15540196,-0.006447923,0.011665287,-0.09100527,-0.0042641833,-0.042528607,0.032753035,0.038509138,-0.05146997,0.05717378,-0.002775175,0.03310861,-0.03847387,0.030344239,0.03264575,0.007901514,-0.058788244,0.026605023,-0.015153136,-0.0010794887,-5.3060616e-05,0.016052721,-0.07064574,-0.05901542,0.001216926,0.04582064,0.04422859,-0.015964141,-0.05045548,-0.027295846,-0.06890897,-0.022256179,0.07572805,0.016999086,0.0918972,-0.02510393,0.08186069,0.12204206,-0.13897556,0.021870093,-0.1250067,0.05414963,0.018486036,-0.05930128,-0.025305195,0.01210013,-0.034681585,0.0036357108,0.03578195,0.027203508,-0.041920103,-0.09858611,-0.0426839,-0.07098479,-0.0063444623,0.037931584,0.03640844,0.0011521555,0.038066383,-0.06993443,0.03509653,0.04546405,0.007911065,-0.037021585,0.04216283,-0.015890358,0.015927238,0.020768825,0.08535061,0.07403001,-0.08902787,0.0033095425,-0.041080944,-0.001521011,-0.02083276,-0.03626243,0.038498305,0.05982016,-0.023962468,-0.021143828,0.047809545,0.007601922,-0.0021610742,-1.9591527e-05,0.06617032,0.09709318,0.009146524,0.020982562,0.014303773,-0.04083855,-0.008694002,-0.00071419834,-0.06335658,6.829762e-33,0.018685922,0.024187572,0.064741716,-0.028954448,-0.10876584,-0.029972417,0.05006809,0.027661512,-0.048282843,0.03591109,-0.051951118,0.037404817,-0.06653974,0.02674337,0.10321025,-0.04446226,0.0116691645,0.065732375,0.06569822,-0.058321938,0.020740505,-0.039310608,-0.010132447,0.06168451,0.08370871,-0.046779968,0.008968849,-0.039037514,-0.009548617,0.011110097,-0.02844129,-0.000510873,-0.007720859,0.052210767,0.08699943,0.055980485,-0.054212797,0.03974258,0.0032780257,-0.042698923,-0.04396392,0.023519635,-0.011318814,-0.0748549,0.0035069005,0.046550807,-0.032750987,-0.007836857,-0.040041246,0.04112873,0.03441771,0.025009813,-0.050201163,0.16538368,0.055974487,0.0055626454,0.066784136,0.044478077,0.032624368,0.16862127,0.043580987,-0.07974299,-0.037922967,0.06481629,0.059669226,0.037005395,-0.07154952,0.012472708,0.057579286,0.0026308752,0.013627071,0.030205783,0.045600943,0.0014236488,-0.06804121,-0.025591055,-0.04863907,0.027396863,-0.034176286,-0.0077687716,-0.020037197,-0.0002914631,0.032782998,0.022264576,-0.07601625,-0.0063238842,0.06439597,0.013071592,-0.07459298,-0.027053552,-0.050004896,0.09533498,0.097277574,-0.057271726,0.033559304,-7.5227546e-33,-0.0010978745,-0.13185617,0.057411954,0.06086446,0.04758753,-0.07209758,0.04250194,-0.070767835,0.038764168,-0.029692307,-0.030045362,0.0042103664,0.106591366,-0.05529931,-0.055660076,0.040918335,-0.047815524,-0.030326277,-0.026994973,0.07617197,-0.076385304,0.05822648,0.05441257,-0.0069882753,0.038415022,-0.078060344,-0.04844364,-0.075852804,-0.031149505,0.01811663,-0.029302096,-0.01850787,0.06723456,-0.047928803,-0.04200957,-0.006723373,0.037821915,-0.028223531,0.070638224,0.06885246,0.0013156396,0.07818942,0.032397967,0.0020133986,0.012471171,0.037929475,-0.15336712,-0.026774345,-0.064761944,-0.006127279,-0.098225094,-0.005101101,-0.018653145,-0.031094192,0.068942204,-0.07903871,-0.04159453,0.01997641,-0.015283047,0.00411129,-0.041278094,0.01984285,-0.013221102,0.047771204,0.0004946108,-0.09616086,0.012666187,-0.027338527,0.013220789,-0.055786435,-0.025966698,0.014379225,0.054384228,0.06876589,-0.059210014,-0.03189393,-0.020891182,-0.008323009,0.018487394,0.08767639,-0.07262044,0.10825175,-0.03277042,0.09549738,0.014013311,0.006831266,0.01894973,-0.034828484,-0.006500062,-0.0046536764,-0.048189815,-0.024253024,-0.054257836,-0.0026248966,-0.01848425,-3.7310745e-08,-0.03977234,-0.047649346,-0.053722806,0.009414296,0.07842738,-0.04579753,-0.05025483,0.11058357,0.00041567537,0.0053517395,0.07952022,-0.01002829,-0.045666702,0.054518264,0.019625358,-0.043576125,0.03325919,-0.050569393,-0.03954952,0.03378317,-0.015468889,0.048269454,0.0010296792,0.022971626,0.068554185,-0.056617014,0.003878837,-0.014192801,-0.00018149389,0.034509268,0.012460856,-0.035814457,-0.01539514,-0.025895135,0.085589044,0.016374864,0.011633603,0.069305435,-0.10293644,0.040448815,0.0424364,-0.035009567,0.040921386,0.01328063,0.02848726,-0.009852583,-0.03541222,0.031855125,0.009774099,0.044534724,-0.038011704,-0.035049297,-0.031759173,0.0032912937,0.09703864,0.0034741317,-0.023010708,0.035557307,0.05462038,-0.06125311,0.0133676715,-0.006452205,-0.08580795,-0.006293019]	2026-01-14 14:15:14.871026+00
3c8b7fa3-8ad5-4871-867d-28f0ee25db3c	af43a4f7-967f-45ee-8baa-e7f9ab759984	Content	# Vector Search Implementation\n\n## Overview\nThis specification covers vector similarity search using pgvector.\n\n## Embedding Storage\nStore embeddings as vector(384) columns in PostgreSQL.\nUse IVFFlat indexes for approximate nearest neighbor search.\n\n## Query Patterns\nUse cosine distance operator <=> for similarity queries.\nORDER BY embedding <=> query_vector LIMIT k for top-k retrieval.	1	0	1	12	[0.018514218,-0.011508709,-0.06940539,-0.050412517,-0.034636255,0.04953341,-0.048225507,-0.0114189675,-0.018590556,-0.028197167,-0.021083504,0.06910326,0.036078315,-0.012615899,-0.07674938,-0.01922897,0.092246525,0.10577303,0.014959401,-0.053657677,-0.020142604,-0.028343279,0.0046519097,0.018378025,-0.058828194,-0.019040974,0.043589327,-0.04768529,0.014893247,0.008733251,-0.0039822394,-0.00056323566,0.028615866,0.10008997,-0.15203835,0.039106406,-0.024410646,-0.058994513,-0.07448544,-0.032418385,0.0001637528,0.0420691,-0.072988726,0.08289378,-0.0054779015,0.0398802,-0.10717499,0.018015759,0.021223236,-0.03023582,-0.11175769,0.02831602,-0.03127495,-0.030684736,-0.014473577,-0.04264391,-0.03214972,-0.07588726,0.045713313,-0.019543108,0.028798824,-0.088654704,0.07788835,-0.054702032,-0.004994032,-0.060826007,0.081016526,0.02384407,0.052710354,-0.061524052,0.027707925,0.09137281,-0.12257836,0.039558332,-0.12302342,0.10879319,-0.0082017835,-0.009011316,-0.004888013,-0.010135466,-0.048452724,0.010679984,0.05409522,0.0012773924,-0.027209273,-0.037761495,0.022554811,-0.062401947,0.03220445,-0.021253455,0.041079756,0.03718505,-0.012100619,-0.078012764,0.019046938,-0.0464249,0.054153655,0.0450468,0.05486941,-0.06234896,0.03606029,0.03704782,0.05066216,0.017433776,-0.06269887,0.020580739,-0.04149546,-0.0020322541,0.074188836,-0.077996306,-0.025486724,0.005502412,-0.07863441,-0.01782435,0.045995902,-0.026102249,0.05622875,-0.00921638,0.072821975,-0.03422478,-0.0005136076,0.017680218,-0.052981615,-0.02785052,-0.04509846,-0.0066941804,-0.024263408,9.4089595e-33,-0.020053068,0.016198626,0.07604615,-0.019956606,-0.081292436,-0.045742165,0.02346939,0.084754884,-0.021219486,0.046105254,-0.08896373,0.10720365,0.016471256,0.057522893,0.026047856,-0.002675676,0.006851853,-0.047585413,-0.001984821,-0.04094863,0.08635875,-0.05735651,0.02809981,0.07050852,0.013902427,-0.052440118,-0.019983208,-0.1490788,0.036286652,-0.016217634,-0.05239618,-0.0034066597,0.0058095567,0.056996204,0.052890226,0.032377828,0.012278463,-0.0030563225,-0.042055957,-0.053387947,-0.003160968,-0.044201292,-0.019674802,-0.075846575,-0.023550699,0.027673308,-0.008611503,-0.012001645,0.030969005,-0.022297123,0.04749211,0.03491917,-0.07975978,0.077727996,0.07446319,-0.012707657,0.029137488,0.025143914,0.028054986,0.09582269,0.03062287,-0.03615871,0.053767357,-0.0072662,-0.02335719,-0.06554771,-0.03903419,0.03348494,0.06436956,0.119953625,0.04499652,0.085540146,-0.010652942,-0.027473545,-0.007998017,-0.007757413,-0.04707934,-0.034628786,-0.009857762,0.002414545,-0.089425586,-0.06316757,0.017324913,-0.013203972,-0.04325479,-0.11533002,0.073694095,-0.038290244,-0.046242017,-0.022663534,-0.0036321732,0.08984859,0.051778473,0.0046324134,0.033250198,-9.755256e-33,-0.033585288,-0.08273861,0.023197198,0.025340032,-0.020755304,-0.02643987,-0.008152151,-0.042117953,-0.04689026,-0.06161308,-0.07145263,-0.04244707,0.14040585,-0.054148853,-0.013206165,0.12584755,-0.050081614,-0.0026651542,-0.108244576,0.07337572,-0.050866414,-0.008216138,-0.002343139,0.03549491,0.08141551,-0.019214643,0.09887545,-0.059652448,-0.030039834,-0.061191823,-0.020255398,-0.018399099,0.023446528,-0.011767861,-0.07062516,-0.01970526,0.03172066,-0.04884532,0.00095157116,0.017818691,-0.053800542,0.072964646,0.053348746,-0.007897585,-0.0070894645,0.04001985,-0.093214765,0.005296362,0.06611359,-0.024761345,0.061257053,0.021645814,-0.05160723,0.011656689,0.099695556,0.004745694,-0.09029908,0.08273226,-0.0058466354,-0.008363336,0.015009152,-0.011522367,0.022403693,0.040053565,0.036452085,-0.059212435,0.03658455,0.0501133,-0.041011147,-0.017040778,0.020877466,0.036453575,0.058103822,0.04550748,-0.034862895,-0.02007901,0.051402893,0.037909016,0.008786593,0.012590975,0.026941983,0.055551462,0.051901005,0.054336645,-0.023717897,0.041142497,0.017585851,0.0037849501,-0.006842172,0.020015448,-0.021340873,-0.0037434353,-0.08867902,-0.00050051074,0.037594806,-3.7453624e-08,-0.06925475,-0.059018664,-0.0235964,-0.04777863,0.040757403,0.0020517563,0.07017932,0.08875166,-0.09776251,0.03389053,0.016753929,-0.018224364,0.0059598666,0.039920732,0.039837692,-0.037311856,0.0065873074,-0.08914033,0.038464602,0.026129616,-0.07196469,0.05995121,0.004551563,0.077923246,0.009631791,-0.0052168877,-0.017184686,0.019864056,0.14592783,0.010551218,0.002484034,-0.006982759,0.025543325,-0.11418892,0.058034196,0.028235955,0.027501564,0.040928278,-0.08386762,0.043095924,0.05458129,-0.046552777,0.03629584,-0.019971848,0.013876498,0.0056591616,0.056386176,-0.0047487374,0.001493535,0.042943746,-0.053385984,-0.057076447,-0.079404466,0.05220333,0.024915015,-0.03316493,-0.09412523,-0.03308165,0.08272948,-0.1203712,0.00927231,-0.020805167,0.037097678,0.05559987]	2026-01-14 14:15:14.948923+00
e474998e-5b59-4220-94c9-025e0c3789f8	bcc97702-2be6-440b-a10e-6050fb8da050	Content	# Frontend React Components\n\n## Overview\nGuidelines for building React components in the application.\n\n## Component Structure\nUse functional components with hooks.\nImplement proper prop typing with TypeScript.\n\n## State Management\nUse React Context for global state.\nPrefer local state for component-specific data.\nConsider React Query for server state.	1	0	1	13	[0.011188581,-0.046553813,0.019468347,-0.014245992,-0.0277189,0.069694765,0.031614374,0.12261348,-0.04112358,0.013624039,-0.07749823,0.0151102515,-0.04789103,0.061268345,0.06716992,0.039276022,0.06920674,-0.053360477,0.04457615,-0.005330935,0.06902271,-0.09441496,0.080276616,0.03755667,-0.00587929,0.0546543,0.08270866,-0.037301634,0.0512039,0.0106126,-0.0036823878,0.046552323,-0.031817224,-0.022284511,-0.16545223,0.051766533,-0.07416041,-0.04253071,-0.0402157,-0.07883616,0.027927684,0.018332895,0.0017670407,-0.0076196734,0.050678186,-0.0015125811,0.030332105,-0.05216789,-0.06580005,-0.034670986,-0.044662274,0.02247055,0.010792173,0.047842085,0.00471608,-0.055159006,-0.020395745,-0.02387508,0.013158974,-0.05429819,-0.0126624005,-0.01731067,0.02330542,-0.042787608,0.062317975,0.043131437,-0.028697696,0.007900719,0.0978269,-0.07156446,-0.019229108,0.010160816,0.074322715,-0.06737122,-0.04219836,-0.1090647,-0.0075827404,-0.0073070982,0.041043025,0.030074822,-0.03280134,0.0067873066,-0.058345806,0.033989564,-0.015230148,0.078172594,0.028504675,-0.012430808,-0.053969257,-0.015966604,0.029749066,-0.05419107,0.09435892,-0.020374205,0.012462837,0.043195397,-0.049068686,0.041044567,0.03127663,-0.04461458,0.07501418,-0.0146059515,0.014368626,0.095583625,-0.062415183,-0.029740438,-0.032160655,-0.024775462,0.013196625,0.01949601,-0.04535052,0.03948553,-0.0039020572,-0.03284824,-0.019712165,-0.04496549,0.032936506,-0.094091214,0.025723817,0.028077757,-0.017340211,-0.020468028,0.032525245,-0.023710517,0.056514997,0.05587574,-0.046032663,5.5518352e-33,-0.027099095,0.029688023,-0.021986734,0.10573832,-0.0053650076,0.014458047,0.035567567,-0.03307894,0.0068071047,-0.001116916,0.05645011,0.05376413,-0.039169695,0.03407763,0.017608987,-0.04237282,0.08010308,0.00360853,0.05330391,-0.054773565,-0.04292726,0.005326605,0.001126525,0.06794052,0.113978356,-0.0068475003,-0.02629263,0.13088343,-0.12479874,-0.049649436,0.1008705,-0.046346482,-0.035649236,0.0739771,0.01209841,-0.06094397,-0.0564112,-0.049362097,-0.03715143,-0.04478056,0.03976614,0.025892692,-0.032747325,0.08073679,0.04254017,-0.026876668,-0.020748938,-0.009200134,0.04195855,0.06353034,-0.042725664,0.003992736,0.099853896,-0.024279606,0.046069767,0.042150892,0.054412697,0.00089318445,0.047522437,0.03594026,-0.07186125,-0.059519272,0.007421078,-0.03385445,-0.031765804,0.058431953,-0.025690459,-0.019563658,0.017377358,-0.016233275,0.053926893,0.013248273,0.030223086,0.063746676,0.015967738,0.042691585,-0.05701784,-0.0040656137,0.025503723,-0.0076636,-0.03496414,0.0027111918,-0.06365675,0.16613169,0.07367736,0.0042952388,-0.04684716,-0.04412597,0.017664874,0.088984184,-0.02302811,-0.057433438,0.05481211,0.011522789,-0.009101059,-5.954209e-33,0.007862729,-0.027668577,-0.043092187,-0.023803433,-0.03258705,-0.040078476,-0.10107425,-0.020782858,0.022156758,-0.031366765,-0.023217127,-0.005730165,0.15670872,-0.0065911645,-0.13502757,0.12952259,-0.026844747,-0.07233472,0.03725351,-0.0069842758,-0.041091602,-0.021101704,-0.041173916,0.058356073,-0.033826876,0.027707811,0.0036108887,-0.06561783,0.0014390448,-0.020294059,-0.05104344,-0.06774797,0.04665651,-0.017022613,-0.09089636,-0.041903615,0.04547155,-0.04523619,-0.036255375,-0.045040905,0.016495308,-0.022366025,0.037365615,-0.00021640962,-0.08844447,-0.02725896,-0.1109961,0.047965676,-0.034734093,0.012417816,-0.05370896,-0.07252288,-0.015042836,-0.10462652,-0.038493205,-0.020759623,0.004280619,0.0004099731,0.061543226,-0.0039848182,-0.0233135,-0.06866195,0.03340272,0.08087144,-0.052947536,-0.08612849,-0.11010256,-0.006915284,0.036049183,0.031707574,0.04130325,0.038258675,0.050791096,0.03215282,0.036067575,0.00053106813,0.042866323,0.02597607,0.10607965,0.07854104,0.01501053,0.04287599,-0.038026955,0.028982295,-0.032836366,0.06596501,-0.017701186,0.00091661914,0.020575974,-0.032826312,-0.07325029,0.012680503,-0.10280419,-0.0070661823,-0.05563529,-3.526513e-08,-0.016454944,-0.047486316,-0.0063391426,-0.034388155,-0.031182582,0.039925285,-0.0338587,-0.039002147,-0.024707451,0.08122189,-0.010659619,0.053782485,-0.021188287,-0.047109686,0.011649546,0.008873658,0.009843745,0.070858456,-0.07501691,-0.026522372,0.028728737,0.022641353,-0.027839279,0.10698211,0.15546854,-0.028162168,0.08623244,0.017204806,-0.011945976,0.025609534,-0.027630478,0.0021653438,0.024444636,-0.013731246,0.025652962,0.042024266,0.023606375,-0.047690134,0.018492406,0.05930046,0.03539039,0.034131605,-0.06867544,0.016201489,-0.04159053,0.08570517,-0.052793607,-0.0033368834,-0.01564614,-0.04224339,-0.012039622,-0.037370153,-0.14665322,0.060455065,0.004687783,0.029094676,0.029290656,0.020246694,0.10984419,-0.08087972,0.026660407,0.040676076,-0.004002621,-0.048661307]	2026-01-14 14:15:15.008618+00
55f276ba-7c4b-4161-849e-c3287cda2450	ce28fd71-dfb4-4b99-b6aa-4f96265dde29	Content	# PostgreSQL Query Optimization\n\n## Overview\nBest practices for optimizing PostgreSQL queries.\n\n## EXPLAIN ANALYZE\nAlways use EXPLAIN ANALYZE to understand query plans.\nLook for sequential scans on large tables.\n\n## Index Usage\nEnsure indexes are being used with proper selectivity.\nConsider covering indexes for frequently accessed columns.\nMonitor index bloat and schedule regular maintenance.	1	0	1	13	[0.07799927,0.065358,-0.015016293,0.010776996,-0.031294566,-0.014218876,0.026175182,-0.0067990553,-0.070468605,0.046647117,-0.09201568,0.078790404,-0.1037307,-0.055496976,-0.086512506,0.002105514,0.0485798,0.0367459,-0.059938975,-0.071099885,-0.008429903,-0.10542838,0.03833308,0.024697531,-0.099792205,0.015992682,0.025827946,-0.008931142,0.029191379,-0.008100195,-0.058551915,0.030970274,0.067912616,0.08121032,-0.12358356,0.047522523,0.03886784,-0.031921875,0.019957304,-0.021629455,-0.03779854,-0.018236477,-0.07355745,0.0035904718,0.0055662594,-0.041356422,-0.0376389,-0.050862066,-0.04140166,-0.0016508497,-0.12607662,0.01308896,-0.017843947,-0.08368438,0.022886284,-0.006930407,-0.016428266,-0.11180453,0.09045544,-0.0068197874,-0.014406662,0.030062763,-0.029253174,0.00101017,-0.042370643,-0.01783439,0.09343584,0.0341101,0.05905075,0.07044525,0.03451775,0.10044195,-0.10108246,-0.024145972,-0.06402502,0.025562877,-0.04487972,-0.052262515,-0.010292948,-0.031200338,-0.0036260115,0.035945684,-9.9569595e-05,0.033485774,-0.032660887,-0.07428143,-0.06243805,-0.083732516,-0.006883152,-0.00610166,0.06843183,0.04245091,-0.016372146,-0.047941823,0.087114476,0.065178744,-0.04451768,-0.09343859,0.056836985,-0.021942684,0.07219266,0.03312891,0.08777993,0.060126267,-0.117076784,-0.047341466,0.043817177,0.04602251,-9.576471e-05,0.002179836,0.059125394,0.047176305,-0.04325174,-0.017638661,0.095851645,0.03445043,-0.009593722,0.018037034,0.045049448,0.082506254,0.041900203,0.010573237,0.010056043,-0.08538127,0.023564188,0.042895578,-0.07003182,7.7236804e-33,-0.029663276,0.017501997,0.012692117,0.0012023784,-0.13655071,0.0021508876,0.05393222,0.067199506,0.0023767825,0.028383626,0.038017485,0.07765807,-0.04745539,0.046072293,0.058904983,-0.018431704,0.015423999,0.11804055,-0.042502552,-0.026484758,0.04960169,-0.089157656,-0.031149914,0.05757617,0.06662777,-0.0011698619,-0.0067220824,-0.062871,-0.030295046,0.0094516,-0.0019523344,0.018380102,-0.0794173,0.059232138,0.04425265,0.05650163,-0.046751454,0.069525376,-0.019922942,-0.057469115,-0.037162274,-0.021306418,-0.010105989,-0.040382337,0.01662,0.051403884,-0.03683388,-0.016693583,0.034408327,0.05432244,0.02383808,-0.007351419,0.026950618,0.11206381,0.021437211,0.024077248,0.058249854,-0.057753973,0.00035244712,0.1412253,0.010601469,-0.106012695,-0.012743074,-0.032945216,0.0058704414,0.01106866,-0.053767394,0.07914789,0.038399346,0.030448332,-0.058703523,0.040341876,0.10023922,-0.002602079,0.026886364,-0.03762001,-0.044800058,0.07320891,-0.029558677,-0.03905146,-0.009999234,0.031161059,0.06796794,-0.04180941,-0.07893928,-0.041786723,0.07253589,0.058447298,-0.0690955,-0.011973327,-0.013446738,0.103771515,-0.0049436553,-0.0040098573,0.0015635767,-9.841162e-33,-0.004396457,-0.017561017,-0.022895379,0.057402205,0.0042064693,-0.0052187443,-0.0069992864,-0.09276003,0.035477277,-0.08761414,-0.090357125,-0.030373631,0.043636296,-0.03653649,-0.07912205,0.0237733,-0.009321361,-0.082147814,-0.028075524,0.057648454,-0.098966986,0.069309056,0.010371435,-0.057962578,0.008507839,-0.005968143,-0.015458154,-0.031901333,0.013571586,0.03917779,-0.054708887,0.033849586,0.049143154,0.032554112,0.014969269,0.015416204,0.03801695,-0.066018686,0.028791405,0.08201168,0.055647142,0.08985561,0.12540063,-0.0025539754,-0.0067827776,0.05103239,-0.07368972,-0.013838221,-0.058222234,0.029703584,-0.02406212,-0.010493385,-0.03777508,-0.028940102,0.009472639,-0.005192285,-0.055622686,-0.035617482,-0.034645133,0.021630574,-0.065289535,0.08161284,-0.029737828,0.073050715,-0.022744037,-0.056065373,0.04540743,-0.08039475,0.030501813,-0.034497663,-0.06860292,-0.000545074,0.022747573,0.031206012,-0.029064376,0.019655604,-0.02309101,-0.00719087,0.007713638,0.021094093,0.014976742,0.039352845,-0.050938986,0.0025287464,-0.09375847,0.032814354,-0.043231048,-0.019987809,-0.038107786,-0.006039109,-0.059258334,-0.09011852,-0.07526099,-0.042093135,-0.0028805418,-3.9674187e-08,-0.04096081,-0.045953635,0.0676712,-0.00077992375,0.08700019,-0.039510112,-0.02593714,0.1176395,-0.0063608377,-0.011005018,0.06437878,-0.038070332,-0.040357593,0.048685297,0.023340393,-0.0597066,-0.01579713,-0.015349632,-0.09029709,-0.03427718,-0.12165185,0.012363425,-0.047989454,-0.005592714,0.059798658,-0.0347665,0.03355077,0.031124571,0.039236344,0.03498761,-0.0052301073,-0.0075766495,-0.01206714,-0.030959414,0.053187802,0.009712985,0.0039033887,-0.011979259,-0.02900252,0.059126094,0.0019994199,0.016678508,0.0040276726,-0.010443753,-0.035085645,-0.043650307,-0.08318777,0.057094,0.039322704,-0.017129324,-0.028434549,-0.0827306,-0.05286304,0.076389454,0.036705464,0.06517403,0.025720999,0.041030385,0.050207343,-0.012639084,0.031548373,0.045490056,-0.06999177,0.02873958]	2026-01-14 14:15:15.062898+00
3ff1703a-4b0d-468a-95b9-e10638f13c9b	2e560d15-2a8a-45dd-a1e3-23b5b821c13a	Content	# Deprecation Test\n\nThis document will be deprecated for testing purposes.\n\n## Features\n\n- Feature A\n- Feature B	1	0	1	8	\N	2026-01-14 14:33:33.398681+00
ca531cf9-da19-456d-9f4c-3b6a2ceeea7c	045eab50-7e02-4320-a6f4-34328cb9a22f	Authentication System Design		1	0	1	2	[0,0.039751325,-0.063408114,0.06254655,-0.040407162,0.010297064,0.010832211,-0.010551586,-0.013050472,0.050419606,-0.0850892,0.10155307,-0.09268281,0.06313379,-0.02710676,0.001538519,0.0020135306,0.017098114,-0.048317008,0.07496591,-0.082269594,0.06447018,-0.027622927,-0.013268492,0.041404426,-0.0462005,0.028317327,0.0007022667,-0.024013832,0.027593268,-0.007005219,-0.030428026,0.06909771,-0.09255617,0.091370426,-0.0676168,0.033861943,-0.0071191876,0.00067829125,-0.017726125,0.049817137,-0.08092696,0.09514552,-0.08432091,0.05198869,-0.011702469,-0.019434372,0.028934812,-0.014877372,-0.013213555,0.03897765,-0.0471079,0.030735796,0.005229258,-0.04640812,0.07580174,-0.081898965,0.0641557,-0.033218727,0.0057876664,0.0034210156,0.01124557,-0.04364711,0.07878031,-0.09996424,0.096835785,-0.07032165,0.032202933,0.00051905325,-0.013754566,0.0030561714,0.024278376,-0.05273889,0.06607681,-0.05513635,0.02228735,0.019666264,-0.053579777,0.06614186,-0.054211073,0.026277311,0.0016519299,-0.0137673,0.0020752987,0.029735113,-0.06803145,0.09574889,-0.10055215,0.08073506,-0.04602932,0.012934899,0.0031890566,0.00451947,-0.03114874,0.06238719,-0.0814094,0.0769721,-0.048837963,0.007926212,0.028882897,-0.046799075,0.04016907,-0.015141539,-0.01332721,0.028690288,-0.020789,-0.009232941,0.04943667,-0.08277431,0.095228255,-0.082501605,0.05205237,-0.01949648,0.001104635,-0.005990707,0.03173732,-0.065556064,0.09042607,-0.0932675,0.071230926,-0.03308664,-0.0049524885,0.026972322,-0.02495166,0.002568709,0.026604624,-0.045654222,0.042479053,-0.015639402,-0.024906784,0.062533155,-0.081873044,0.076145716,-0.050368793,0.018917125,0.0014008536,0.00057087175,-0.024964929,0.060810212,-0.09128091,0.101758376,-0.08684044,0.05293751,-0.015210461,-0.009681472,0.011546084,0.008482045,-0.038517095,0.06165639,-0.06412362,0.04191588,-0.0027667494,-0.037516363,0.06258535,-0.06334366,0.042262416,-0.012151461,-0.010024561,0.011319544,0.010950842,-0.047890015,0.08325843,-0.10123703,0.09399436,-0.06542916,0.029294495,-0.002602636,-0.0025269105,-0.015332201,0.046245333,-0.07370155,0.08255638,-0.06632391,0.030321429,0.01084173,-0.040227644,0.046647534,-0.02998131,0.0011891838,0.022989614,-0.0281084,0.008984161,0.027774915,-0.06689805,0.09173712,-0.09221616,0.0696339,-0.036017384,0.008336643,-0.0003548669,0.016021734,-0.047577746,0.07927853,-0.09495333,0.085773505,-0.054506004,0.014212118,0.017984997,-0.029076198,0.016366087,0.011275413,-0.03770907,0.047309496,-0.032502934,-0.0025551633,0.04392677,-0.074529506,0.082284294,-0.065866575,0.035304166,-0.007135722,-0.0035483728,-0.00963398,0.041276988,-0.07676466,0.099270076,-0.09782048,0.0725612,-0.034694485,0.0011225721,0.0136370035,-0.0043875286,-0.02228444,0.051200595,-0.06590557,0.056597076,-0.024868604,-0.017010005,0.051929805,-0.06609977,0.055613287,-0.02827634,-0.00017840373,0.013675758,-0.0035433997,-0.027295796,0.06569509,-0.09456186,0.101032466,-0.08262479,0.048418723,-0.014698622,-0.002852683,-0.0033341888,0.029099036,-0.06056533,0.080817275,-0.07803884,0.051211953,-0.010641163,-0.026947295,0.046382833,-0.041279994,0.017054487,0.011719661,-0.028343907,0.022046762,0.006808051,-0.046854705,0.08113644,-0.095200926,0.08399883,-0.054278515,0.021328948,-0.0016329756,0.0049536442,-0.029648151,0.063456304,-0.08938545,0.09387009,-0.07329375,0.035745803,0.002829582,-0.026246116,0.025800336,-0.004405406,-0.02484764,0.045010693,-0.043450113,0.0179503,0.022177916,-0.06051619,0.08136689,-0.07723789,0.052395854,-0.02078497,-0.0006905167,0.00029852893,0.02287334,-0.058463253,0.08979167,-0.1018527,0.08850875,-0.055438805,0.01742673,0.008710489,-0.012164064,-0.0067108953,0.03659692,-0.06067582,0.0647312,-0.044006318,0.005528538,0.035214845,-0.061656237,0.06404525,-0.044078223,0.014040661,0.009125445,-0.011984281,-0.008915514,0.045353677,-0.08135168,0.10081077,-0.095212735,0.06769154,-0.031523682,0.0037612373,0.002939571,0.013623527,-0.04415864,0.072355896,-0.082733475,-0.040898338,0.0014840225,0.024536226,-0.027185608,0.007873425,0.021322316,-0.043489754,0.045037206,-0.022256045,-0.016855016,0.056379568,-0.08007087,0.07909958,-0.056247875,0.024539413,-0.0009627643,-0.0017018524,-0.01896675,0.05385206,-0.08665862,0.10171849,-0.09150264,0.060235586,-0.021880452,-0.00654002,0.0130840475,0.0034096488,-0.032795787,0.05852166,-0.06560195,0.047844965,-0.0108648315,-0.0305652,0.059550095,-0.06512753,0.04747833,-0.017795408,-0.0071253804,0.0129782,0.0051569017,-0.04042216,0.0774416,-0.09966955,0.09730502,-0.07197771,0.035958856,-0.0062756026,-0.0034492407,-0.010480554,0.040077433,-0.069520205,0.08276517,-0.071268536,0.03811704,0.0034143678,-0.03618669,0.047371395,-0.034556437,0.0068568923,0.019501649,-0.029008538]	2026-01-14 17:02:37.8634+00
328148cf-fb8b-4f2e-a43c-d215ac09ce27	045eab50-7e02-4320-a6f4-34328cb9a22f	Overview	This document describes the authentication system for the Agentic Platform.	2	1	3	5	[0.022421999,-0.026673924,0.040186454,-0.05274779,0.054317396,-0.039902583,0.012018292,0.02045037,-0.046438556,0.057936907,-0.05376259,0.040059093,-0.027286205,0.025144393,-0.0378681,0.062145602,-0.088663496,0.106536016,-0.10849601,0.09435904,-0.0711001,0.049506225,-0.03901015,0.04318188,-0.058039755,0.073990315,-0.0804665,0.07103961,-0.046553355,0.014776487,0.023652025,-0.009192848,-0.01589098,0.037236035,-0.042211175,0.02601107,0.0060021607,-0.04083253,0.064044766,-0.06665036,0.04938401,-0.022320492,1.6187561e-05,0.005494832,0.009508388,-0.038632832,0.068424314,-0.08481044,0.07984458,-0.05551744,0.022808656,0.0035669655,-0.01219971,0.0004363282,0.024370914,-0.048416045,0.058088653,-0.04653204,0.044041257,0.01063294,-0.04330779,0.0402069,-0.0049406798,-0.043257784,0.07879053,-0.08200686,0.04866589,0.007988088,-0.06353323,0.09403704,-0.087489285,0.049519867,-0.00066074653,-0.033534706,0.034776833,-0.00083849137,-0.05335174,0.10284647,-0.1246249,0.10861956,-0.06253755,-0.001977163,0.021611499,-0.019822853,0.00065073156,0.023408,-0.03744236,0.031329107,-0.0046393005,-0.03310379,0.06693989,-0.08359597,0.07780435,-0.05478616,0.027709942,-0.011344577,0.014950284,-0.037816644,0.06958739,-0.09521646,0.10217926,-0.08648145,0.054584343,-0.020323452,-0.0017025445,0.00310299,0.014315424,-0.039453447,0.057283744,-0.05610231,0.033189222,0.003836125,-0.040615935,0.06288537,-0.063259676,0.04472378,-0.019151883,0.0015677108,-0.0028981194,0.024695205,-0.058358062,0.089227885,-0.1035934,0.09524803,-0.0684552,0.025758224,-0.020073721,0.021235814,-0.02540133,0.027082015,-0.021830283,0.008428311,0.010469949,-0.029552618,-0.003365031,0.01862899,-0.025579061,0.018652307,0.0010356223,-0.02619111,0.046806276,-0.05492552,0.048429996,-0.032025952,0.014963481,-0.0065798336,0.011804525,-0.028781625,0.04974953,-0.064756535,0.066430785,-0.05351761,0.031488113,-0.009927158,-0.002047084,0.00013606402,0.013100564,-0.029497767,0.039228298,-0.035545122,0.018048774,0.0070874235,-0.030042848,0.04202356,-0.039444316,0.025614046,-0.009117055,-0.00033322477,0.036758784,-0.07516121,0.0846446,-0.06305923,0.02300394,0.014249609,-0.02898817,0.012537608,0.028553125,-0.075631194,0.106867045,-0.10770946,0.0778558,-0.031395566,-0.009941648,0.027196288,-0.01325602,-0.023752179,0.0643811,-0.08721411,0.07916393,-0.0417808,-0.009454864,0.05251687,-0.06935466,0.05450761,-0.017682644,-0.020940222,0.0404228,-0.029145595,-0.009585584,0.05909198,-0.097289436,0.107251376,-0.08530301,0.042766143,-0.0005183113,-0.021024864,0.01170083,0.023529863,-0.06696961,0.096681744,-0.09702574,0.06617805,-0.017032241,-0.028953597,0.052012596,-0.043511253,0.010051255,0.0297351,-0.05415878,0.048913885,-0.013977239,-0.03634102,0.080220774,-0.098758146,0.08499614,-0.047230285,0.0050047804,0.020280683,-0.015649369,-0.017217288,0.016073989,-0.031700566,0.03617562,-0.025741009,0.003749454,0.020917328,-0.038081285,0.041122455,-0.03012802,0.011826459,0.0036611983,-0.007695028,-0.0027223262,0.02349198,-0.04537017,0.058389235,-0.056628708,0.04104897,-0.019028991,0.000829742,0.0053210123,0.0028340768,-0.020510362,0.038188893,-0.0461967,0.03936328,-0.01952041,-0.0053536794,0.024935743,-0.031482276,0.023516698,-0.00651149,-0.009761409,0.015941111,-0.0075902785,-0.012654384,0.03632509,-0.053163752,0.05602345,-0.044280767,0.024123054,-0.0055731335,0.017767685,-0.05175042,0.08532459,-0.10360542,0.09864247,-0.07321901,0.039511222,-0.0132503025,0.0061865402,-0.020468477,0.047632,-0.072683774,0.081320696,-0.06682343,0.03331824,0.0061575407,-0.03585942,0.044835266,-0.032125376,0.0071706357,0.014766144,-0.019969562,0.0028974602,0.094893016,-0.10882457,0.10601085,-0.0884024,0.06448311,-0.04520178,0.03873056,-0.04656338,0.062824614,-0.07711929,0.079557516,-0.06554361,0.038032886,-0.0061731655,-0.019018434,0.029871669,-0.025672272,0.012934601,-0.0022082299,0.0029506634,-0.018925669,0.046334602,-0.075577706,0.09580184,-0.100054935,0.088576674,-0.06864809,0.051072914,-0.044978086,0.05342679,-0.07194756,0.090684734,-0.09913913,0.09122565,-0.068222456,0.03819731,-0.012185319,-0.0010497608,-0.00084015814,0.012723831,-0.024516651,0.026084123,-0.0121707115,-0.015010256,0.0467685,-0.07203599,0.082609065,-0.07702102,0.061189316,-0.04552801,0.0399106,-0.04889924,0.06952826,-0.09270522,0.10755803,-0.10664405,0.08952362,-0.062984504,-0.004048781,-0.010393532,0.037010487,-0.061777763,0.07131073,-0.05930545,0.029588182,0.0056892037,-0.03184306,0.03866364,-0.025274144,0.0005138796,0.021337526,-0.027444215,0.0126051875,0.018216642,-0.052240543,0.07496488,-0.07709206,0.05896155,-0.030366026,0.0058389474,0.0023265688,0.010019774,-0.03689186,0.065038346,-0.08030201,0.074417956,-0.05913296,0.007281828,0.026072003]	2026-01-14 17:02:37.867643+00
d5ff151c-26b5-4f72-a8a1-3461b5eefa0c	045eab50-7e02-4320-a6f4-34328cb9a22f	Authentication Methods	The platform supports multiple authentication methods:\n- JWT-based authentication for API access\n- OAuth 2.0 for third-party integrations\n- Session-based authentication for web UI	2	2	6	11	[0.06642178,-0.08036135,0.0701041,-0.040783685,0.006447727,0.01667741,-0.017963005,-0.002533005,0.034104306,-0.060543213,0.06792841,-0.051319163,0.01152707,0.01571342,-0.03674035,0.05006347,-0.032481395,-0.006116396,0.02823943,-0.021051316,-0.013985307,0.0617792,-0.10081977,0.113468885,-0.09440105,0.05314527,-0.009510236,-0.015913825,0.0116223665,0.019298064,-0.060665715,0.09098338,-0.05761208,0.033937905,0.002868254,-0.038384084,0.058804624,-0.0575112,0.038195543,-0.01304197,-0.0031600948,0.00014962576,0.022847395,-0.045582026,0.0604148,-0.064564675,0.05593566,-0.038276177,0.019387893,-0.0073953783,0.006865128,-0.016634459,0.030391017,-0.03972468,0.038188163,-0.02441896,0.0028252706,0.018493492,-0.031595074,0.032466996,-0.022915153,0.009663333,-0.0010960451,0.0032068216,-0.016695179,0.036604606,-0.054675568,0.06328571,-0.059088316,0.044604838,-0.027007999,0.014679142,-0.013190508,0.02263878,-0.03760832,0.049781587,-0.051944844,0.04146837,-0.018586855,-0.012447721,0.041132852,-0.05580834,0.05144236,-0.032012902,0.008571137,0.0060842643,-0.0035679503,-0.016050465,0.044262104,-0.068184614,0.07672886,-0.06590987,0.040755823,-0.012899619,-0.0049920743,0.005281378,0.010993283,-0.034633383,0.052712407,-0.054798465,0.0379835,-0.00830727,-0.022107074,0.04083294,-0.03160472,0.039761998,-0.034982238,0.033796024,-0.0264908,0.019731723,-0.020697154,0.03259457,-0.05306559,0.075264744,-0.09109547,0.10082831,-0.08568651,0.072181605,-0.06797925,0.075602,-0.091211975,0.10645379,-0.11247429,0.10419139,-0.082764916,0.055084206,-0.030517535,0.016480979,-0.014950488,0.021588402,-0.02790208,0.025398431,-0.009741093,-0.017084334,0.047636453,-0.07250171,0.08472652,-0.083074,0.07254517,-0.061915606,0.059469912,-0.06897991,0.08785576,-0.10835704,0.12128375,-0.12037756,0.10532349,-0.08191255,0.05928732,-0.04559076,0.04410394,-0.051723994,0.060511153,-0.061562285,0.04935261,-0.024462713,-0.006617807,0.03451726,-0.051389296,0.054589022,-0.047856454,0.039441302,-0.038069393,0.04868597,-0.07001792,0.09512483,-0.11467562,0.121380374,-0.10232291,0.069084816,-0.040791184,0.029451676,-0.03837921,0.06063456,-0.08239485,0.08963021,-0.07488658,0.040921714,0.0005500935,-0.034403548,0.049280487,-0.042959984,0.023346853,-0.004605714,0.0002954798,-0.016797151,0.05018724,-0.08805694,0.115405776,-0.121784806,0.10626514,-0.0778502,0.051134545,-0.04161158,0.03945168,-0.05306496,0.07567108,-0.09564243,0.102091536,-0.0901116,0.06315744,-0.03142456,0.0070031635,0.0038786978,0.006792045,-0.016965857,0.018351512,-0.0068816026,-0.015284351,0.04074339,-0.060348455,0.06754657,-0.061476495,0.047341418,-0.03387852,0.029139284,-0.03660424,0.053495362,-0.072095595,0.08344301,-0.08162845,0.06663609,-0.044364788,0.023819808,-0.012821104,0.014285447,-0.024864579,0.036591742,-0.040746506,0.032084115,-0.08902696,0.09719176,-0.08249036,0.050049692,-0.013162922,-0.013049003,0.018847523,-0.0045018196,-0.01988767,0.03928221,-0.040967382,0.020702383,0.015193278,-0.052816954,0.07729733,-0.07987549,0.06205827,-0.03485307,0.01345187,-0.0099137,0.02735477,-0.05843225,0.08884909,-0.10419963,0.09687391,-0.069710284,0.03464502,-0.007006123,-0.0018128911,-0.010213062,0.03480393,-0.057383638,0.06411221,-0.04856844,0.014878393,0.024211224,-0.053391743,0.062079173,-0.04943594,0.024720721,-0.0027994933,-0.003029152,0.020844674,-0.034820467,0.027015142,-0.0024681492,-0.025695032,0.042577237,-0.038674038,0.014452735,0.019849848,-0.049114216,0.0605669,-0.049885377,0.023252433,0.005624811,-0.022101622,0.017629776,0.0061337394,-0.038113635,0.048795696,-0.060281795,0.057638798,-0.04289323,0.0236329,-0.009360717,0.006934167,-0.01727714,0.03494067,-0.050723165,0.056093685,-0.047297254,0.0271736,-0.0038170181,-0.013280422,0.017753506,-0.009387303,-0.005809787,0.01851793,-0.020606056,0.009062145,0.012531335,-0.035684746,0.051042832,-0.052843127,0.041653972,-0.02407978,0.012580336,-0.018243067,0.041212823,-0.07070322,0.0923928,0.012311787,-0.047851395,0.06751461,-0.063404724,0.03888979,-0.006966067,-0.015992656,0.018102365,0.0023195343,-0.035937015,0.0668647,-0.08028077,0.0672131,-0.047632042,0.022036284,-0.00063509133,-0.034114305,0.0027739168,0.035795916,-0.060272265,0.056041867,-0.022252483,-0.02773367,0.07270258,-0.09371709,0.083155915,-0.048329603,0.007940465,0.01691581,-0.012891795,-0.019189762,0.0647132,-0.10226583,0.09192159,-0.0739524,0.04049277,-0.0053756326,-0.017047482,0.018748902,-0.001831489,-0.022524998,0.039471973,-0.037660763,0.014734076,0.028369984,-0.047487013,0.0569102,-0.05361085,0.040433887,-0.024714146,0.014743729,-0.01578446,0.027537517,-0.04428359,0.05762643,-0.060524292,0.050676275,-0.031639684,0.011142536,0.0026000408,-0.0047996296,-0.0036375723]	2026-01-14 17:02:37.870147+00
ba835b89-994a-4924-994a-37dc9f0aaac2	045eab50-7e02-4320-a6f4-34328cb9a22f	Security Requirements	- All tokens must be signed using RS256\n- Token expiration: 1 hour for access tokens, 7 days for refresh tokens\n- Rate limiting: 100 requests per minute per user	2	3	12	16	[0.068094485,-0.059930105,0.04966867,-0.042266343,0.040893678,-0.045421306,0.05249423,-0.057158846,0.055262335,-0.04547362,0.02995641,-0.0133711025,0.0006834838,0.0051697767,-0.0046402426,0.0013005391,-7.978362e-05,0.004848478,-0.016511638,0.032525238,-0.048068605,0.058311347,-0.060688607,0.05129857,-0.051950634,0.048567977,-0.042804457,0.037130397,-0.03365272,0.033114266,-0.03455201,0.0357778,-0.034450784,0.02922708,-0.02043488,0.009950956,-0.00033716156,-0.0063495687,0.009503766,-0.010221293,0.010733357,-0.013296668,0.019072508,-0.018032936,0.014178364,-0.018662246,0.014521549,-0.019456184,0.0324446,-0.048333425,0.06029164,-0.0630736,0.055526584,-0.041140668,0.02637734,-0.017578192,0.017935775,-0.025978833,0.03629794,-0.04216329,0.03877916,-0.025614146,0.0066894577,0.011313519,-0.022219533,0.023282114,-0.016461829,0.007447826,-0.0028924632,0.0071854554,-0.02031485,0.018047309,-0.046733923,0.06587918,-0.068387635,0.05490821,-0.033494283,0.015717583,-0.011099638,0.022530956,-0.044874605,0.06742386,-0.079035655,0.07347851,-0.052430645,0.02469066,-0.0019789985,-0.006657097,-0.00084718945,0.01861651,-0.035687815,0.04130479,-0.030115161,0.004778302,0.020471998,-0.051819067,0.061742853,-0.01644839,0.009225427,0.029757315,-0.045599848,0.029754179,0.010981396,-0.05770943,0.08848422,-0.088826984,0.077372,-0.036615755,-0.03255806,0.064933114,-0.056988664,0.012233196,0.04802752,-0.09490352,0.10577248,-0.07512868,0.017227432,0.040743113,-0.07168894,0.06159003,-0.016209811,-0.041682553,0.083244994,-0.087408304,0.08161017,-0.025795244,-0.034857932,0.07250989,-0.070447326,0.031075783,0.02525575,-0.07003446,0.0802781,-0.04957781,-0.008805765,0.06827784,-0.101639174,0.09410676,-0.050383046,-0.0076157656,0.05128265,-0.05904839,0.026733158,0.030442232,-0.08515005,0.11105707,-0.09545222,0.045345567,0.01588538,-0.059694458,0.06604123,-0.032984756,-0.022402907,0.07224126,-0.09122979,0.06880065,-0.014208356,-0.04788413,0.089207046,-0.09141496,0.054860033,0.0015987664,-0.049658682,0.06516265,-0.03969919,-0.015349346,0.0742514,-0.07909421,0.084747605,-0.026386822,-0.012337334,0.04722784,-0.082859255,0.077541105,-0.04246951,-0.0059365635,0.044973947,-0.056532893,0.035770707,0.0065772138,-0.049356807,0.07115129,-0.060563926,-0.00681773,0.05839752,-0.08949287,0.08538107,-0.04810039,-0.0045282063,0.047444865,-0.060363565,0.03749412,0.009687878,-0.057951197,0.083457105,-0.07320017,0.031256035,0.023159632,-0.06489054,0.07488693,-0.049324453,0.0014227488,0.044907928,-0.06654562,0.052257065,-0.008097039,-0.04548233,0.08342653,-0.08808166,0.05765056,-0.0070477375,-0.039256725,0.058973067,-0.04268046,-0.001656459,0.050528318,-0.092192546,0.09915433,-0.066459835,0.008046565,0.049912162,-0.08152803,0.054823667,0.003055507,-0.04857752,0.06899235,-0.052636288,0.005533575,0.05146381,-0.0926471,0.0997521,-0.070693314,0.020543296,0.025711881,-0.04516733,0.02799284,0.017846024,-0.07040299,0.10427313,-0.102777,0.06596469,-0.0106022535,-0.03785341,0.057443406,-0.040215705,-0.003984548,0.0522601,-0.07966664,0.07470407,-0.043456975,-0.0019168531,0.041280966,-0.05745955,0.044446304,-0.010257048,-0.026941236,0.047568507,-0.04004684,0.0063779154,0.038791757,-0.07517013,0.08652781,-0.06846069,0.030485405,0.008536908,-0.029454084,0.022012703,0.010222223,-0.05157652,0.081785545,-0.085717246,0.060637597,0.0014649677,-0.069133475,0.10594836,-0.09733662,0.050422423,0.009435313,-0.050846297,0.051481385,-0.008817192,-0.066807225,0.12179431,-0.15031211,0.1393649,-0.0943722,0.036567703,0.007176417,-0.017220767,-0.009445523,0.04556197,-0.09441849,0.12169932,-0.11195434,0.06715458,0.005948893,-0.030169366,0.032353614,-0.012876167,-0.017406708,0.042385846,-0.04844776,0.031027343,0.0031775131,-0.03939162,0.061821483,-0.06120339,0.039221898,-0.0076805498,-0.01717721,0.022473706,-0.004886399,-0.027746888,0.060176715,-0.0770475,0.070257016,-0.04284142,0.0075228773,0.019383736,-0.025783697,0.009588947,0.02777492,0.042167,-0.045826335,0.042909857,-0.03741244,0.034286655,-0.037032153,0.04598655,-0.058137868,0.068548724,-0.072709866,0.068694696,-0.05808198,0.04520423,-0.035082165,0.031035384,-0.033114538,0.038106453,-0.041109186,0.037921388,-0.02709965,0.010696786,0.006673666,-0.019998942,0.024238475,-0.03272425,0.03756214,-0.038469736,0.036830146,-0.035000585,0.035157718,-0.038233813,0.04345408,-0.048697278,0.05150684,-0.050267834,0.044985447,-0.037291642,0.029676696,-0.02431382,0.02204016,-0.021982368,0.02200588,-0.019771997,0.01389541,0.0012224327,-0.00022685232,-0.008353621,0.011871884,-0.0061743576,-0.008419055,0.027230853,-0.043432586,0.051284812,-0.048857458,0.038926672,-0.0276187,0.021451302,-0.024191646,0.03503747,-0.04899379,0.059264638,-0.06051317]	2026-01-14 17:02:37.872417+00
dae09132-3ae9-4b1d-910f-8eccf517352b	045eab50-7e02-4320-a6f4-34328cb9a22f	Implementation Details	The auth service is implemented in TypeScript using the `jsonwebtoken` library.\nUser credentials are stored in PostgreSQL with bcrypt hashing.	2	4	17	20	[-0.082354255,0.05198545,-0.0109518925,-0.02068183,0.027585879,-0.006517882,-0.032123506,0.06928906,-0.08642062,0.037547328,-0.026110947,0.003967644,0.017937966,-0.028808504,0.023175433,-0.0035250292,-0.020890364,0.038485922,-0.04089703,0.026988722,-0.0033995595,-0.01864091,0.02869511,-0.031039422,-0.004274175,0.031997163,-0.036869206,0.014703055,0.025578983,-0.066196516,0.08901237,-0.08420803,0.054973844,-0.015965628,-0.013732351,0.019763593,0.0006152975,-0.037221547,0.07183494,-0.08694426,0.07415762,-0.03824395,-0.005132374,0.036897946,-0.043688644,0.024228284,0.010090253,-0.040699646,0.050793443,-0.033417366,-0.005163443,0.048436232,-0.077527136,0.08022148,-0.056793395,0.019850012,0.011734622,-0.02188713,0.005055962,0.031116176,-0.06945013,0.09146462,-0.08623902,0.055655174,-0.013504776,-0.021109745,0.032917045,-0.017778413,-0.015351535,0.04874468,-0.06442816,0.05545289,-0.007181921,-0.03528902,0.0553598,-0.047255702,0.018736375,0.012684917,-0.028198075,0.016773248,0.01949482,-0.06633857,0.10410993,-0.11715724,0.10129157,-0.065762945,0.028799806,-0.0088503845,0.015726093,-0.045893412,0.08417178,-0.07754086,0.078436136,-0.065926805,0.045554098,-0.026260247,0.016113816,-0.018459436,0.030337797,-0.043933082,0.068021715,-0.08577768,0.02792645,0.0024533467,-0.027946109,0.036814317,-0.025341565,-0.00039385186,0.027442284,-0.042201176,0.036946937,-0.013548226,-0.017419895,0.04173637,-0.04834296,0.034637,-0.0077104894,-0.019058365,0.032426897,-0.025643758,0.0016913076,0.028140146,-0.049662687,0.052591667,-0.035476357,0.006396225,0.020910928,-0.03363265,0.026020655,-0.0021414866,-0.026079748,0.1019841,-0.0940313,0.05586206,-0.0006744412,-0.006719476,-0.00898511,0.03918666,-0.06804038,0.08007651,-0.06764306,0.03460394,0.005481062,-0.03582229,0.04441258,-0.029744823,0.0014939756,0.024162885,-0.032343887,0.016637903,0.01778283,-0.056605954,0.083207265,-0.08659057,0.06663268,-0.034119178,0.005554126,0.0047673387,0.00837759,-0.03863095,0.07110332,-0.08951882,0.084029876,-0.05595467,0.017165527,0.015578782,-0.02863978,0.024522057,0.017307665,-0.07060437,0.09679687,-0.08338898,0.036765795,0.020867081,-0.062128153,0.0675847,-0.035064735,-0.019308517,0.06885545,-0.08914164,0.069703914,-0.019078631,-0.039279107,0.08506864,-0.0692335,0.022550281,0.029795015,-0.059981685,0.05093583,-0.0045572068,-0.059153747,0.111650735,-0.12949757,0.10557816,-0.052486002,-0.0035314446,0.035169963,-0.027167039,-0.016378779,0.073977076,-0.11705909,0.12369035,-0.08910748,0.028026728,0.032383062,-0.06549412,0.05795064,-0.016033301,-0.037393555,0.07388769,-0.0731101,0.03262113,0.03090606,-0.08963715,0.1739734,-0.046837237,-0.0009517415,0.03739373,0.009002835,-0.035515014,0.06280178,-0.07452889,0.061596245,-0.026555117,-0.01755831,0.05341488,-0.06764184,0.057175253,-0.030670678,0.0042965063,0.0060720844,0.007484984,-0.041089404,0.08088324,-0.109638356,0.11498794,-0.09533399,0.06059843,-0.027458113,0.011348427,-0.019069564,0.045540392,-0.07625616,0.09427127,-0.08835866,0.00539948,0.04127086,-0.06817679,0.07111163,-0.06123506,0.043650463,-0.029256035,0.027045326,-0.039762616,0.06256089,-0.08530642,0.09742516,-0.09296754,0.07346324,-0.04719723,0.025253955,-0.01622614,0.022124842,-0.037451226,0.05187463,-0.055232167,0.04245202,-0.016039046,-0.015069884,0.039732892,-0.049886595,0.044353776,-0.029350411,0.015449898,-0.012460887,0.02467544,-0.04876666,0.07534452,-0.08865397,0.07606638,-0.040847134,0.00043419027,0.025468051,-0.024341494,-0.0031420626,0.04344508,-0.076660715,0.08606662,-0.06615516,0.02528971,0.018286966,-0.045178533,0.044111762,-0.017316518,-0.020570137,0.049549773,-0.053879753,0.029650066,0.0133134145,-0.056132287,0.07990047,-0.07472386,0.04444087,-0.0047609475,-0.024286117,0.027969502,-0.0039328183,-0.03666688,0.074502856,-0.0913431,0.07879344,-0.042327248,-0.0013303839,0.03221005,-0.03665775,0.013863685,0.023770072,-0.05659886,0.06717937,-0.048659626,0.0080919955,0.03691982,-0.066632494,0.0686008,-0.043616742,0.005302794,0.026445193,-0.035021186,0.015092563,0.024824066,-0.066430174,0.09040582,-0.032771703,0.023769785,-0.0027985699,-0.01967926,0.032476086,-0.029049853,0.010647106,0.014288532,-0.03415891,0.039766755,-0.02872034,0.0065756417,0.015831627,-0.031268224,0.009750772,0.025412172,-0.05548195,0.064051665,-0.04494371,0.005203918,0.038243797,-0.06667883,0.06852701,-0.044878054,0.008932333,0.020357225,-0.02739922,0.0074634394,0.031030083,-0.07053053,0.092757285,-0.08745471,0.057303157,-0.016631681,-0.015450317,0.024209393,-0.0063422015,-0.028454587,0.06215111,-0.07705002,0.06429578,-0.028147252,-0.016035454,0.049124993,-0.0573658,0.03893666,-0.004790797,-0.026628776,0.038264327,-0.022653066,-0.014465388,0.056873836]	2026-01-14 17:02:37.874893+00
6a14dc74-d483-44d5-950e-03c1d92e9254	045eab50-7e02-4320-a6f4-34328cb9a22f	API Endpoints	- POST /auth/login - Authenticate user\n- POST /auth/refresh - Refresh access token\n- POST /auth/logout - Invalidate session	2	5	21	25	[0.047033068,-0.007763106,-0.020127311,0.02303714,0.00041886038,-0.038746092,0.07308529,-0.08626249,0.0710344,-0.033575803,-0.009463614,0.0319604,-0.030697016,0.019697376,0.0069583943,-0.03423457,0.046736438,-0.03612762,0.0051635127,0.033593565,-0.06376213,0.072961725,-0.058716543,0.026882008,-0.0031624276,-0.008338841,0.0015508365,0.020606035,-0.047615048,0.06640395,-0.0676146,0.05009537,-0.021462165,-0.00554095,0.019136854,-0.014143937,-0.005560264,0.028921297,-0.043033056,0.039352372,-0.017822858,-0.013069766,0.040337734,-0.05269011,0.045918733,-0.024889223,0.0011829131,0.012479363,-0.008357576,-0.012577892,0.04109588,-0.06411795,0.070979886,-0.058538985,0.032678653,-0.0054887235,-0.010526421,0.008435054,0.009809964,-0.034322295,0.052040026,-0.053008806,0.035177365,-0.0054056793,-0.023797877,0.04024647,-0.037889797,0.019686455,0.003843036,-0.019688383,0.01861444,0.00038535602,-0.015330269,0.04552382,-0.06352975,0.0610998,-0.03962821,0.009479676,0.014981311,-0.02227637,0.009312892,0.017139453,-0.04370318,0.056817885,-0.04925486,0.023597667,0.0089804,-0.034056004,0.040852726,-0.027388629,0.0014066997,0.023357708,-0.033782426,0.02366956,0.0032641538,-0.035151802,0.057649847,-0.060800713,0.043794233,-0.049153075,0.0002021723,0.031281766,-0.03174576,0.0027590916,0.039767016,-0.073239625,0.07925096,-0.052441083,0.0031063121,0.047697745,-0.078211315,0.076363206,-0.045518756,0.002827729,0.029035188,-0.03277652,0.0048070326,0.045807116,-0.083825424,0.100307874,-0.08744135,0.051193204,-0.008453223,-0.021056894,0.024227507,-0.0008305399,-0.036391255,0.06785776,-0.076566525,0.0562747,-0.014524452,-0.030939288,0.060641624,-0.06267919,0.038391083,-0.0016808318,-0.02768508,0.03358828,-0.01131848,-0.030138852,0.07238444,-0.10897787,0.10980578,-0.08056808,0.0359463,0.002363325,-0.01605717,-0.0010007238,0.039843336,-0.08071233,0.10254923,-0.09311506,0.05488606,-0.0038982576,-0.03790568,0.053158328,-0.03735306,0.00096118514,0.035633713,-0.05195471,0.037295185,0.0041028783,-0.055039465,0.09356222,-0.10345354,0.081971355,-0.0411328,0.019096455,0.004884194,0.00065590534,-0.03304812,0.07632662,-0.10889027,0.113872945,-0.087249786,0.039792467,0.008064525,-0.03598553,0.03344345,-0.004722716,-0.03318266,0.058767293,-0.05637741,0.023769023,0.026763445,-0.074230015,0.09895886,-0.09198032,0.05928275,-0.018900119,-0.007771306,0.0062634847,0.024000302,-0.06940872,0.10867462,-0.12303405,0.105242014,-0.06305182,0.015509717,0.016158836,-0.018701721,-0.0068358965,0.045647893,-0.07630611,0.08107835,-0.05447755,0.005942447,0.044636495,-0.076401375,0.07747482,-0.050602693,0.011786849,0.017435767,-0.02036491,-0.0068138824,0.053162906,-0.098204024,0.12171019,-0.11338241,0.07777269,-0.030632472,-0.0080404505,0.021524632,-0.004424975,-0.033674516,0.0728275,-0.0923151,0.08061019,-0.0409383,-0.010231849,0.051044885,-0.064696126,0.047445934,-0.010369122,-0.025998667,0.041550077,-0.026288427,-0.014839692,0.06427928,-0.10025038,0.10716094,-0.08305704,0.040538557,-0.0007017213,-0.016986942,0.0040299026,0.033026807,-0.07573741,0.1026111,-0.099432014,0.06609595,-0.016685676,-0.027251758,0.047002878,-0.035623714,0.0012299534,0.036935646,-0.057772364,0.04848223,-0.01074993,-0.040021904,0.08205596,-0.09760193,0.08140982,-0.04321294,0.0030304343,0.018457804,-0.009848494,-0.025500396,0.07106773,-0.10508391,0.11096758,-0.08528001,0.039383564,0.005991433,-0.030666405,0.024665013,0.0070323343,-0.046909127,0.07334745,-0.07103194,0.03367254,0.012826142,-0.05994852,0.08775305,-0.08541395,0.056372866,-0.01665265,-0.01285778,0.01644768,0.0018969252,-0.047551643,0.0947325,-0.12160652,0.11568671,-0.07981302,0.030790644,0.00866141,-0.020791188,0.0013072097,0.038587607,-0.07759634,0.09457299,-0.07869937,0.034713697,0.019316543,-0.060610417,0.07254773,-0.052588448,0.013441103,0.0230794,-0.0365587,0.0178162,0.026650853,-0.077743895,0.11288569,-0.11681554,0.08888164,-0.04333446,0.0024807013,0.014019336,0.0014205998,0.06389889,-0.037533127,0.00060887204,0.027555738,-0.031983297,0.009241256,0.030891925,-0.07009773,0.090286404,-0.082259424,0.050112423,-0.009267625,-0.006413979,0.011080004,-0.00082791183,-0.026525807,0.056665722,-0.07369942,0.06779985,-0.039942905,0.0014683075,0.031326063,-0.044965092,0.034094814,-0.013143029,-0.009511355,0.021300143,-0.014962905,-0.007946863,0.0377835,-0.061413173,0.06849291,-0.05641442,0.031542454,-0.0061541703,-0.007452836,0.0028588127,0.0174017,-0.04306027,0.061046578,-0.061767194,0.04372041,-0.014234218,-0.014026603,0.029109986,-0.025482371,0.0066554695,0.016525052,-0.031108027,0.02827503,-0.007596951,-0.022732466,0.049798522,-0.062132463,0.055186942,-0.033495087,0.008478297,0.0070458404,-0.0050219926,-0.013971116,0.0409921,-0.06302145]	2026-01-14 17:02:37.877558+00
757ea084-239c-4304-8cb7-b8b84ea24a46	32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	API Security Guidelines		1	0	1	2	[0,0.039751325,-0.063408114,0.06254655,-0.040407162,0.010297064,0.010832211,-0.010551586,-0.013050472,0.050419606,-0.0850892,0.10155307,-0.09268281,0.06313379,-0.02710676,0.001538519,0.0020135306,0.017098114,-0.048317008,0.07496591,-0.082269594,0.06447018,-0.027622927,-0.013268492,0.041404426,-0.0462005,0.028317327,0.0007022667,-0.024013832,0.027593268,-0.007005219,-0.030428026,0.06909771,-0.09255617,0.091370426,-0.0676168,0.033861943,-0.0071191876,0.00067829125,-0.017726125,0.049817137,-0.08092696,0.09514552,-0.08432091,0.05198869,-0.011702469,-0.019434372,0.028934812,-0.014877372,-0.013213555,0.03897765,-0.0471079,0.030735796,0.005229258,-0.04640812,0.07580174,-0.081898965,0.0641557,-0.033218727,0.0057876664,0.0034210156,0.01124557,-0.04364711,0.07878031,-0.09996424,0.096835785,-0.07032165,0.032202933,0.00051905325,-0.013754566,0.0030561714,0.024278376,-0.05273889,0.06607681,-0.05513635,0.02228735,0.019666264,-0.053579777,0.06614186,-0.054211073,0.026277311,0.0016519299,-0.0137673,0.0020752987,0.029735113,-0.06803145,0.09574889,-0.10055215,0.08073506,-0.04602932,0.012934899,0.0031890566,0.00451947,-0.03114874,0.06238719,-0.0814094,0.0769721,-0.048837963,0.007926212,0.028882897,-0.046799075,0.04016907,-0.015141539,-0.01332721,0.028690288,-0.020789,-0.009232941,0.04943667,-0.08277431,0.095228255,-0.082501605,0.05205237,-0.01949648,0.001104635,-0.005990707,0.03173732,-0.065556064,0.09042607,-0.0932675,0.071230926,-0.03308664,-0.0049524885,0.026972322,-0.02495166,0.002568709,0.026604624,-0.045654222,0.042479053,-0.015639402,-0.024906784,0.062533155,-0.081873044,0.076145716,-0.050368793,0.018917125,0.0014008536,0.00057087175,-0.024964929,0.060810212,-0.09128091,0.101758376,-0.08684044,0.05293751,-0.015210461,-0.009681472,0.011546084,0.008482045,-0.038517095,0.06165639,-0.06412362,0.04191588,-0.0027667494,-0.037516363,0.06258535,-0.06334366,0.042262416,-0.012151461,-0.010024561,0.011319544,0.010950842,-0.047890015,0.08325843,-0.10123703,0.09399436,-0.06542916,0.029294495,-0.002602636,-0.0025269105,-0.015332201,0.046245333,-0.07370155,0.08255638,-0.06632391,0.030321429,0.01084173,-0.040227644,0.046647534,-0.02998131,0.0011891838,0.022989614,-0.0281084,0.008984161,0.027774915,-0.06689805,0.09173712,-0.09221616,0.0696339,-0.036017384,0.008336643,-0.0003548669,0.016021734,-0.047577746,0.07927853,-0.09495333,0.085773505,-0.054506004,0.014212118,0.017984997,-0.029076198,0.016366087,0.011275413,-0.03770907,0.047309496,-0.032502934,-0.0025551633,0.04392677,-0.074529506,0.082284294,-0.065866575,0.035304166,-0.007135722,-0.0035483728,-0.00963398,0.041276988,-0.07676466,0.099270076,-0.09782048,0.0725612,-0.034694485,0.0011225721,0.0136370035,-0.0043875286,-0.02228444,0.051200595,-0.06590557,0.056597076,-0.024868604,-0.017010005,0.051929805,-0.06609977,0.055613287,-0.02827634,-0.00017840373,0.013675758,-0.0035433997,-0.027295796,0.06569509,-0.09456186,0.101032466,-0.08262479,0.048418723,-0.014698622,-0.002852683,-0.0033341888,0.029099036,-0.06056533,0.080817275,-0.07803884,0.051211953,-0.010641163,-0.026947295,0.046382833,-0.041279994,0.017054487,0.011719661,-0.028343907,0.022046762,0.006808051,-0.046854705,0.08113644,-0.095200926,0.08399883,-0.054278515,0.021328948,-0.0016329756,0.0049536442,-0.029648151,0.063456304,-0.08938545,0.09387009,-0.07329375,0.035745803,0.002829582,-0.026246116,0.025800336,-0.004405406,-0.02484764,0.045010693,-0.043450113,0.0179503,0.022177916,-0.06051619,0.08136689,-0.07723789,0.052395854,-0.02078497,-0.0006905167,0.00029852893,0.02287334,-0.058463253,0.08979167,-0.1018527,0.08850875,-0.055438805,0.01742673,0.008710489,-0.012164064,-0.0067108953,0.03659692,-0.06067582,0.0647312,-0.044006318,0.005528538,0.035214845,-0.061656237,0.06404525,-0.044078223,0.014040661,0.009125445,-0.011984281,-0.008915514,0.045353677,-0.08135168,0.10081077,-0.095212735,0.06769154,-0.031523682,0.0037612373,0.002939571,0.013623527,-0.04415864,0.072355896,-0.082733475,-0.040898338,0.0014840225,0.024536226,-0.027185608,0.007873425,0.021322316,-0.043489754,0.045037206,-0.022256045,-0.016855016,0.056379568,-0.08007087,0.07909958,-0.056247875,0.024539413,-0.0009627643,-0.0017018524,-0.01896675,0.05385206,-0.08665862,0.10171849,-0.09150264,0.060235586,-0.021880452,-0.00654002,0.0130840475,0.0034096488,-0.032795787,0.05852166,-0.06560195,0.047844965,-0.0108648315,-0.0305652,0.059550095,-0.06512753,0.04747833,-0.017795408,-0.0071253804,0.0129782,0.0051569017,-0.04042216,0.0774416,-0.09966955,0.09730502,-0.07197771,0.035958856,-0.0062756026,-0.0034492407,-0.010480554,0.040077433,-0.069520205,0.08276517,-0.071268536,0.03811704,0.0034143678,-0.03618669,0.047371395,-0.034556437,0.0068568923,0.019501649,-0.029008538]	2026-01-14 17:03:53.967464+00
71fac788-156a-4544-b3f0-083f4f0b802b	32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	Session Management	Sessions are stored in Redis with a 48-hour TTL.\nAll sessions require re-authentication after password change.	2	3	12	15	[-0.08553417,0.085706696,-0.08942989,0.09343071,-0.09363197,0.08714074,-0.07367895,0.055769425,-0.035658363,0.003458248,0.0010698731,0.023901671,-0.05076878,0.06560908,-0.06007521,0.035416234,-0.0019006559,-0.026082903,0.036898434,-0.027213976,0.0035703524,0.02078445,-0.032277018,0.023546029,0.0029994326,-0.036307324,0.061955713,-0.06904358,0.055395797,-0.028587045,0.0022939248,0.010275341,-0.0027231956,-0.021464039,0.05058566,-0.07033833,0.070679374,-0.050650846,0.018851172,0.010671901,-0.02513813,0.019141136,0.0027831946,-0.028357346,0.04347632,-0.03899922,0.0151614295,0.0185085,-0.04772796,0.06027943,-0.051840514,0.028030057,-0.0016896079,-0.013295861,0.008674908,0.014197483,-0.044996195,0.06936659,-0.07580069,0.061152168,-0.03214588,0.002158121,0.015188626,-0.01254551,-0.007654199,0.034379914,-0.053313483,0.053737704,-0.033700373,0.0009775038,0.030626552,-0.047868572,0.044386473,-0.02372013,-0.0024149804,0.01977308,-0.018435173,-0.002410276,0.03405564,-0.062429156,0.07482479,-0.065980434,0.040590312,-0.011047215,-0.008502887,0.008943107,0.009447076,-0.037133455,0.059909597,-0.06572288,0.05047097,-0.019989207,-0.012724278,0.033715643,-0.034738857,0.017181128,0.008631401,-0.0284144,0.03080392,-0.012834274,-0.0056059165,0.019272191,-0.06578344,0.066565104,-0.04752717,0.016862512,0.053747483,-0.07471293,0.03856479,-0.0056926366,-0.025281306,0.03967822,-0.030836742,0.0033031434,0.029353255,-0.051051874,0.050917603,-0.028502412,-0.0059918636,0.036596507,-0.04922358,0.038411524,-0.009934631,-0.021974765,0.04145924,-0.03864811,0.01439834,0.020108705,-0.048721466,0.05805624,-0.043909058,0.0132671315,0.01904448,-0.0374731,0.033196416,-0.008352291,-0.02498763,0.047897,-0.065626174,0.059698112,-0.031139942,-0.0082639465,0.04159249,-0.054870423,0.043737825,-0.0155093735,-0.014363577,0.029731235,-0.021517118,-0.007903485,0.045818094,-0.07525061,0.08308214,-0.06632566,0.033546254,-0.00074619846,-0.016312135,0.009664381,0.017040478,-0.05029686,0.073229015,-0.07369689,0.050134726,-0.012322651,-0.013613112,0.017926723,-0.0017978923,-0.023881527,0.043505363,-0.044287033,0.02244282,0.01494092,-0.053252794,0.07731058,-0.078591056,0.059269853,-0.031134859,0.009895092,-0.007614172,0.02689696,-0.0596171,0.090795964,-0.10577342,0.0972324,-0.068709366,0.032907326,-0.0056202803,-0.0018181885,-0.012058175,0.038177934,-0.06131904,0.0674493,-0.050500054,0.015324569,0.024578048,-0.04844801,0.06881026,-0.06278758,0.03502676,-0.00046727702,-0.022847058,0.022442486,0.0025837775,-0.04111363,0.075325176,-0.08922764,0.08304953,-0.030223226,-0.024275277,0.056289982,-0.052613813,0.01728769,0.030372398,-0.0650738,0.06771223,-0.00029803585,-0.046531897,0.0862989,-0.103224754,0.09219468,-0.06116299,0.027297856,-0.008714045,0.015758265,-0.046025895,0.085498795,-0.11525891,0.12055875,-0.09789984,0.05672498,-0.014912842,-0.009765349,0.008131182,0.016041446,-0.04788229,0.068605594,-0.064572014,0.03388586,0.012636465,-0.05659196,0.080754064,-0.077272385,0.051378686,-0.018823,-0.0017298822,-0.002302885,0.03134668,-0.07342877,0.109888524,-0.12430103,0.11033591,-0.074783534,0.03429777,-0.0074170697,0.0056894016,-0.028156219,0.061839823,-0.088000074,0.09116,-0.06657214,0.02254507,0.023486163,-0.05326251,0.05639629,-0.035291318,0.0039295782,0.018892756,-0.018635975,-0.00795588,0.05124135,-0.093256,0.11628245,-0.11130758,0.0823125,-0.044338968,0.016259534,-0.011718436,0.03258676,-0.068070084,0.09989632,-0.11109624,0.09416624,-0.0546993,0.008742566,0.02485206,-0.03341733,0.016490716,0.014020474,-0.039607264,0.044093814,-0.02145402,-0.02123891,0.067145035,-0.097675465,0.10135199,-0.07926137,0.04448997,-0.015810456,0.0086482,-0.030370643,0.054782595,-0.08006568,0.09527922,-0.08760946,0.082211666,-0.075176165,0.07019022,-0.06936604,0.07223237,-0.07597396,0.07680374,-0.07180962,0.060389865,-0.044588163,0.028167123,-0.01486351,0.0066609066,-0.002906986,0.000697577,0.0036577263,-0.057383206,0.059798278,-0.06077985,0.064193204,-0.07224669,0.08437314,-0.097450525,0.107257076,-0.1104636,0.10620839,-0.096499905,0.07404478,0.014111386,-0.0038662048,-0.022524826,0.05298693,-0.07326213,0.07374013,-0.054064423,0.023305193,0.004383887,-0.016542675,0.0083661415,0.015007712,-0.040980287,0.055554688,-0.0500708,0.02538356,0.008519372,-0.037277635,0.04901407,-0.039999712,0.016412225,0.008654977,-0.021498347,0.014400842,0.010643747,-0.042864844,0.06786002,-0.07448423,0.060180478,-0.0321962,0.004102284,0.010716158,-0.0054762005,-0.016755681,0.044542518,-0.06357261,0.06353693,-0.0430904,0.010518015,0.020213962,-0.036128722,0.03143356,-0.0102687115,-0.015307125,0.03112829,-0.02774375,0.004977581,0.0279587,-0.056856297,0.06929719,-0.06058584,0.035980858]	2026-01-14 17:03:53.975822+00
29e3df85-64f0-4d22-b905-5f9f71b99294	32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	Overview	Security guidelines for the Agentic Platform API layer.	2	1	3	5	[0.061199557,-0.061700616,0.068856835,-0.081342496,0.094680354,-0.10336487,0.1034881,-0.094609484,0.07997299,-0.06496749,0.054568283,-0.050986115,0.05265033,-0.05501309,0.052788228,-0.0425504,0.024447268,-0.0022027318,-0.018591492,0.033078045,-0.039383378,0.03943719,-0.03797018,0.04017186,-0.049132593,0.06429738,-0.08167378,0.09569521,-0.101846956,0.09879647,-0.08900719,0.07754181,-0.06962913,0.068161204,-0.07232068,0.07799636,-0.07978733,0.07363417,-0.058815118,0.0383492,-0.017612273,0.0018284274,0.006361418,-0.008089151,0.058962587,-0.055002682,0.04288623,-0.031168371,0.0278872,-0.03667211,0.054971654,-0.07525105,0.08858561,-0.08892744,0.07599986,-0.0554318,0.036067758,-0.025742957,0.027549118,-0.038380984,0.050460014,-0.05510414,0.04693552,-0.026508039,9.402024e-05,0.023268387,-0.036052343,0.035794064,-0.026217135,0.0153911915,-0.0118086925,0.020261707,-0.039496455,0.06277094,-0.08104894,0.08729963,-0.07984164,0.06312884,-0.04560112,0.03563113,-0.037510328,0.049398948,-0.06422271,0.0730861,-0.06956529,0.052821968,-0.028044594,0.0040048137,0.011099935,-0.013525077,0.0057199323,0.004902829,-0.009578409,0.0024494226,0.01656944,-0.041696034,0.06400125,-0.07564173,0.07357623,-0.060984265,0.04570762,-0.036462374,0.038638186,-0.051699225,0.024947755,-0.018752111,0.016176876,-0.016337413,0.016874228,-0.01511975,0.009414844,5.6815996e-05,-0.011317132,0.021502163,-0.028195882,0.03055022,-0.029654965,0.027980762,-0.028162746,0.031708606,-0.038250875,0.04570241,-0.051240783,0.052649893,-0.04937567,0.0331297,-0.042644825,0.042152606,-0.028963841,0.0063601024,0.01793239,-0.03539887,0.040769875,-0.03449953,0.022500679,-0.013264688,0.013747496,-0.025995158,0.046127412,-0.06616716,0.07783921,-0.07651722,0.06342683,-0.045048777,0.030008439,-0.024943085,0.03132846,-0.04478601,0.057202764,-0.06064706,0.051202297,-0.030880058,0.0066947495,0.012657161,-0.020921735,0.017239116,-0.006507553,-0.00301387,0.0037136269,0.0076753856,-0.028463786,0.051252097,-0.06743863,0.07130761,-0.062737875,0.047234062,-0.033265553,0.028189575,-0.015577886,0.0042703585,-0.0045572636,0.013818023,-0.02495585,0.02984176,-0.023255523,0.0054333606,0.017999891,-0.038682308,0.049479485,-0.047862,0.037077043,-0.024553034,0.01830284,-0.023050608,0.03793984,-0.056921955,0.07163947,-0.07542157,0.0664766,-0.048750702,0.030041177,-0.018268753,0.017696202,-0.030895235,0.025239833,-0.015364676,0.005618792,-0.00017266744,0.0010264365,-0.007060378,0.014582834,-0.019112667,0.017541423,-0.009638301,-0.0018238759,0.012382343,-0.018008094,0.01702159,-0.010882231,0.0034732725,0.0007746871,0.0009783028,-0.008607384,0.019071627,-0.027862474,0.031157538,-0.027647227,0.019158443,-0.009776405,0.0038856745,-0.0040696636,0.009875712,-0.018037792,0.02404997,-0.02433607,0.017975137,-0.0071551804,-0.0038624948,0.010772059,-0.011272477,-0.01847434,0.016315177,0.0018853262,-0.030348903,0.05820281,-0.07464985,0.07410549,-0.05883975,0.037857488,-0.022554697,0.021233672,-0.03510731,0.057708558,-0.07798829,0.08561633,-0.075943895,0.052247956,-0.024181189,0.0031703883,0.0030307793,0.0059766714,-0.023085766,0.0371345,-0.038303696,0.022872936,0.065696105,-0.073517926,0.06800963,-0.053447805,0.038083658,-0.030167092,0.033977386,-0.04776389,0.06458422,-0.07563809,0.074498236,-0.06020957,0.03777052,-0.015765227,0.0022815007,-0.0010712849,0.0097938925,-0.0020482186,-0.018739784,0.040491108,-0.05764972,0.06663119,-0.06746912,0.06373155,-0.060748488,0.063001275,-0.07192651,0.085188106,-0.097767144,0.104347475,-0.10185352,0.09092369,-0.07561296,0.061467044,-0.052891333,0.05107559,-0.053468943,0.055056144,-0.05082237,0.03822382,-0.018478526,-0.003942699,0.023382157,-0.035628796,0.039857812,-0.03894766,0.038023613,-0.041927457,0.052827597,-0.06911654,0.0861254,-0.09831361,0.10188481,-0.09657527,0.08575778,-0.07481167,0.06854057,-0.06887615,0.07396863,-0.07909998,0.07898147,-0.07033341,0.053509556,-0.032386493,0.012570033,0.0012222442,-0.0073485663,0.00795284,-0.0078577055,0.012172729,-0.023765784,0.041811224,-0.06211217,0.0790435,-0.08818504,0.088383414,-0.08225482,0.074888475,-0.07137309,0.07433273,-0.08265408,0.092015505,-0.09696428,0.09354602,-0.08122526,0.06317602,-0.044802453,0.031198261,-0.024762185,0.024112022,-0.024816813,0.021595113,-0.010924136,-0.007192364,0.029146407,-0.04937673,0.062958054,-0.067888334,0.06597861,-0.06191968,0.060974367,-0.06640255,0.0778545,-0.09150357,0.10185504,-0.10436438,0.097609684,-0.08397682,0.06852879,-0.056601025,0.05127546,0.0013382973,-0.013051172,0.01213989,-0.0026752886,-0.007128251,0.00890851,0.0017781967,-0.023270588,0.048545104,-0.06853247,0.07641873,-0.07086925,0.056630634,-0.042222384,0.03582579,-0.041341417,0.056505967,-0.07397152]	2026-01-14 17:03:53.970932+00
a1a43137-cea5-430e-8fd6-28729f5247a8	32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	Authentication Configuration	The platform uses the following authentication settings:\n- JWT tokens signed with HS256 algorithm\n- Token expiration: 24 hours for access tokens, 30 days for refresh tokens\n- Rate limiting: 1000 requests per minute per API key	2	2	6	11	[0.09935965,-0.098486,0.07862258,-0.050363585,0.02787302,-0.02208392,0.035453968,-0.06079207,0.084718384,-0.1175338,0.08978199,-0.04563504,0.0023464032,0.02359558,-0.024306986,0.0042175897,0.02212726,-0.03711709,0.028597407,0.004225346,-0.050327454,0.09208017,-0.11363255,0.08623879,-0.0623884,0.04040806,-0.031968784,0.041737262,-0.065128654,0.09050334,-0.08343966,0.07827866,-0.06383269,0.045926794,-0.03162282,0.025857208,-0.029103985,0.03718309,-0.043305393,0.04137319,-0.02895306,0.008494847,0.01378846,-0.030843748,0.038103074,-0.035617728,0.027978724,-0.022062687,0.023684748,-0.034764048,0.052361637,-0.070052706,0.080975786,-0.08109743,0.07112739,-0.05616637,0.04325543,-0.038002048,0.041900583,-0.05163169,0.060676415,-0.062470626,0.053586975,-0.035418108,0.01355351,0.0048519257,-0.01445671,0.014239668,-0.0079338355,0.0021801519,-0.003287082,-0.009284402,-0.025398586,0.060423523,-0.08288444,0.085644305,-0.07070055,0.04817572,-0.03141802,0.030561663,-0.047635145,0.075563505,-0.10154327,0.1131722,-0.06814854,0.0363475,-0.008270102,-0.004559952,-0.0017716644,0.021727879,-0.04301398,0.052514937,-0.04262891,0.014959463,0.020404534,-0.049676787,0.061934404,-0.0180603,0.02490889,0.0065810494,-0.017532412,0.00076593715,0.037307493,-0.07973536,0.08098364,-0.06923391,0.061300825,-0.033246934,-0.0018743383,0.025776193,-0.025711676,0.0006054715,0.038413316,-0.0733331,0.087885,-0.07533588,0.041712917,-0.0029135717,-0.022913277,0.024062103,-0.00087264,-0.034446854,0.06369003,-0.071401626,0.08855647,-0.055945866,0.010656419,0.017809039,-0.0403324,0.02555666,0.016792107,-0.063529186,0.08917237,-0.0782077,0.032577973,0.029197218,-0.06960132,0.0742623,-0.047282994,0.003678601,0.038012695,-0.03814727,0.009174869,0.03528204,-0.074004255,0.08834834,-0.07118673,0.030329121,0.01521555,-0.044344287,0.043966845,-0.0152685,-0.026873883,0.06104222,-0.06956536,0.04701195,-0.0028154338,-0.043227457,0.070427,-0.06709901,0.036145955,0.006355036,-0.038879856,0.04479542,-0.020350859,-0.023509827,0.066383004,-0.05247096,0.07858922,-0.055238362,0.0532417,-0.034824234,-0.014625274,0.04069086,-0.039770573,0.010747626,0.03387991,-0.073969536,0.091372505,-0.07861893,0.042485755,-0.0030819823,-0.034785204,0.010902915,0.015367396,-0.054770116,0.088056795,-0.09859821,0.080367975,-0.04084712,-0.0025432461,0.030771054,-0.032291036,0.0062045553,0.018357985,-0.035495304,0.03568196,-0.017518768,-0.011575946,0.038903166,-0.052552506,0.04709436,-0.02616588,0.000711222,0.016279992,-0.016013008,-0.0018851652,0.02917913,-0.052968338,0.06186962,-0.05147471,0.026466057,0.0016235725,-0.019933589,0.020432394,-0.0037566586,-0.021107549,0.041148722,-0.045585483,0.031054147,-0.0032407434,-0.025825346,0.0435188,-0.021336699,0.0035706877,0.011797471,-0.014999571,0.002201883,0.022620954,-0.04955804,0.0413354,-0.031639706,0.015231075,-0.0005267512,-0.005013244,-0.0015306671,0.017133676,-0.034275137,0.0445451,-0.0426796,0.02908986,-0.009672624,-0.007007522,0.013813013,-0.008442184,-0.0054821037,0.020165803,-0.027398072,0.022506325,-0.006615329,-0.013873107,0.030330673,-0.036020987,0.029311528,-0.0144393565,-0.0005363093,0.007612668,-0.002693226,-0.012437115,0.030958945,-0.044281278,0.046156164,-0.06182005,0.055414062,-0.040891014,0.025238687,-0.01569903,0.016299935,-0.025932478,0.03889538,-0.047645435,0.07774186,-0.02728318,-0.033600666,0.07156235,-0.07274399,0.040960975,0.0041954955,-0.036819503,0.03717765,-0.0012342478,-0.06704763,0.115728885,-0.14712077,0.1483103,-0.1202384,0.07722519,-0.040090643,0.026168898,-0.04100444,0.061234493,-0.10231301,0.13226195,-0.13437438,0.104736924,-0.04025359,0.02169505,-0.012222725,0.014329728,-0.024686053,0.035771288,-0.039520156,0.031232325,-0.01187122,-0.012351103,0.0329047,-0.04298363,0.040721796,-0.030041547,0.018728916,-0.014658995,0.021981971,-0.03909904,0.059399247,-0.074404426,0.077814706,-0.06851519,0.05110242,-0.033678357,0.023969557,-0.02563228,0.03651497,0.0355932,-0.06188875,0.06842019,-0.055512574,0.032603562,-0.013667818,0.010470091,-0.026882613,0.05699211,-0.087904625,0.13957416,-0.122672595,0.08678404,-0.04839699,0.024589743,-0.024862502,0.046612073,-0.07641848,0.09652594,-0.09341009,0.06432293,-0.018676316,-0.0264002,0.055866748,-0.049855005,0.031548064,-0.013565414,0.008130804,-0.021155337,0.049351864,-0.08176509,0.07122362,-0.073313415,0.065630086,-0.05343798,0.043744087,-0.041920327,0.049116626,-0.06170527,0.07302305,-0.076575816,0.06916883,-0.052461732,0.03220221,-0.015505347,0.007482556,-0.008835822,0.015570019,-0.020960482,0.018831639,-0.006573845,-0.013548914,0.035428364,-0.05198561,0.058512233,-0.054877568,0.045544762,-0.037388504,0.036361516,-0.04460865,0.059412796,-0.074478425]	2026-01-14 17:03:53.973432+00
ad1eba16-7b94-4e8d-b651-30469ec6ddd2	32e1d912-777d-4ef2-a2d6-3e6ea7e77b7a	Password Requirements	- Minimum 12 characters\n- Must include uppercase, lowercase, number, and special character\n- Passwords hashed using Argon2id	2	4	16	20	[0.048584096,-0.016476473,-0.0073245475,0.01359182,-0.0017231329,-0.020007415,0.038456764,-0.041956943,0.025953397,0.004766527,-0.038324088,0.061400317,-0.065579,0.05134077,-0.027794093,0.008272506,-0.00390984,0.018274292,-0.045634635,0.07369018,-0.08945589,0.08548101,-0.06341984,0.03324243,-0.00846371,-0.0003216954,-0.009500752,0.031336747,-0.052574214,0.060663734,-0.04917241,0.020907955,0.0133855,-0.04013523,0.049403004,-0.039605267,0.018227931,0.0018062453,-0.008375287,-0.0039907456,0.031451017,-0.062663,0.084192514,-0.086931214,0.07044487,-0.04316789,0.018351076,-0.007705551,0.015790569,-0.03783596,0.06204318,-0.07526146,0.069317184,-0.044961493,0.01154271,0.017439637,-0.030768197,0.02484452,-0.0053709876,-0.0154278055,0.024711281,-0.05543292,0.018442106,0.029062293,-0.06654221,0.0782052,-0.060542606,0.023979424,0.012154567,-0.028920822,0.016877579,0.019371295,-0.06336552,0.09466628,-0.09864587,0.0734953,-0.031090101,-0.008700756,0.027534239,-0.01737675,-0.01565951,0.05426646,-0.07826168,0.074291244,-0.042261295,-0.0045859213,0.045988392,-0.06434518,0.053120524,-0.019942323,-0.017090136,0.038118318,-0.031078694,0.03531129,0.004259529,-0.045881327,0.07087923,-0.068465434,0.040893022,-0.0023586245,-0.027819611,0.03447758,-0.013886755,-0.024449773,0.062347982,-0.08165854,0.04853306,-0.032386303,0.005735648,0.01811124,-0.02727737,0.017017983,0.007999049,-0.035927415,0.053419996,-0.05202774,0.032251675,-0.0033052654,-0.021298965,0.030222608,-0.019730644,-0.004526171,0.030230321,-0.044314086,0.03923668,-0.016612072,-0.013552088,0.03763978,-0.04494193,0.032777973,-0.00776841,-0.017351836,0.029850958,-0.023115486,-0.00016911617,0.029297587,-0.050670575,0.054309417,-0.038636416,0.011228705,0.014815734,-0.027157472,0.057923377,-0.076515496,0.04772977,-0.009366295,-0.02076491,0.028998774,-0.012355017,-0.020047944,0.0513827,-0.065201156,0.05334304,-0.01987236,-0.020845927,0.055332176,-0.07569703,0.072751336,-0.049897537,0.019850546,0.0014859544,-0.002668137,-0.017782135,0.05065441,-0.08045654,0.12374243,-0.11472769,0.063985,-0.01959831,0.0021298209,-0.018670581,0.059460543,-0.10259664,0.12457113,-0.11158676,0.06622283,-0.006255238,-0.043804772,0.06439702,-0.050221853,0.012710036,0.025530007,-0.041624125,0.023470478,0.024389798,-0.082885206,0.0983622,-0.09092627,0.06129423,-0.025550755,0.0023487923,-0.003942522,0.030294273,-0.06908129,0.10159927,-0.111732155,0.0936875,-0.054788228,0.011982237,0.016257154,-0.0187567,-0.0030363312,0.03578923,-0.0607213,0.062656485,-0.03734992,-0.0064252145,0.0510319,-0.07837357,0.07851974,-0.05441786,0.020433255,0.0045823297,-0.006369324,-0.017867412,0.05564333,-0.10495136,0.13427508,-0.1286769,0.08950519,-0.033768468,-0.013992024,0.0334352,-0.018133257,-0.021391375,0.06276078,-0.07527894,0.07720143,-0.042161334,-0.015552087,0.070740186,-0.099338435,0.0899174,-0.0491273,-0.0015237377,0.036012497,-0.036305044,0.0010267207,0.053859536,-0.10269215,0.122404665,-0.103580005,0.05496516,0.00071841595,-0.0376599,0.0393208,-0.006346425,-0.043765966,0.089407615,-0.113517314,0.10114838,-0.0561822,-0.0021177153,0.04830624,-0.06291785,0.04175803,0.0021292598,-0.044760868,0.06275935,-0.044607405,-0.003785,0.061870873,-0.10427655,0.1129291,-0.08568658,0.03733387,0.00753304,-0.026322039,0.009293914,0.035756633,-0.08723255,0.120089546,-0.057831436,0.01441298,0.027217498,-0.04742464,0.036975134,-0.001457711,-0.04140546,0.0702668,-0.07040119,0.04078006,0.005420519,-0.047121346,0.065430276,-0.052683294,0.016101822,0.025686948,-0.051598173,0.048215184,-0.016237818,-0.029838793,0.06866118,-0.0822444,0.06458547,-0.024533695,-0.018458242,0.043665133,-0.039028097,0.006936013,0.036922432,-0.0710857,0.07861626,-0.05523033,0.01136223,0.032826405,-0.057099987,0.050836515,-0.018104715,-0.024303379,0.054940756,-0.058005948,0.030936627,0.014344832,-0.05713135,0.07784394,-0.06740469,0.031576086,0.011813711,-0.04142902,0.04266471,-0.01465524,0.084074825,-0.063447215,0.03546784,-0.013624604,0.008103469,-0.020909073,0.044913553,-0.06728951,0.07568083,-0.064152405,0.03606553,-0.0024999762,-0.023021331,0.030976154,-0.020366363,-0.0008472723,0.019606719,-0.0240625,0.009299543,0.020262977,-0.05294915,0.075385734,-0.07887847,0.06354862,-0.038246922,0.016286578,-0.009041612,0.02048023,-0.045254502,0.071262404,-0.08545385,0.08009684,-0.056499116,0.024400784,0.002671327,-0.013860376,0.0061520245,0.014216828,-0.03478796,0.042897023,-0.031789277,0.0039028397,0.030255392,-0.057102967,0.06645078,-0.05634671,0.033972275,-0.012162958,0.0032212266,-0.012989165,0.038023204,-0.06722592,0.08715283,-0.08844997,0.070335686,-0.04097792,0.0135859735,-9.0510686e-05,0.0054418915,-0.025260253,0.047963727,-0.06035394]	2026-01-14 17:03:53.978086+00
c33a683a-c9ad-473d-88e2-26aa613fc6f7	5026dbba-9135-4930-99ff-7852b4243c03	Content	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.\n\n## Consequences\nMemory usage will decrease by approximately 40%.\nQuery latency may increase by 10-20ms for complex searches.\n	1	0	1	15	[0.047602434,-0.03525335,0.037918285,-0.053530313,0.07333075,-0.086088486,0.083511956,-0.06425853,0.0356952,-0.016468275,-0.011177419,0.04029732,-0.030463615,0.006914509,0.013484652,-0.010993847,-0.0011434488,-0.014269915,-0.042817276,0.096458904,-0.12376107,0.11414927,-0.074399434,0.011019891,0.030778956,-0.018630216,-0.023140889,0.07360825,-0.10736842,0.10673954,-0.07026252,0.013427986,0.03871993,-0.01676237,-0.0026181694,0.037507184,-0.06842343,0.07757261,-0.057425432,0.014376509,0.03427088,-0.06854928,0.075348675,-0.054650597,0.019486595,0.010358316,-0.017877452,-0.0029614093,0.04428603,-0.08806125,0.114708655,-0.11247187,0.083037555,-0.040717132,0.0055818106,0.006157528,0.0100869285,-0.04509639,0.08028782,-0.09665191,0.083900645,-0.04543809,-0.0032296411,0.04188342,-0.05523715,0.04021648,-0.0073811025,-0.024190499,0.036100462,-0.025761046,-0.019312283,0.065523535,-0.09336453,0.091932215,-0.0641183,0.025188498,0.0045669395,-0.009587029,-0.0134787895,0.054149497,-0.09312882,0.11155406,-0.10004285,0.06320025,-0.01742499,-0.016933564,0.025307437,-0.00586532,-0.029643333,0.061559554,-0.071781695,0.05248813,-0.009932913,-0.03850627,0.07261311,-0.078979,0.057386268,-0.020868465,-0.010580499,0.019631473,3.614532e-05,-0.040673073,0.06727088,-0.08627688,0.06511704,-0.032089323,-0.0045181923,0.02806157,-0.03917062,0.0223452,0.006196207,-0.029983278,0.03485299,-0.015783219,-0.020657487,0.04535136,-0.05539808,0.03481373,-0.029063022,0.02144795,-0.018159766,0.023087934,-0.03591927,0.052256253,-0.06569819,0.070887916,-0.058803048,0.03669559,-0.03897275,0.031989787,-0.032359917,0.03772755,-0.043021988,0.04292749,-0.034475185,0.028298708,-0.002311183,-0.016250161,0.021765282,-0.014951114,0.0024655529,0.0063375244,-0.0039455234,-0.011659624,0.035984643,-0.064342655,0.08674326,-0.095252596,0.087248415,-0.0675728,0.046194974,-0.03342296,0.034960374,-0.049178187,0.067909695,-0.08038718,0.101829894,-0.08756659,0.05652567,-0.020352818,-0.0071873125,0.03697146,-0.033540804,0.014114051,-0.0014047711,-0.012281646,0.010505372,0.008816954,0.002093313,-6.30052e-05,-0.0071789785,0.017038157,-0.025570964,0.029363386,-0.02715735,0.020445213,-0.0127474675,0.007920077,-0.008303083,0.017365795,-0.035395887,0.031876694,-0.00817265,0.01670627,-0.025451215,0.036252603,-0.04149621,0.035209417,-5.3353586e-05,-0.015985508,0.04314883,-0.026724892,0.001686464,0.018255202,-0.032642506,0.029153459,-0.008695576,-0.01964108,0.042931136,-0.05994583,0.04526509,-0.026708402,-0.010462081,0.038553778,-0.043802004,0.023462582,0.01286885,-0.04785523,0.06472938,-0.041062467,0.027101632,0.0022697332,-0.054412473,0.0723996,-0.038721107,0.010465524,0.016520157,-0.03532093,0.038326576,-0.025482424,0.004294019,-0.0048972503,0.01570301,-0.0011907879,-0.0063450215,0.0043248287,0.010543777,-0.029414203,0.04119959,-0.03825375,0.019915571,0.007141762,-0.03207739,0.045047496,-0.041892268,0.026098404,-0.0070966287,-0.004288925,0.0010572078,0.016588978,-0.041319277,0.062172882,-0.069799975,0.06093458,-0.039954435,0.016780004,-0.0021200962,0.0023435638,0.006961495,0.009345548,-0.027095074,0.03626885,-0.030891793,0.011921363,0.013186316,-0.034025945,0.04220668,-0.03535039,0.01820789,-0.0003583135,-0.008404942,0.0027890496,0.015443528,-0.038305625,0.055403233,-0.05891029,0.04731527,-0.026143244,0.005307336,0.025856923,-0.02776969,0.011649614,0.051653836,-0.0853513,0.094231695,-0.07389784,0.05392791,-0.017997852,-0.004246341,0.00040250653,0.027514117,-0.06412152,0.089530475,-0.08891713,0.07343054,-0.026462182,-0.02518018,-0.013713672,-0.013001226,0.018772647,-0.0048175943,-0.018021906,0.034541775,-0.041876797,0.014473236,0.032677386,-0.08170999,0.11358425,-0.11714437,0.09440376,-0.05952184,0.03196438,-0.027127646,0.05241741,-0.08485515,0.112765945,-0.1219527,0.10664631,-0.07229304,0.032972664,-0.0046847393,-0.0022782416,-0.011785023,0.03618443,-0.05502543,0.054895215,-0.03136185,-0.008830854,0.050926227,-0.07540433,0.06633032,-0.065331176,0.026501209,-0.032043703,0.023655977,-0.030085312,0.050384857,-0.07651743,0.09718278,-0.10321652,0.09197269,-0.07484608,0.066550925,-0.03520305,0.021719845,-0.03191198,0.05699957,-0.05754166,0.07198968,-0.062495857,0.06704401,-0.010744494,-0.04675933,0.08153677,-0.080558516,0.04896397,0.0015301689,-0.037159618,0.026470644,0.016003923,-0.07098611,0.11288711,-0.12206432,0.094232425,-0.042516265,0.0056820763,0.001690956,0.018671507,-0.056744587,0.093597114,-0.11047906,0.09782839,-0.05987863,0.012657465,0.023664312,-0.034405682,0.01737199,0.016138755,-0.046801597,0.056581028,-0.037430298,-0.004798199,0.053107195,-0.08745369,0.09431045,-0.07310616,0.036457162,-0.00408016,-0.006694658,-0.010738985,0.049073555,-0.09057509,0.115576066,-0.11190177]	2026-01-14 17:47:31.107757+00
59823f2f-1164-4d6a-95b2-b5767de2ce2c	c36a563a-057e-4d04-a8a1-8937e8c78a5b	Content	# Authentication API Specification\n\n## Overview\n\nThis document specifies the authentication system for our platform.\n\n## Authentication Methods\n\nThe API supports JWT-based authentication. All tokens expire after 24 hours.\nUsers must refresh their tokens before expiration to maintain access.\n\n## Security Requirements\n\n- All API endpoints require HTTPS\n- Passwords must be at least 12 characters\n- Failed login attempts are limited to 5 per hour\n- Two-factor authentication is mandatory for admin accounts\n\n## Rate Limiting\n\nThe API enforces rate limiting of 100 requests per minute per user.\nExceeding this limit results in a 429 status code.\n	1	0	1	23	\N	2026-01-14 17:50:16.743579+00
fa5a4e15-4383-4692-a3ad-6ad95657797c	eb97556c-8fd9-4483-acb1-fcea72679609	Content	# Authentication API Specification\n\n## Overview\n\nThis document specifies the authentication system for our platform.\n\n## Authentication Methods\n\nThe API supports JWT-based authentication. All tokens expire after 24 hours.\nUsers must refresh their tokens before expiration to maintain access.\n\n## Security Requirements\n\n- All API endpoints require HTTPS\n- Passwords must be at least 12 characters\n- Failed login attempts are limited to 5 per hour\n- Two-factor authentication is mandatory for admin accounts\n\n## Rate Limiting\n\nThe API enforces rate limiting of 100 requests per minute per user.\nExceeding this limit results in a 429 status code.\n	1	0	1	23	[-0.09031829,0.0051225885,0.00013385293,-0.034198172,-0.025381496,-0.049171895,-0.03944435,-0.008471834,0.043821048,-0.010257135,-0.01289736,0.036070608,0.044324826,0.010834743,0.08356941,0.016633166,0.011605002,0.018229892,-0.044116315,-0.060436822,0.08471102,-0.015221178,-0.06890839,0.017328592,-0.028584994,-0.049373478,0.01998672,-0.029790454,-0.026807638,0.07683681,-0.020583361,-0.016316267,-0.018428113,0.037796237,-0.0887178,-0.015395499,-0.002922717,-0.078839764,0.032691974,-0.06810807,-0.09319614,-0.025667502,-0.08678415,0.0401402,-0.041559003,-0.004132458,-0.039565608,-0.03528487,-0.08088737,0.0860608,0.028362373,0.021059414,0.056961946,-0.020720117,-0.08635012,-0.09421536,-0.07460613,0.03550514,-0.00018955737,0.10884458,0.022355193,-0.07461335,-0.008578467,-0.018351097,0.01532052,-0.040970173,-0.06569724,-0.0601339,0.09974146,0.016064763,-0.08889563,-0.006776174,-0.124443956,0.0040594684,-0.012037299,-0.021414407,-0.06383048,-0.022069862,0.076616526,-0.06728554,-0.019802101,-0.016263945,0.06376453,0.0878232,0.057606816,0.02607879,-0.027863055,0.11605425,-0.03859385,0.031436536,0.06652511,0.033168662,0.0046740468,-0.012950719,0.041039024,0.007550477,-0.06831829,-0.010049325,-0.1057292,0.007625723,-0.067657866,0.0012108965,-0.034654945,-0.026832921,0.08057162,-0.009559654,0.020878714,0.020756781,0.052162237,0.08334033,0.01210369,-0.034251686,-0.004955312,-0.037464064,0.0066244137,0.09827382,-0.03145537,0.027593607,0.07964238,0.03595453,0.06779379,0.042643145,0.03467882,-0.10180502,0.017032849,0.0132814385,0.05414444,1.1433071e-32,-0.046342846,0.06616522,0.01117746,0.017975735,-0.014290558,-0.033406727,-0.005760724,-0.0039221453,-0.015623649,-0.01824483,-0.004022295,0.033328455,-0.00801335,-0.011519834,0.058245026,-0.038923576,0.016450629,0.0029443833,0.09547693,0.03303515,0.054197893,-0.13004267,0.08295408,0.027351616,-0.036402795,-0.0037794642,0.025133526,0.035397504,-0.026962368,0.023737352,-0.01030931,-0.009058219,-0.040815603,-0.009623566,0.011411475,0.019221332,0.08566123,-0.02834767,0.03509432,-0.066065915,-0.048375383,0.030534532,-0.057499982,0.05718464,-0.02174285,-0.031639386,0.01852456,0.011610856,0.04704122,0.10071449,-0.073299006,0.07740573,-0.033137836,-0.0807366,0.024800545,-0.031109538,-0.022583129,0.012171819,-0.08351617,-0.020568177,0.012938339,-0.06636024,0.013976495,-0.044916883,-0.019698793,0.051900133,0.0009479372,0.011895624,-0.03385256,0.0341931,0.06086616,0.053467147,0.037839334,-0.0614689,-0.13955784,-0.035726126,0.1752279,0.075445406,0.044452243,0.024070632,0.07380859,-0.05641917,-0.0053843944,0.061755765,0.03217296,0.013219079,0.019668864,0.004536449,-0.08213318,-0.00983269,0.03657454,-0.07240017,0.057892278,0.0523532,-0.036059387,-1.01387144e-32,-0.00920365,-0.048630223,0.029285878,0.021904977,0.025801757,-0.027132494,-0.038544677,0.11763239,-0.031397875,0.026208758,0.008850296,-0.0037269336,0.067648284,0.013762017,-0.027506761,0.009570519,-0.04515917,-0.0006887052,0.022716835,-0.037297912,-0.0058547924,0.04052301,-0.038082413,0.012427971,0.016231027,0.032209363,-0.09909269,-0.023235448,-0.0072609033,-0.048706576,0.074130684,-0.058293592,-0.010928548,0.011631685,0.007307366,-0.15734546,0.07913769,0.14596504,0.02138761,0.01790754,0.08799271,-0.057588503,0.025005667,-0.021324571,0.006561268,0.02511148,-0.0074157557,0.0071881595,-0.08942312,-0.0019629553,0.01693877,-0.05903723,0.017113551,-0.0016241478,-0.022210078,-0.012054484,0.018393008,0.02869278,0.031967815,-0.023406472,-0.004283344,-0.051125515,0.03493542,0.14818355,-0.00636873,-0.04008479,-0.049048264,0.10563831,-0.07023423,0.03455783,0.040575176,-0.04386478,-0.030950574,0.045451205,0.028752841,-0.042080425,0.016549788,-0.092349604,-0.00023267488,0.0057495204,-0.073386356,0.047159158,-0.057441153,0.022348043,0.06391899,-0.087614484,0.008418213,0.029020274,0.04070462,0.04807121,0.033489753,0.0021363464,-0.06447025,0.043879457,0.00928012,-5.0457043e-08,0.009121322,-0.01203923,0.015240588,-0.035981603,0.012888943,0.08392665,-0.01293182,-0.043769866,0.018505149,0.039574146,0.10164322,0.020893332,-0.035557702,-0.07282307,-0.0787128,-0.026665313,-0.044845544,-0.026557853,0.010287314,-0.046067394,-0.07995422,-0.027193831,0.028771255,-0.067462556,-0.02792328,0.037638724,0.07325985,0.11899623,-0.04303376,-0.012186848,-0.09900412,0.041836865,-0.004102721,-0.07506652,-0.087428175,0.011194008,-0.051519707,-0.08565266,-0.06650224,0.0044136117,-0.030602619,-0.044118192,0.02057343,0.014730599,0.041951165,0.033368178,-0.0149644185,0.025732666,0.037414473,0.00052712235,-0.001777291,0.041876495,0.012172521,0.06962655,-0.03820857,0.065834925,-0.0018782207,0.011512415,0.08617241,-0.05230007,0.10888802,0.07443421,0.036731124,-0.035764124]	2026-01-14 17:53:46.917683+00
30f69bc7-041f-49c3-b85a-35da3368d4c5	5941db0b-8fbf-44c8-ac52-5ac688ac8422	Content	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.	1	0	1	10	[0.019177882,-0.018898759,-0.04426501,0.033431903,-0.019915188,-0.05163123,-0.0796716,0.018727584,0.044522785,0.021913847,-0.083917506,0.04763559,-0.01660692,-0.03994266,-0.0015625198,-0.012262027,0.04773461,0.00799227,-0.05572599,-0.09389394,0.03156081,-0.020484721,-0.012421968,-0.06515133,-0.07347579,-0.04839906,-0.03253597,-0.019132616,-0.013932071,-0.040666018,0.008338815,-0.015178445,0.068746336,0.08208873,-0.07696376,0.10315318,0.00095837587,-0.14066522,-0.05912433,-0.008712068,0.030668283,-0.0039098766,-0.06551486,0.045439504,0.03409974,-0.057165746,-0.038693033,0.053132694,0.017657854,-0.015605455,-0.021396061,-0.009125348,-0.027349297,0.016800351,-0.0412514,0.068833545,-0.06790402,-0.053339764,-0.037571084,-0.06371681,0.055114742,-0.09197821,-0.026811017,-0.030393096,-0.0675832,0.0042271977,0.05832411,-0.09083766,0.09243547,-0.030935442,-0.001974594,0.0029972543,-0.06246038,-0.022545941,-0.025775153,0.017578702,0.08875414,0.04349829,0.04091676,-0.036860384,-0.018601447,-0.0057502845,-0.008365264,0.043200668,0.009814699,-0.039770875,0.020196252,-0.058878303,-0.003908051,-0.0061999615,0.0574618,-0.000739722,0.062884666,-0.03674477,-0.016301118,0.009239243,-0.016060824,-0.002385244,0.017394736,-0.0024885177,-0.030840192,0.045471117,0.048310984,0.0706624,-0.1212178,-0.036729246,-0.08422325,0.032396495,-0.0086961,-0.038275305,0.049727116,0.022724468,0.048063606,-0.027111605,-7.341316e-05,0.08510487,-0.07493397,-0.08693954,0.06523588,0.009916491,0.09386403,0.03509409,-0.03499985,-0.09185595,-0.0036730948,-0.03445356,-0.053064167,7.286481e-33,-0.023776557,0.065199256,0.029153524,-0.019542092,-0.033680364,0.04047401,0.026073046,0.07160516,-0.0605181,-0.018026156,-0.07882502,0.09200167,-0.028901968,0.050911732,0.07836532,0.07893845,0.06206762,0.0638576,-0.005010709,-0.01906934,0.07500853,-0.0055499976,-0.02166101,-0.03139301,0.04182693,-0.020818885,0.010954957,-0.09788385,0.008022182,-0.0006392268,-0.011517488,-0.016671108,0.0007103269,0.11993714,0.047761347,0.04603592,-0.034652386,0.065880746,-0.020382183,-0.023785954,-0.018862573,0.08345605,-0.024359554,-0.043060053,-0.036779806,-0.015457436,-0.025612785,-0.023223989,0.051671114,0.03485986,0.07999302,0.079734266,0.06601179,0.057706535,0.06764428,0.013637296,0.04193446,0.048317146,-0.0019557467,0.106698096,0.00059689215,-0.05856683,0.10029938,0.06358869,0.049112424,0.09914984,0.040303137,-0.01170407,0.061378982,0.061395414,0.029827997,0.11761413,0.114597805,-0.07279317,-0.018996015,-0.099004425,0.0075839832,-0.009213184,-0.005816692,0.0664553,-0.03432171,-0.051268958,-0.050512616,0.08223947,-0.029189631,-0.11882415,0.018588727,0.004718547,-0.011999662,-0.020704074,-0.055349182,0.0138881,-0.002283727,-0.026166337,0.041592795,-5.9660493e-33,0.0027732584,-0.14697075,-0.06825139,0.09735653,0.0065213093,-0.09043365,0.04009372,0.06936787,-0.07249697,0.0006946538,0.031373385,-0.038478598,0.039345026,0.032523498,-0.015288751,0.097338445,-0.026951363,-0.11651126,-0.06912807,0.054203283,-0.0457737,0.031093795,-0.068957016,0.04955592,0.066066824,-0.026540432,-0.0151753845,-0.078136206,-0.12257644,-0.10041546,-0.02395376,-0.018302174,-0.033820856,-0.027126048,-0.057456676,0.046757374,0.017088553,0.027001016,-0.013053394,0.037317205,0.051330816,0.0476096,-0.025529481,-0.033728473,0.03427679,0.015912566,-0.116734125,0.066386916,0.022126082,-0.028874371,0.03734107,0.034051903,-0.01461365,-0.018734004,0.09378762,-0.035759594,-0.054096375,0.068804495,-0.06979585,0.07331263,0.014664017,-0.01438006,-0.0043133995,0.05269717,0.037416894,-0.06750742,0.007864568,-0.011815919,-0.08256545,-0.0041485787,0.049767163,0.008094295,0.0010543495,0.09568427,-0.0085436115,-0.010811496,0.031589907,-0.00071638724,0.001965036,0.049332086,-0.074007414,0.03240105,0.029581705,0.08608283,0.045498595,0.04269553,0.023930758,0.0054241563,-0.0037122807,0.030044027,0.021415247,-0.049466863,-0.12886862,0.036351353,0.0022177107,-3.8379113e-08,0.0008602611,0.024018237,-0.0655583,0.026329665,0.038519755,0.041001044,0.03338665,0.088383175,-0.057021968,0.033934575,0.053829495,-0.022812461,-0.052525748,0.0056563746,0.017115006,0.009386039,0.010102626,-0.034756195,-0.02478354,-0.054226797,-0.029829398,0.08003891,-0.05149248,-0.030754091,0.06439553,-0.05317883,0.065622434,0.028727874,0.054334477,-0.033097863,0.026289336,-0.022087798,0.0025625606,-0.03196879,0.04735988,-0.061339214,-0.025914097,0.078263395,-0.079759896,0.021985415,0.027882526,0.014786013,0.012425547,-0.023377901,-0.011807707,-0.004371339,-0.07857975,-0.015013009,0.07890694,0.027458696,-0.023971956,-0.07001574,-0.040358987,0.04140173,0.03432889,-0.0055097924,0.00040052785,-0.01863178,0.04616672,-0.012028091,0.072636224,-0.06798893,-0.058588896,0.035552092]	2026-01-14 17:57:07.046379+00
e8416ffe-a993-47e2-b1a7-48b7ffe11ad6	cdf3dfed-eb8c-4b07-b9f8-255ecd10e0dd	Content	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.	1	0	1	10	[0.019177882,-0.018898759,-0.04426501,0.033431903,-0.019915188,-0.05163123,-0.0796716,0.018727584,0.044522785,0.021913847,-0.083917506,0.04763559,-0.01660692,-0.03994266,-0.0015625198,-0.012262027,0.04773461,0.00799227,-0.05572599,-0.09389394,0.03156081,-0.020484721,-0.012421968,-0.06515133,-0.07347579,-0.04839906,-0.03253597,-0.019132616,-0.013932071,-0.040666018,0.008338815,-0.015178445,0.068746336,0.08208873,-0.07696376,0.10315318,0.00095837587,-0.14066522,-0.05912433,-0.008712068,0.030668283,-0.0039098766,-0.06551486,0.045439504,0.03409974,-0.057165746,-0.038693033,0.053132694,0.017657854,-0.015605455,-0.021396061,-0.009125348,-0.027349297,0.016800351,-0.0412514,0.068833545,-0.06790402,-0.053339764,-0.037571084,-0.06371681,0.055114742,-0.09197821,-0.026811017,-0.030393096,-0.0675832,0.0042271977,0.05832411,-0.09083766,0.09243547,-0.030935442,-0.001974594,0.0029972543,-0.06246038,-0.022545941,-0.025775153,0.017578702,0.08875414,0.04349829,0.04091676,-0.036860384,-0.018601447,-0.0057502845,-0.008365264,0.043200668,0.009814699,-0.039770875,0.020196252,-0.058878303,-0.003908051,-0.0061999615,0.0574618,-0.000739722,0.062884666,-0.03674477,-0.016301118,0.009239243,-0.016060824,-0.002385244,0.017394736,-0.0024885177,-0.030840192,0.045471117,0.048310984,0.0706624,-0.1212178,-0.036729246,-0.08422325,0.032396495,-0.0086961,-0.038275305,0.049727116,0.022724468,0.048063606,-0.027111605,-7.341316e-05,0.08510487,-0.07493397,-0.08693954,0.06523588,0.009916491,0.09386403,0.03509409,-0.03499985,-0.09185595,-0.0036730948,-0.03445356,-0.053064167,7.286481e-33,-0.023776557,0.065199256,0.029153524,-0.019542092,-0.033680364,0.04047401,0.026073046,0.07160516,-0.0605181,-0.018026156,-0.07882502,0.09200167,-0.028901968,0.050911732,0.07836532,0.07893845,0.06206762,0.0638576,-0.005010709,-0.01906934,0.07500853,-0.0055499976,-0.02166101,-0.03139301,0.04182693,-0.020818885,0.010954957,-0.09788385,0.008022182,-0.0006392268,-0.011517488,-0.016671108,0.0007103269,0.11993714,0.047761347,0.04603592,-0.034652386,0.065880746,-0.020382183,-0.023785954,-0.018862573,0.08345605,-0.024359554,-0.043060053,-0.036779806,-0.015457436,-0.025612785,-0.023223989,0.051671114,0.03485986,0.07999302,0.079734266,0.06601179,0.057706535,0.06764428,0.013637296,0.04193446,0.048317146,-0.0019557467,0.106698096,0.00059689215,-0.05856683,0.10029938,0.06358869,0.049112424,0.09914984,0.040303137,-0.01170407,0.061378982,0.061395414,0.029827997,0.11761413,0.114597805,-0.07279317,-0.018996015,-0.099004425,0.0075839832,-0.009213184,-0.005816692,0.0664553,-0.03432171,-0.051268958,-0.050512616,0.08223947,-0.029189631,-0.11882415,0.018588727,0.004718547,-0.011999662,-0.020704074,-0.055349182,0.0138881,-0.002283727,-0.026166337,0.041592795,-5.9660493e-33,0.0027732584,-0.14697075,-0.06825139,0.09735653,0.0065213093,-0.09043365,0.04009372,0.06936787,-0.07249697,0.0006946538,0.031373385,-0.038478598,0.039345026,0.032523498,-0.015288751,0.097338445,-0.026951363,-0.11651126,-0.06912807,0.054203283,-0.0457737,0.031093795,-0.068957016,0.04955592,0.066066824,-0.026540432,-0.0151753845,-0.078136206,-0.12257644,-0.10041546,-0.02395376,-0.018302174,-0.033820856,-0.027126048,-0.057456676,0.046757374,0.017088553,0.027001016,-0.013053394,0.037317205,0.051330816,0.0476096,-0.025529481,-0.033728473,0.03427679,0.015912566,-0.116734125,0.066386916,0.022126082,-0.028874371,0.03734107,0.034051903,-0.01461365,-0.018734004,0.09378762,-0.035759594,-0.054096375,0.068804495,-0.06979585,0.07331263,0.014664017,-0.01438006,-0.0043133995,0.05269717,0.037416894,-0.06750742,0.007864568,-0.011815919,-0.08256545,-0.0041485787,0.049767163,0.008094295,0.0010543495,0.09568427,-0.0085436115,-0.010811496,0.031589907,-0.00071638724,0.001965036,0.049332086,-0.074007414,0.03240105,0.029581705,0.08608283,0.045498595,0.04269553,0.023930758,0.0054241563,-0.0037122807,0.030044027,0.021415247,-0.049466863,-0.12886862,0.036351353,0.0022177107,-3.8379113e-08,0.0008602611,0.024018237,-0.0655583,0.026329665,0.038519755,0.041001044,0.03338665,0.088383175,-0.057021968,0.033934575,0.053829495,-0.022812461,-0.052525748,0.0056563746,0.017115006,0.009386039,0.010102626,-0.034756195,-0.02478354,-0.054226797,-0.029829398,0.08003891,-0.05149248,-0.030754091,0.06439553,-0.05317883,0.065622434,0.028727874,0.054334477,-0.033097863,0.026289336,-0.022087798,0.0025625606,-0.03196879,0.04735988,-0.061339214,-0.025914097,0.078263395,-0.079759896,0.021985415,0.027882526,0.014786013,0.012425547,-0.023377901,-0.011807707,-0.004371339,-0.07857975,-0.015013009,0.07890694,0.027458696,-0.023971956,-0.07001574,-0.040358987,0.04140173,0.03432889,-0.0055097924,0.00040052785,-0.01863178,0.04616672,-0.012028091,0.072636224,-0.06798893,-0.058588896,0.035552092]	2026-01-14 17:59:45.050008+00
84cb55c2-c7de-4761-a041-7186719fd6fc	74127424-1760-47e1-9899-e85a540de669	Content	# Updated Architecture\n\n## Database\nThe platform uses PostgreSQL 14 as the primary database.\nElasticsearch provides semantic search capabilities.\nThe embedding dimension is 768.\n\n## Performance\nAll API responses must complete within 200ms.	1	0	1	9	[0.08391698,-0.010777362,-0.0021018821,0.026613971,-0.018926496,0.027070327,-0.12805837,0.028142313,0.025391664,0.006704039,-0.07012442,0.013466578,0.012801172,0.013087034,-0.031557653,0.04024981,0.020025624,-0.03135806,-0.025475305,-0.0037206823,0.02822967,-0.015103459,0.011867645,-0.05228068,-0.051973157,-0.0086677745,-0.058366466,0.0064449087,0.00060559873,-0.0225405,0.03383642,-0.012856819,0.07062503,0.14031962,-0.065732285,0.014808858,0.03490629,-0.112876154,-0.055738714,-0.047752846,0.007007055,-0.007599291,-0.068089485,0.02108612,0.02707085,-0.031158727,-0.014314096,-0.006283797,-0.019144151,0.020738823,-0.027418826,-0.033104714,-0.0030521224,0.010821681,0.028463602,0.0038309277,-0.10013149,-0.0025150597,-0.052692823,-0.029618831,0.08809206,-0.071755596,0.004505614,-0.01009053,-0.05148112,-0.009224379,0.0391045,-0.068948686,0.07453467,-0.08550462,-0.0018298503,-0.0103785135,-0.070499726,0.045667816,0.012784155,0.027540017,0.055863507,0.043026302,0.09252684,0.0012938506,-0.011045052,-0.026186489,-0.09018714,0.04669084,-0.016508382,-0.074765064,0.01703075,-0.054346636,-0.020447372,0.026564885,0.07141719,-0.05734268,0.03525992,0.008184222,0.015250178,0.007657095,-0.031304087,-0.016744444,0.02605042,-0.008321306,0.014817261,0.07391082,0.06457795,0.05732878,-0.098037414,0.0027134563,-0.02643965,0.05052689,0.001206436,-0.026441678,0.05577893,-0.004864508,0.020389432,0.0021883058,0.040893015,0.04516551,-0.063904285,-0.074548736,0.09668407,0.030130139,0.05501262,0.028810654,0.0060138977,-0.08838949,-0.044025242,0.060088616,-0.049126256,7.263086e-33,0.06708352,0.06393219,0.03560729,-0.0339295,-0.015513892,0.028468184,0.047627028,0.09371136,-0.08487986,-0.010037183,-0.09746391,0.0957109,0.026847387,0.044943273,0.079382755,0.062507525,0.024643218,0.06937001,0.03341635,0.012451459,0.08676683,0.043505955,-0.037459124,0.03011408,0.022683136,-0.013854872,0.0067386786,-0.074886635,0.020899734,0.0043103932,-0.07947995,-0.0385435,-0.045776032,0.06014151,0.06028243,0.0059779435,-0.04416864,0.0320659,-0.018723844,-0.037498344,0.022691993,0.03366382,0.015338148,-0.05056695,-0.027814945,0.02350898,-0.028338032,-0.020927474,0.019852748,0.009086091,0.058565818,0.053575672,0.021614669,0.039027117,0.116462,0.056311496,0.03967383,0.04911579,0.040992834,0.06149817,-0.03180947,-0.09266316,0.08764048,0.06653402,0.06085895,0.036531985,0.0058217375,-0.0054982016,0.059361942,0.07901957,0.0355332,0.03932371,0.07256352,-0.031210586,-0.020504696,-0.10232256,-0.021448204,-0.064020306,-0.017272925,0.08556225,-0.06733217,-0.032895852,-0.02561691,0.052363116,-0.065375365,-0.07279207,-0.0036195575,-0.028053874,6.866304e-05,-0.044410788,-0.05923244,0.054403223,-0.025443261,-0.0030639993,0.0006614247,-5.5557896e-33,0.0010525085,-0.113098815,-0.028915942,0.068826795,-0.061751448,-0.0650592,0.05596378,0.08754164,-0.10258528,-0.024856592,0.041573443,-0.104514346,0.0883586,-0.05587289,-0.042951647,0.08063484,-0.05373352,-0.10469331,-0.017344745,0.015513001,-0.050115116,0.046695743,-0.047065195,0.067736015,0.064629234,-0.0583146,-0.04287299,-0.10402609,-0.08022679,-0.0334152,0.00598251,-0.06879356,0.033408176,0.023688914,-0.09412966,-0.019997748,0.06388545,-0.04368741,-0.005054573,-0.00901325,-0.005200728,0.06548291,-0.007030158,-0.008724281,0.0147526115,0.055430766,-0.087216,0.023469888,0.041035943,-0.08160887,-0.0052102106,0.012784422,0.028276274,-0.03696274,0.06996305,-0.030196454,-0.07947357,0.08999141,-0.024697732,0.034749784,0.051750083,0.0042285314,0.014488565,0.042418007,0.03630707,-0.022679962,-0.07663593,0.009023922,-0.18236582,-0.01872227,-0.025211824,-0.009346815,0.013935036,0.0792932,-0.009691522,0.0013173926,0.029708503,-0.016791362,0.016529508,-0.011081171,-0.057986893,0.045810994,0.052964997,0.06220601,0.0032290963,0.052637823,0.05964526,0.026985995,-0.072580844,0.06808726,-0.030970309,-0.050938938,-0.1412387,0.02954314,0.014477009,-3.4994528e-08,-0.038319394,0.025355179,-0.03853055,-0.0070691705,0.045304257,0.043316256,0.052673228,0.14423573,-0.008070836,0.039958883,0.04899388,-0.03515157,-0.09416005,0.08792909,0.014845303,-0.052122343,0.05369296,-0.02707181,-0.02298762,-0.006415391,-0.03647077,0.0739587,-0.02202476,-0.07502351,0.08345948,-0.03986165,0.0008768394,0.08624562,-0.0006846244,-0.060105097,-0.010879809,-0.029398328,0.004390525,-0.082000345,0.009343876,0.05449217,-0.0063418876,0.030118413,-0.103235014,-0.006504755,0.053698506,-0.010585661,0.010674281,-0.0348324,0.038184777,-0.036649235,-0.028975327,0.016925892,0.031793058,0.046505213,0.033390615,-0.04359697,-0.003952348,0.020616189,0.043012485,0.031155381,-0.062941335,-0.03575164,0.045484442,-0.010343316,0.100837566,-0.04946469,0.02160523,-0.005954635]	2026-01-14 18:01:21.188342+00
dec67824-6f3a-46fe-8c35-c9f31a81f7aa	2fa32237-731b-4393-9a06-b914b012db84	Content	# Architecture Decision\n\n## Context\nThe platform uses PostgreSQL 15 as the primary database.\nRedis provides caching with a 1-hour TTL.\nAll API responses must complete within 500ms.\n\n## Decision\nWe will use pgvector for semantic search instead of Elasticsearch.\nThe embedding dimension is 384.	1	0	1	10	[0.019177882,-0.018898759,-0.04426501,0.033431903,-0.019915188,-0.05163123,-0.0796716,0.018727584,0.044522785,0.021913847,-0.083917506,0.04763559,-0.01660692,-0.03994266,-0.0015625198,-0.012262027,0.04773461,0.00799227,-0.05572599,-0.09389394,0.03156081,-0.020484721,-0.012421968,-0.06515133,-0.07347579,-0.04839906,-0.03253597,-0.019132616,-0.013932071,-0.040666018,0.008338815,-0.015178445,0.068746336,0.08208873,-0.07696376,0.10315318,0.00095837587,-0.14066522,-0.05912433,-0.008712068,0.030668283,-0.0039098766,-0.06551486,0.045439504,0.03409974,-0.057165746,-0.038693033,0.053132694,0.017657854,-0.015605455,-0.021396061,-0.009125348,-0.027349297,0.016800351,-0.0412514,0.068833545,-0.06790402,-0.053339764,-0.037571084,-0.06371681,0.055114742,-0.09197821,-0.026811017,-0.030393096,-0.0675832,0.0042271977,0.05832411,-0.09083766,0.09243547,-0.030935442,-0.001974594,0.0029972543,-0.06246038,-0.022545941,-0.025775153,0.017578702,0.08875414,0.04349829,0.04091676,-0.036860384,-0.018601447,-0.0057502845,-0.008365264,0.043200668,0.009814699,-0.039770875,0.020196252,-0.058878303,-0.003908051,-0.0061999615,0.0574618,-0.000739722,0.062884666,-0.03674477,-0.016301118,0.009239243,-0.016060824,-0.002385244,0.017394736,-0.0024885177,-0.030840192,0.045471117,0.048310984,0.0706624,-0.1212178,-0.036729246,-0.08422325,0.032396495,-0.0086961,-0.038275305,0.049727116,0.022724468,0.048063606,-0.027111605,-7.341316e-05,0.08510487,-0.07493397,-0.08693954,0.06523588,0.009916491,0.09386403,0.03509409,-0.03499985,-0.09185595,-0.0036730948,-0.03445356,-0.053064167,7.286481e-33,-0.023776557,0.065199256,0.029153524,-0.019542092,-0.033680364,0.04047401,0.026073046,0.07160516,-0.0605181,-0.018026156,-0.07882502,0.09200167,-0.028901968,0.050911732,0.07836532,0.07893845,0.06206762,0.0638576,-0.005010709,-0.01906934,0.07500853,-0.0055499976,-0.02166101,-0.03139301,0.04182693,-0.020818885,0.010954957,-0.09788385,0.008022182,-0.0006392268,-0.011517488,-0.016671108,0.0007103269,0.11993714,0.047761347,0.04603592,-0.034652386,0.065880746,-0.020382183,-0.023785954,-0.018862573,0.08345605,-0.024359554,-0.043060053,-0.036779806,-0.015457436,-0.025612785,-0.023223989,0.051671114,0.03485986,0.07999302,0.079734266,0.06601179,0.057706535,0.06764428,0.013637296,0.04193446,0.048317146,-0.0019557467,0.106698096,0.00059689215,-0.05856683,0.10029938,0.06358869,0.049112424,0.09914984,0.040303137,-0.01170407,0.061378982,0.061395414,0.029827997,0.11761413,0.114597805,-0.07279317,-0.018996015,-0.099004425,0.0075839832,-0.009213184,-0.005816692,0.0664553,-0.03432171,-0.051268958,-0.050512616,0.08223947,-0.029189631,-0.11882415,0.018588727,0.004718547,-0.011999662,-0.020704074,-0.055349182,0.0138881,-0.002283727,-0.026166337,0.041592795,-5.9660493e-33,0.0027732584,-0.14697075,-0.06825139,0.09735653,0.0065213093,-0.09043365,0.04009372,0.06936787,-0.07249697,0.0006946538,0.031373385,-0.038478598,0.039345026,0.032523498,-0.015288751,0.097338445,-0.026951363,-0.11651126,-0.06912807,0.054203283,-0.0457737,0.031093795,-0.068957016,0.04955592,0.066066824,-0.026540432,-0.0151753845,-0.078136206,-0.12257644,-0.10041546,-0.02395376,-0.018302174,-0.033820856,-0.027126048,-0.057456676,0.046757374,0.017088553,0.027001016,-0.013053394,0.037317205,0.051330816,0.0476096,-0.025529481,-0.033728473,0.03427679,0.015912566,-0.116734125,0.066386916,0.022126082,-0.028874371,0.03734107,0.034051903,-0.01461365,-0.018734004,0.09378762,-0.035759594,-0.054096375,0.068804495,-0.06979585,0.07331263,0.014664017,-0.01438006,-0.0043133995,0.05269717,0.037416894,-0.06750742,0.007864568,-0.011815919,-0.08256545,-0.0041485787,0.049767163,0.008094295,0.0010543495,0.09568427,-0.0085436115,-0.010811496,0.031589907,-0.00071638724,0.001965036,0.049332086,-0.074007414,0.03240105,0.029581705,0.08608283,0.045498595,0.04269553,0.023930758,0.0054241563,-0.0037122807,0.030044027,0.021415247,-0.049466863,-0.12886862,0.036351353,0.0022177107,-3.8379113e-08,0.0008602611,0.024018237,-0.0655583,0.026329665,0.038519755,0.041001044,0.03338665,0.088383175,-0.057021968,0.033934575,0.053829495,-0.022812461,-0.052525748,0.0056563746,0.017115006,0.009386039,0.010102626,-0.034756195,-0.02478354,-0.054226797,-0.029829398,0.08003891,-0.05149248,-0.030754091,0.06439553,-0.05317883,0.065622434,0.028727874,0.054334477,-0.033097863,0.026289336,-0.022087798,0.0025625606,-0.03196879,0.04735988,-0.061339214,-0.025914097,0.078263395,-0.079759896,0.021985415,0.027882526,0.014786013,0.012425547,-0.023377901,-0.011807707,-0.004371339,-0.07857975,-0.015013009,0.07890694,0.027458696,-0.023971956,-0.07001574,-0.040358987,0.04140173,0.03432889,-0.0055097924,0.00040052785,-0.01863178,0.04616672,-0.012028091,0.072636224,-0.06798893,-0.058588896,0.035552092]	2026-01-14 18:09:16.41143+00
af6e7b9d-aca1-42be-ba86-151e94556ec0	71704e2b-6e44-4b92-b94f-62657082a2ef	Content	# Updated Architecture\n\n## Database\nThe platform uses PostgreSQL 14 as the primary database.\nElasticsearch provides semantic search capabilities.\nThe embedding dimension is 768.\n\n## Performance\nAll API responses must complete within 200ms.	1	0	1	9	[0.08391698,-0.010777362,-0.0021018821,0.026613971,-0.018926496,0.027070327,-0.12805837,0.028142313,0.025391664,0.006704039,-0.07012442,0.013466578,0.012801172,0.013087034,-0.031557653,0.04024981,0.020025624,-0.03135806,-0.025475305,-0.0037206823,0.02822967,-0.015103459,0.011867645,-0.05228068,-0.051973157,-0.0086677745,-0.058366466,0.0064449087,0.00060559873,-0.0225405,0.03383642,-0.012856819,0.07062503,0.14031962,-0.065732285,0.014808858,0.03490629,-0.112876154,-0.055738714,-0.047752846,0.007007055,-0.007599291,-0.068089485,0.02108612,0.02707085,-0.031158727,-0.014314096,-0.006283797,-0.019144151,0.020738823,-0.027418826,-0.033104714,-0.0030521224,0.010821681,0.028463602,0.0038309277,-0.10013149,-0.0025150597,-0.052692823,-0.029618831,0.08809206,-0.071755596,0.004505614,-0.01009053,-0.05148112,-0.009224379,0.0391045,-0.068948686,0.07453467,-0.08550462,-0.0018298503,-0.0103785135,-0.070499726,0.045667816,0.012784155,0.027540017,0.055863507,0.043026302,0.09252684,0.0012938506,-0.011045052,-0.026186489,-0.09018714,0.04669084,-0.016508382,-0.074765064,0.01703075,-0.054346636,-0.020447372,0.026564885,0.07141719,-0.05734268,0.03525992,0.008184222,0.015250178,0.007657095,-0.031304087,-0.016744444,0.02605042,-0.008321306,0.014817261,0.07391082,0.06457795,0.05732878,-0.098037414,0.0027134563,-0.02643965,0.05052689,0.001206436,-0.026441678,0.05577893,-0.004864508,0.020389432,0.0021883058,0.040893015,0.04516551,-0.063904285,-0.074548736,0.09668407,0.030130139,0.05501262,0.028810654,0.0060138977,-0.08838949,-0.044025242,0.060088616,-0.049126256,7.263086e-33,0.06708352,0.06393219,0.03560729,-0.0339295,-0.015513892,0.028468184,0.047627028,0.09371136,-0.08487986,-0.010037183,-0.09746391,0.0957109,0.026847387,0.044943273,0.079382755,0.062507525,0.024643218,0.06937001,0.03341635,0.012451459,0.08676683,0.043505955,-0.037459124,0.03011408,0.022683136,-0.013854872,0.0067386786,-0.074886635,0.020899734,0.0043103932,-0.07947995,-0.0385435,-0.045776032,0.06014151,0.06028243,0.0059779435,-0.04416864,0.0320659,-0.018723844,-0.037498344,0.022691993,0.03366382,0.015338148,-0.05056695,-0.027814945,0.02350898,-0.028338032,-0.020927474,0.019852748,0.009086091,0.058565818,0.053575672,0.021614669,0.039027117,0.116462,0.056311496,0.03967383,0.04911579,0.040992834,0.06149817,-0.03180947,-0.09266316,0.08764048,0.06653402,0.06085895,0.036531985,0.0058217375,-0.0054982016,0.059361942,0.07901957,0.0355332,0.03932371,0.07256352,-0.031210586,-0.020504696,-0.10232256,-0.021448204,-0.064020306,-0.017272925,0.08556225,-0.06733217,-0.032895852,-0.02561691,0.052363116,-0.065375365,-0.07279207,-0.0036195575,-0.028053874,6.866304e-05,-0.044410788,-0.05923244,0.054403223,-0.025443261,-0.0030639993,0.0006614247,-5.5557896e-33,0.0010525085,-0.113098815,-0.028915942,0.068826795,-0.061751448,-0.0650592,0.05596378,0.08754164,-0.10258528,-0.024856592,0.041573443,-0.104514346,0.0883586,-0.05587289,-0.042951647,0.08063484,-0.05373352,-0.10469331,-0.017344745,0.015513001,-0.050115116,0.046695743,-0.047065195,0.067736015,0.064629234,-0.0583146,-0.04287299,-0.10402609,-0.08022679,-0.0334152,0.00598251,-0.06879356,0.033408176,0.023688914,-0.09412966,-0.019997748,0.06388545,-0.04368741,-0.005054573,-0.00901325,-0.005200728,0.06548291,-0.007030158,-0.008724281,0.0147526115,0.055430766,-0.087216,0.023469888,0.041035943,-0.08160887,-0.0052102106,0.012784422,0.028276274,-0.03696274,0.06996305,-0.030196454,-0.07947357,0.08999141,-0.024697732,0.034749784,0.051750083,0.0042285314,0.014488565,0.042418007,0.03630707,-0.022679962,-0.07663593,0.009023922,-0.18236582,-0.01872227,-0.025211824,-0.009346815,0.013935036,0.0792932,-0.009691522,0.0013173926,0.029708503,-0.016791362,0.016529508,-0.011081171,-0.057986893,0.045810994,0.052964997,0.06220601,0.0032290963,0.052637823,0.05964526,0.026985995,-0.072580844,0.06808726,-0.030970309,-0.050938938,-0.1412387,0.02954314,0.014477009,-3.4994528e-08,-0.038319394,0.025355179,-0.03853055,-0.0070691705,0.045304257,0.043316256,0.052673228,0.14423573,-0.008070836,0.039958883,0.04899388,-0.03515157,-0.09416005,0.08792909,0.014845303,-0.052122343,0.05369296,-0.02707181,-0.02298762,-0.006415391,-0.03647077,0.0739587,-0.02202476,-0.07502351,0.08345948,-0.03986165,0.0008768394,0.08624562,-0.0006846244,-0.060105097,-0.010879809,-0.029398328,0.004390525,-0.082000345,0.009343876,0.05449217,-0.0063418876,0.030118413,-0.103235014,-0.006504755,0.053698506,-0.010585661,0.010674281,-0.0348324,0.038184777,-0.036649235,-0.028975327,0.016925892,0.031793058,0.046505213,0.033390615,-0.04359697,-0.003952348,0.020616189,0.043012485,0.031155381,-0.062941335,-0.03575164,0.045484442,-0.010343316,0.100837566,-0.04946469,0.02160523,-0.005954635]	2026-01-14 18:11:24.647749+00
ae130918-ff8c-4066-8039-796cdbab1eeb	555b21c5-e167-4634-8ced-cfe541301183	Content	Test document with a few claims. PostgreSQL is the database. Redis is the cache.	1	0	1	1	[-0.047744904,-0.017868739,-0.13644251,0.057053193,-0.013372681,-0.07779018,-0.012832037,0.005063173,0.038735654,0.047461256,0.00038560876,0.092508234,-0.005549435,-0.07399491,-0.027336132,-0.016045053,0.08041792,-0.04511591,0.04783745,-0.07570851,-0.015330722,-0.029173097,-0.01737607,0.029534735,0.02295783,-0.041200824,-0.057359483,0.041403133,-0.04702351,-0.09929678,0.0015910515,0.01668765,0.032034215,0.03495935,0.032584105,0.08664325,0.04412073,-0.10671087,-0.0389511,0.0015319336,0.016313937,-0.04041701,-0.034053057,0.100386016,0.048741892,0.012338302,-0.04006438,0.06731675,-0.029933553,0.016188452,-0.021562565,0.012525402,-0.03506217,0.032352682,-0.01769071,0.072103545,0.025456162,0.0014225736,-0.0626317,0.016399253,0.024095109,-0.024904393,-0.055198807,0.071972325,-0.06621365,0.07186916,0.019794911,-0.07504405,0.10159421,-0.14704174,-0.032191157,0.017872926,-0.04991942,-0.01640474,0.008442472,0.020715797,0.060713124,-0.048032057,0.034113996,-0.110960804,-0.03592302,0.018717673,0.0022684957,0.017383773,0.00325023,0.033857524,0.09776776,-0.0029265627,-0.0060652336,-0.0014875121,0.07640924,0.015938561,-0.0034763173,0.011931357,-0.1009594,0.015644934,0.04035284,0.015279581,0.08438605,0.0151563855,0.04272327,0.05448901,0.07540883,0.011836891,-0.09919093,-0.009412521,-0.009253322,-0.051931586,-0.012203727,-0.064500555,0.010385492,-0.017051216,-0.041673735,-0.030197771,-0.017623043,-0.003242932,-0.09262074,-0.02278996,-0.06359837,-0.052069325,0.08008614,0.05880183,-0.026576944,-0.10673705,-0.03923464,-0.036248323,-0.011524623,-1.3039435e-33,0.009155358,0.0009977351,0.0389071,0.04795372,0.0006967087,0.012019621,-0.022745,0.08794395,-0.08399524,0.04994791,0.01661888,0.062971435,-0.051221836,0.03511211,0.052355796,0.118867986,-0.022393547,0.06929742,0.051894672,0.012549696,0.04568692,0.026948271,-0.015860185,-0.030534243,0.07683793,0.05354186,0.01101068,-0.00063659565,-0.019699514,-0.014827215,0.038316313,-0.026981436,-0.022935864,0.08276837,0.027071198,0.08180557,-0.0065732943,-0.03155398,-0.057502605,0.029024087,-0.018537909,0.049050085,0.021007668,0.020780833,-0.004940104,-0.06895797,-0.065221466,-0.02308783,0.103693426,0.06465518,-0.009893066,0.026607336,0.09409402,0.0663983,0.0041158367,0.03212407,0.035806965,-0.010059638,0.04875202,0.0950865,0.02014001,-0.003023886,-0.04315739,0.0067319865,-0.002580272,0.0824846,-0.021954592,-0.069364056,0.11735783,0.02743739,-0.0029735707,0.025272133,0.0839296,-0.05012474,-0.02147574,-0.073003784,-0.11583732,0.034525912,-0.0827311,0.012056064,0.02071923,-0.06613918,-0.08304509,0.0975253,-0.10402507,0.013527288,-0.024833372,0.008606979,-0.007309412,-0.016904077,-0.01855424,0.060276207,0.020517867,-0.016155297,0.09866746,-7.857494e-35,-0.033945594,-0.10200489,-0.06110145,0.1024321,0.022935059,-0.03697849,0.041434158,0.032994583,-0.0741054,0.010965054,0.04198466,-0.054856185,-0.02725756,0.011500799,0.0010381226,0.023053262,-0.011442189,-0.103328876,-0.07674775,0.059771616,-0.06181998,0.09927605,0.049169976,-0.0072913,0.038082004,-0.008447053,-0.059589323,-0.103709504,-0.08726063,-0.023990778,0.036412857,0.03881082,-0.12973578,-0.027454838,-0.010930512,-0.039853215,0.031518243,0.015012654,-0.010782388,0.01640051,0.061426252,0.06313318,0.03604849,-0.009648195,-0.0034928897,0.06583556,-0.055544063,0.0023363435,0.03595036,-0.03526117,0.05397152,-0.015903581,-0.0041846405,-0.033920627,0.062238783,0.029819313,-0.11961058,0.0025945723,-0.032691263,0.06832684,0.01893363,0.03818451,-0.058400765,0.09445692,-0.03672113,-0.03534092,0.0021972845,0.009327908,0.007544466,-0.022957252,0.036493387,0.017876454,0.014266948,0.004749351,0.0152815385,-0.027545776,-0.04489747,-0.04114515,-0.04565032,0.055582467,0.060905218,-0.03481812,-0.0010273454,0.046815183,0.02885196,-0.038492445,-0.059048865,-0.0801708,-0.04070945,0.021694187,-0.003909449,0.0014026529,-0.12211973,0.011897832,-0.03394635,-2.1782322e-08,-0.009486884,0.0094933035,0.02629645,-0.025504282,0.001221965,0.0027714027,0.07194216,0.07781571,-0.05461863,-0.0026252824,0.052619625,-0.05117646,-0.047696155,-0.031377066,-0.0035501323,-0.03070109,0.033117276,0.0040909164,-0.025840513,-0.0098683555,-0.0605865,0.048816074,-0.02366572,-0.044371568,0.02419053,0.013310319,0.10159103,0.051336225,0.050954442,-0.05290069,0.086467914,-0.0002283142,0.033094518,-0.045807917,0.112346426,0.011457069,0.025070503,0.11225393,-0.015442882,-0.03200601,-0.08220036,0.0221965,0.040634785,0.020641478,-0.019107433,-0.046109904,-0.11328746,-0.039693482,0.045975473,-0.046697818,-0.04703321,-0.09492504,0.004830601,0.048963994,-0.039336715,-0.02726472,0.07037312,-0.00834697,0.000594163,-0.0068763644,0.082638085,-0.03635063,0.03813341,0.04636609]	2026-01-14 18:23:23.694906+00
38bba5ac-9373-430a-945e-2e4c4eb80273	bb5b5b7d-3921-4036-98b2-a00d334568f5	Content	# System Architecture\n\nThe platform uses PostgreSQL 15 as the primary database for structured data.\nRedis provides caching with a 1-hour TTL for session data.\nAll API responses must complete within 500ms for optimal user experience.\n\n## Database Layer\n- PostgreSQL handles ACID transactions\n- Connection pooling via PgBouncer\n- Automatic failover with streaming replication\n\n## Caching Strategy\n- Redis cluster for high availability\n- Write-through cache for user sessions\n- Cache invalidation on data updates	1	0	1	15	[-0.029709885,-0.022140086,-0.06901228,0.004006857,-0.091975346,-0.0726436,-0.0031662018,0.009898265,0.049154736,0.024079205,-0.060176235,0.08283822,-0.043345228,-0.07747726,0.04011345,-0.023982344,0.12055628,-0.0059777433,-0.060655847,-0.14431024,-0.016421992,-0.05945614,-0.03118614,0.037347414,-0.054058645,-0.021065798,-0.02784849,-0.05062777,-0.029013338,-0.06711582,-0.033613816,-0.0024249633,0.036096837,0.05047067,-0.06990464,0.099598475,0.045637395,-0.10564246,-0.03965831,-0.05111285,0.017008346,-0.020484291,-0.075607516,0.0791229,0.015142715,-0.024048379,-0.06028357,0.071528785,-0.029929537,-0.0015702719,-0.006898111,0.036964618,0.022965275,0.068267055,-0.040421262,0.090096384,-0.028545655,-0.012509782,-0.027353115,0.025445608,0.015219433,-0.061468113,-0.051086843,0.008768078,-0.07090935,0.01358369,0.07937049,-0.07976684,0.10377377,-0.02670543,-0.049890384,0.009794592,-0.060139753,-0.04123701,-0.07400718,-0.035470746,0.06328419,-0.010199234,-0.008356835,-0.049452763,-0.024639482,0.060980376,0.02248143,0.04121403,-0.021226987,-0.047347665,0.0026820865,0.034608256,-0.05170117,-0.014230396,0.01880778,0.09165821,0.05807186,-0.043161787,-0.0789451,0.02446752,0.02026691,-0.025260812,0.052342292,0.003991799,0.014646279,0.06951893,0.038882397,0.07007517,-0.10527064,-0.050774656,-0.08520499,0.0011027611,-0.056213535,-0.009490127,0.012536789,0.011481524,0.02415535,-0.037265018,0.0020948811,0.052985985,-0.099147886,-0.063675426,0.017608289,-0.028171072,0.09313375,0.0015853298,-0.020823017,-0.08591866,0.025828404,-0.09699899,-0.0075998497,6.449111e-33,-0.031085255,0.037628744,0.03697521,-0.015392791,-0.029257081,0.005514507,-0.0033140026,0.01813232,-0.037988525,-0.0101532005,-0.016454611,0.02596585,-0.049080532,0.038941137,0.05856745,0.07048293,0.038401343,0.047395002,0.055563748,-0.026016776,0.039542563,0.011971161,0.0058269077,0.0012348327,0.07376715,0.034466032,-0.0012042786,-0.05520059,-0.005314208,-0.003511253,0.036913864,-0.006013955,-0.009288369,0.09603232,0.04247556,0.05505415,0.006372238,-0.0015922885,0.025715495,-0.0122916475,-0.01476923,0.11344101,-0.04274721,-0.00042358274,-0.033905335,-0.01565459,-0.028072089,0.0012266374,0.024319991,0.039514404,0.034653,0.05776982,0.04552545,0.06590249,0.014430334,0.026128799,0.029362272,-0.02003114,-0.010757053,0.15104586,0.02881174,-0.08036848,-0.009111042,0.02858275,0.012594559,0.0996773,0.023789825,-0.03262942,0.06811802,0.033847127,-0.03743813,0.110799655,0.09326252,-0.040465675,-0.03598467,-0.048529983,-0.00045584494,0.0013545583,-0.017294483,0.08137374,-0.014664958,-0.05696596,-0.09936289,0.105219714,-0.05451758,-0.06330941,0.04745982,0.033688545,-0.022227217,0.004462609,-0.07144386,-0.042985577,0.08827917,-0.024808196,0.04820897,-6.581042e-33,0.018905316,-0.1229301,-0.06056986,0.11075194,0.035679746,-0.049382858,0.019885799,0.02729683,-0.03996251,-0.013683151,-0.02021084,-0.0013178568,0.05612499,0.044900637,-0.017827088,0.044204652,0.021284688,-0.10287919,-0.08375215,0.04559909,-0.019769643,0.035913933,-0.008207807,-0.0019072645,0.072246045,-0.023997707,-0.087768584,-0.08472169,-0.06725826,-0.05937439,0.009079168,-0.0239773,0.0037648766,-0.06580814,-0.006018802,0.016446108,0.007537501,0.038177542,-0.024484834,0.011054053,0.0722138,0.009963018,-0.020349408,-0.050175067,0.030367931,0.061963823,-0.16479912,0.03917188,-0.08653881,0.019148033,0.043746244,0.003214036,-0.04532108,-0.045298494,0.103136174,-0.041375715,-0.049773213,0.038911358,-0.048493084,0.033572435,0.0012588712,-0.060545478,-0.011064848,0.0798316,0.021345159,-0.06268808,0.04535671,-0.036367565,0.007969462,0.014665379,0.066978626,0.007571448,0.019365367,0.08136201,-0.0076322816,-0.03454324,-0.053570777,-0.06885843,-0.017837482,0.07847079,-0.0854101,0.034719698,0.005669293,0.082959644,0.068407394,-0.00959183,0.0052880556,-0.036119938,0.023827132,-0.004801325,-0.006068628,-0.01955819,-0.13613886,0.06216042,-0.034175016,-3.8598937e-08,0.02400218,-0.028530437,-0.038180895,0.031140393,0.049294617,0.015912302,0.030944403,0.05563766,-0.006334646,0.039836932,0.076556906,-0.006259024,-0.0009024998,-0.062008906,0.016490594,0.06381448,0.04834029,-0.04420753,-0.020449135,-0.052044753,-0.03740487,0.054685373,-0.06993883,-0.053906493,0.04446198,-0.01799881,0.09772887,0.04341241,0.034381516,-0.031742867,0.057962917,-0.0448939,0.06598267,-0.02894394,0.11355293,-0.06658309,-0.02429118,0.10644805,-0.0091726845,-0.0025167004,-0.024370996,0.0066455505,0.01577891,0.019473525,-0.014592046,0.005460173,-0.13073687,0.011605746,0.050168075,0.030907769,-0.03181728,-0.035997514,-0.019631054,0.02699332,0.013105749,0.014396894,0.053627998,0.010634822,0.084602185,-0.06254652,0.06002443,-0.0061902734,-0.050255377,-0.0044375686]	2026-01-14 18:24:25.73316+00
8b5c725b-3d16-4168-94b0-a5d1504af759	d1aec79c-878f-4ab4-98aa-f53ce6d80178	Content	This is a test document about the L02 Agent Runtime Layer. It provides core services for agent execution.	1	0	1	1	\N	2026-01-15 04:13:01.307109+00
\.


--
-- Data for Name: service_registry_events; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.service_registry_events (id, event_id, "timestamp", service_id, event_type, layer, host, port, health_status, capabilities, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.sessions (id, agent_id, session_type, status, context, checkpoint, runtime_backend, runtime_metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: supersessions; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.supersessions (id, old_document_id, new_document_id, reason, created_at) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.tasks (id, task_id, plan_id, agent_id, name, description, task_type, status, dependencies, inputs, outputs, assigned_agent, timeout_seconds, retry_policy, retry_count, tool_name, llm_prompt, metadata, error, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: tool_definitions; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.tool_definitions (tool_id, tool_name, description, category, tags, latest_version, source_type, source_metadata, deprecation_state, deprecation_date, created_at, updated_at, requires_approval, default_timeout_seconds, default_cpu_millicore_limit, default_memory_mb_limit, required_permissions, result_schema, retry_policy, circuit_breaker_config, description_embedding) FROM stdin;
\.


--
-- Data for Name: tool_executions; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.tool_executions (id, invocation_id, tool_id, tool_name, tool_version, agent_id, agent_did, tenant_id, session_id, parent_sandbox_id, input_params, output_result, status, error_code, error_message, error_details, retryable, duration_ms, cpu_used_millicore_seconds, memory_peak_mb, network_bytes_sent, network_bytes_received, documents_accessed, checkpoints_created, checkpoint_ref, async_mode, priority, idempotency_key, require_approval, cpu_millicore_limit, memory_mb_limit, timeout_seconds, created_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: tool_invocations; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.tool_invocations (id, invocation_id, tool_id, tool_version, agent_did, tenant_id, session_id, parameters, result, error, status, started_at, completed_at, duration_ms, resource_usage, documents_accessed, checkpoints_created) FROM stdin;
\.


--
-- Data for Name: tool_versions; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.tool_versions (version_id, tool_id, version, manifest, compatibility_range, release_notes, deprecated_in_favor_of, created_at, removed_at) FROM stdin;
\.


--
-- Data for Name: tools; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.tools (id, name, description, tool_type, schema_def, permissions, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: training_examples; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.training_examples (id, execution_id, task_id, agent_id, source_type, source_trace_hash, input_text, input_structured, output_text, expected_actions, final_answer, quality_score, confidence, labels, domain, task_type, difficulty, metadata, extracted_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_interactions; Type: TABLE DATA; Schema: mcp_documents; Owner: postgres
--

COPY mcp_documents.user_interactions (id, interaction_id, "timestamp", user_id, interaction_type, target_type, target_id, action, parameters, result, error_message, client_ip, user_agent, session_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: snapshots; Type: TABLE DATA; Schema: shared; Owner: postgres
--

COPY shared.snapshots (id, snapshot_id, aggregate_type, aggregate_id, version, state, created_at) FROM stdin;
\.


--
-- Name: supersessions_id_seq; Type: SEQUENCE SET; Schema: mcp_documents; Owner: postgres
--

SELECT pg_catalog.setval('mcp_documents.supersessions_id_seq', 1, false);


--
-- Name: tool_invocations_id_seq; Type: SEQUENCE SET; Schema: mcp_documents; Owner: postgres
--

SELECT pg_catalog.setval('mcp_documents.tool_invocations_id_seq', 1, false);


--
-- Name: snapshots_id_seq; Type: SEQUENCE SET; Schema: shared; Owner: postgres
--

SELECT pg_catalog.setval('shared.snapshots_id_seq', 1, false);


--
-- Name: agent_state agent_state_pkey; Type: CONSTRAINT; Schema: l02_runtime; Owner: postgres
--

ALTER TABLE ONLY l02_runtime.agent_state
    ADD CONSTRAINT agent_state_pkey PRIMARY KEY (agent_id);


--
-- Name: checkpoints checkpoints_pkey; Type: CONSTRAINT; Schema: l02_runtime; Owner: postgres
--

ALTER TABLE ONLY l02_runtime.checkpoints
    ADD CONSTRAINT checkpoints_pkey PRIMARY KEY (checkpoint_id);


--
-- Name: active_sessions active_sessions_pkey; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.active_sessions
    ADD CONSTRAINT active_sessions_pkey PRIMARY KEY (id);


--
-- Name: active_sessions active_sessions_session_id_key; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.active_sessions
    ADD CONSTRAINT active_sessions_session_id_key UNIQUE (session_id);


--
-- Name: checkpoints checkpoints_checkpoint_id_key; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.checkpoints
    ADD CONSTRAINT checkpoints_checkpoint_id_key UNIQUE (checkpoint_id);


--
-- Name: checkpoints checkpoints_pkey; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.checkpoints
    ADD CONSTRAINT checkpoints_pkey PRIMARY KEY (id);


--
-- Name: context_conflicts context_conflicts_pkey; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.context_conflicts
    ADD CONSTRAINT context_conflicts_pkey PRIMARY KEY (id);


--
-- Name: context_versions context_versions_pkey; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.context_versions
    ADD CONSTRAINT context_versions_pkey PRIMARY KEY (id);


--
-- Name: global_context global_context_pkey; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.global_context
    ADD CONSTRAINT global_context_pkey PRIMARY KEY (id);


--
-- Name: global_context global_context_project_id_key; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.global_context
    ADD CONSTRAINT global_context_project_id_key UNIQUE (project_id);


--
-- Name: task_contexts task_contexts_pkey; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.task_contexts
    ADD CONSTRAINT task_contexts_pkey PRIMARY KEY (id);


--
-- Name: task_contexts task_contexts_task_id_key; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.task_contexts
    ADD CONSTRAINT task_contexts_task_id_key UNIQUE (task_id);


--
-- Name: task_relationships task_relationships_pkey; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.task_relationships
    ADD CONSTRAINT task_relationships_pkey PRIMARY KEY (id);


--
-- Name: task_relationships unique_relationship; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.task_relationships
    ADD CONSTRAINT unique_relationship UNIQUE (source_task_id, target_task_id, relationship_type);


--
-- Name: context_versions unique_task_version; Type: CONSTRAINT; Schema: mcp_contexts; Owner: postgres
--

ALTER TABLE ONLY mcp_contexts.context_versions
    ADD CONSTRAINT unique_task_version UNIQUE (task_id, version);


--
-- Name: agents agents_did_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.agents
    ADD CONSTRAINT agents_did_key UNIQUE (did);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_alert_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.alerts
    ADD CONSTRAINT alerts_alert_id_key UNIQUE (alert_id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: anomalies anomalies_anomaly_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.anomalies
    ADD CONSTRAINT anomalies_anomaly_id_key UNIQUE (anomaly_id);


--
-- Name: anomalies anomalies_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.anomalies
    ADD CONSTRAINT anomalies_pkey PRIMARY KEY (id);


--
-- Name: api_requests api_requests_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.api_requests
    ADD CONSTRAINT api_requests_pkey PRIMARY KEY (id);


--
-- Name: api_requests api_requests_request_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.api_requests
    ADD CONSTRAINT api_requests_request_id_key UNIQUE (request_id);


--
-- Name: authentication_events authentication_events_event_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.authentication_events
    ADD CONSTRAINT authentication_events_event_id_key UNIQUE (event_id);


--
-- Name: authentication_events authentication_events_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.authentication_events
    ADD CONSTRAINT authentication_events_pkey PRIMARY KEY (id);


--
-- Name: circuit_breaker_events circuit_breaker_events_event_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.circuit_breaker_events
    ADD CONSTRAINT circuit_breaker_events_event_id_key UNIQUE (event_id);


--
-- Name: circuit_breaker_events circuit_breaker_events_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.circuit_breaker_events
    ADD CONSTRAINT circuit_breaker_events_pkey PRIMARY KEY (id);


--
-- Name: claims claims_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.claims
    ADD CONSTRAINT claims_pkey PRIMARY KEY (id);


--
-- Name: compliance_results compliance_results_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.compliance_results
    ADD CONSTRAINT compliance_results_pkey PRIMARY KEY (id);


--
-- Name: compliance_results compliance_results_result_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.compliance_results
    ADD CONSTRAINT compliance_results_result_id_key UNIQUE (result_id);


--
-- Name: configurations configurations_namespace_key_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.configurations
    ADD CONSTRAINT configurations_namespace_key_key UNIQUE (namespace, key);


--
-- Name: configurations configurations_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.configurations
    ADD CONSTRAINT configurations_pkey PRIMARY KEY (id);


--
-- Name: conflicts conflicts_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.conflicts
    ADD CONSTRAINT conflicts_pkey PRIMARY KEY (id);


--
-- Name: consolidations consolidations_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.consolidations
    ADD CONSTRAINT consolidations_pkey PRIMARY KEY (id);


--
-- Name: control_operations control_operations_operation_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.control_operations
    ADD CONSTRAINT control_operations_operation_id_key UNIQUE (operation_id);


--
-- Name: control_operations control_operations_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.control_operations
    ADD CONSTRAINT control_operations_pkey PRIMARY KEY (id);


--
-- Name: dataset_examples dataset_examples_dataset_id_example_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.dataset_examples
    ADD CONSTRAINT dataset_examples_dataset_id_example_id_key UNIQUE (dataset_id, example_id);


--
-- Name: dataset_examples dataset_examples_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.dataset_examples
    ADD CONSTRAINT dataset_examples_pkey PRIMARY KEY (id);


--
-- Name: datasets datasets_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.datasets
    ADD CONSTRAINT datasets_pkey PRIMARY KEY (id);


--
-- Name: document_tags document_tags_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.document_tags
    ADD CONSTRAINT document_tags_pkey PRIMARY KEY (document_id, tag);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: entities entities_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.entities
    ADD CONSTRAINT entities_pkey PRIMARY KEY (id);


--
-- Name: evaluations evaluations_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.evaluations
    ADD CONSTRAINT evaluations_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: feedback_entries feedback_entries_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.feedback_entries
    ADD CONSTRAINT feedback_entries_pkey PRIMARY KEY (id);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: goals goals_goal_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.goals
    ADD CONSTRAINT goals_goal_id_key UNIQUE (goal_id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: metrics metrics_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.metrics
    ADD CONSTRAINT metrics_pkey PRIMARY KEY (id);


--
-- Name: model_usage model_usage_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.model_usage
    ADD CONSTRAINT model_usage_pkey PRIMARY KEY (id);


--
-- Name: model_usage model_usage_request_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.model_usage
    ADD CONSTRAINT model_usage_request_id_key UNIQUE (request_id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: plans plans_plan_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.plans
    ADD CONSTRAINT plans_plan_id_key UNIQUE (plan_id);


--
-- Name: provenance provenance_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.provenance
    ADD CONSTRAINT provenance_pkey PRIMARY KEY (id);


--
-- Name: quality_scores quality_scores_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.quality_scores
    ADD CONSTRAINT quality_scores_pkey PRIMARY KEY (id);


--
-- Name: quality_scores quality_scores_score_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.quality_scores
    ADD CONSTRAINT quality_scores_score_id_key UNIQUE (score_id);


--
-- Name: rate_limit_events rate_limit_events_event_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.rate_limit_events
    ADD CONSTRAINT rate_limit_events_event_id_key UNIQUE (event_id);


--
-- Name: rate_limit_events rate_limit_events_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.rate_limit_events
    ADD CONSTRAINT rate_limit_events_pkey PRIMARY KEY (id);


--
-- Name: saga_executions saga_executions_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.saga_executions
    ADD CONSTRAINT saga_executions_pkey PRIMARY KEY (id);


--
-- Name: saga_executions saga_executions_saga_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.saga_executions
    ADD CONSTRAINT saga_executions_saga_id_key UNIQUE (saga_id);


--
-- Name: saga_steps saga_steps_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.saga_steps
    ADD CONSTRAINT saga_steps_pkey PRIMARY KEY (id);


--
-- Name: saga_steps saga_steps_step_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.saga_steps
    ADD CONSTRAINT saga_steps_step_id_key UNIQUE (step_id);


--
-- Name: sections sections_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.sections
    ADD CONSTRAINT sections_pkey PRIMARY KEY (id);


--
-- Name: service_registry_events service_registry_events_event_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.service_registry_events
    ADD CONSTRAINT service_registry_events_event_id_key UNIQUE (event_id);


--
-- Name: service_registry_events service_registry_events_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.service_registry_events
    ADD CONSTRAINT service_registry_events_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: supersessions supersessions_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.supersessions
    ADD CONSTRAINT supersessions_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_task_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tasks
    ADD CONSTRAINT tasks_task_id_key UNIQUE (task_id);


--
-- Name: tool_definitions tool_definitions_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_definitions
    ADD CONSTRAINT tool_definitions_pkey PRIMARY KEY (tool_id);


--
-- Name: tool_executions tool_executions_invocation_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_executions
    ADD CONSTRAINT tool_executions_invocation_id_key UNIQUE (invocation_id);


--
-- Name: tool_executions tool_executions_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_executions
    ADD CONSTRAINT tool_executions_pkey PRIMARY KEY (id);


--
-- Name: tool_invocations tool_invocations_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_invocations
    ADD CONSTRAINT tool_invocations_pkey PRIMARY KEY (id);


--
-- Name: tool_versions tool_versions_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_versions
    ADD CONSTRAINT tool_versions_pkey PRIMARY KEY (version_id);


--
-- Name: tool_versions tool_versions_tool_id_version_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_versions
    ADD CONSTRAINT tool_versions_tool_id_version_key UNIQUE (tool_id, version);


--
-- Name: tools tools_name_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tools
    ADD CONSTRAINT tools_name_key UNIQUE (name);


--
-- Name: tools tools_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tools
    ADD CONSTRAINT tools_pkey PRIMARY KEY (id);


--
-- Name: training_examples training_examples_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.training_examples
    ADD CONSTRAINT training_examples_pkey PRIMARY KEY (id);


--
-- Name: user_interactions user_interactions_interaction_id_key; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.user_interactions
    ADD CONSTRAINT user_interactions_interaction_id_key UNIQUE (interaction_id);


--
-- Name: user_interactions user_interactions_pkey; Type: CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.user_interactions
    ADD CONSTRAINT user_interactions_pkey PRIMARY KEY (id);


--
-- Name: snapshots snapshots_pkey; Type: CONSTRAINT; Schema: shared; Owner: postgres
--

ALTER TABLE ONLY shared.snapshots
    ADD CONSTRAINT snapshots_pkey PRIMARY KEY (id);


--
-- Name: snapshots snapshots_snapshot_id_key; Type: CONSTRAINT; Schema: shared; Owner: postgres
--

ALTER TABLE ONLY shared.snapshots
    ADD CONSTRAINT snapshots_snapshot_id_key UNIQUE (snapshot_id);


--
-- Name: snapshots unique_snapshot_version; Type: CONSTRAINT; Schema: shared; Owner: postgres
--

ALTER TABLE ONLY shared.snapshots
    ADD CONSTRAINT unique_snapshot_version UNIQUE (aggregate_type, aggregate_id, version);


--
-- Name: idx_agent_state_last_updated; Type: INDEX; Schema: l02_runtime; Owner: postgres
--

CREATE INDEX idx_agent_state_last_updated ON l02_runtime.agent_state USING btree (last_updated);


--
-- Name: idx_agent_state_session_id; Type: INDEX; Schema: l02_runtime; Owner: postgres
--

CREATE INDEX idx_agent_state_session_id ON l02_runtime.agent_state USING btree (session_id);


--
-- Name: idx_checkpoints_agent_id; Type: INDEX; Schema: l02_runtime; Owner: postgres
--

CREATE INDEX idx_checkpoints_agent_id ON l02_runtime.checkpoints USING btree (agent_id);


--
-- Name: idx_checkpoints_created_at; Type: INDEX; Schema: l02_runtime; Owner: postgres
--

CREATE INDEX idx_checkpoints_created_at ON l02_runtime.checkpoints USING btree (created_at);


--
-- Name: idx_checkpoints_session_id; Type: INDEX; Schema: l02_runtime; Owner: postgres
--

CREATE INDEX idx_checkpoints_session_id ON l02_runtime.checkpoints USING btree (session_id);


--
-- Name: idx_checkpoints_created; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_checkpoints_created ON mcp_contexts.checkpoints USING btree (created_at DESC);


--
-- Name: idx_checkpoints_task; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_checkpoints_task ON mcp_contexts.checkpoints USING btree (task_id);


--
-- Name: idx_checkpoints_type; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_checkpoints_type ON mcp_contexts.checkpoints USING btree (checkpoint_type);


--
-- Name: idx_conflicts_status; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_conflicts_status ON mcp_contexts.context_conflicts USING btree (resolution_status);


--
-- Name: idx_conflicts_task_a; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_conflicts_task_a ON mcp_contexts.context_conflicts USING btree (task_a_id);


--
-- Name: idx_conflicts_task_b; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_conflicts_task_b ON mcp_contexts.context_conflicts USING btree (task_b_id);


--
-- Name: idx_context_versions_created; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_context_versions_created ON mcp_contexts.context_versions USING btree (created_at DESC);


--
-- Name: idx_context_versions_task; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_context_versions_task ON mcp_contexts.context_versions USING btree (task_id);


--
-- Name: idx_sessions_heartbeat; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_sessions_heartbeat ON mcp_contexts.active_sessions USING btree (last_heartbeat DESC);


--
-- Name: idx_sessions_recovery; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_sessions_recovery ON mcp_contexts.active_sessions USING btree (recovery_needed) WHERE (recovery_needed = true);


--
-- Name: idx_sessions_status; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_sessions_status ON mcp_contexts.active_sessions USING btree (status);


--
-- Name: idx_task_contexts_keywords; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_task_contexts_keywords ON mcp_contexts.task_contexts USING gin (keywords);


--
-- Name: idx_task_contexts_priority; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_task_contexts_priority ON mcp_contexts.task_contexts USING btree (priority);


--
-- Name: idx_task_contexts_status; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_task_contexts_status ON mcp_contexts.task_contexts USING btree (status);


--
-- Name: idx_task_contexts_updated; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_task_contexts_updated ON mcp_contexts.task_contexts USING btree (updated_at DESC);


--
-- Name: idx_task_rel_source; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_task_rel_source ON mcp_contexts.task_relationships USING btree (source_task_id);


--
-- Name: idx_task_rel_target; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_task_rel_target ON mcp_contexts.task_relationships USING btree (target_task_id);


--
-- Name: idx_task_rel_type; Type: INDEX; Schema: mcp_contexts; Owner: postgres
--

CREATE INDEX idx_task_rel_type ON mcp_contexts.task_relationships USING btree (relationship_type);


--
-- Name: idx_alerts_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_alerts_agent ON mcp_documents.alerts USING btree (agent_id);


--
-- Name: idx_alerts_delivered; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_alerts_delivered ON mcp_documents.alerts USING btree (delivered);


--
-- Name: idx_alerts_severity; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_alerts_severity ON mcp_documents.alerts USING btree (severity);


--
-- Name: idx_alerts_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_alerts_timestamp ON mcp_documents.alerts USING btree ("timestamp");


--
-- Name: idx_alerts_type; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_alerts_type ON mcp_documents.alerts USING btree (type);


--
-- Name: idx_anomalies_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_anomalies_agent ON mcp_documents.anomalies USING btree (agent_id);


--
-- Name: idx_anomalies_detected; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_anomalies_detected ON mcp_documents.anomalies USING btree (detected_at);


--
-- Name: idx_anomalies_metric; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_anomalies_metric ON mcp_documents.anomalies USING btree (metric_name);


--
-- Name: idx_anomalies_severity; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_anomalies_severity ON mcp_documents.anomalies USING btree (severity);


--
-- Name: idx_anomalies_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_anomalies_status ON mcp_documents.anomalies USING btree (status);


--
-- Name: idx_api_requests_consumer; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_api_requests_consumer ON mcp_documents.api_requests USING btree (consumer_id);


--
-- Name: idx_api_requests_path; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_api_requests_path ON mcp_documents.api_requests USING btree (path);


--
-- Name: idx_api_requests_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_api_requests_status ON mcp_documents.api_requests USING btree (status_code);


--
-- Name: idx_api_requests_tenant; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_api_requests_tenant ON mcp_documents.api_requests USING btree (tenant_id);


--
-- Name: idx_api_requests_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_api_requests_timestamp ON mcp_documents.api_requests USING btree ("timestamp" DESC);


--
-- Name: idx_api_requests_trace; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_api_requests_trace ON mcp_documents.api_requests USING btree (trace_id);


--
-- Name: idx_auth_events_consumer; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_auth_events_consumer ON mcp_documents.authentication_events USING btree (consumer_id);


--
-- Name: idx_auth_events_success; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_auth_events_success ON mcp_documents.authentication_events USING btree (success);


--
-- Name: idx_auth_events_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_auth_events_timestamp ON mcp_documents.authentication_events USING btree ("timestamp" DESC);


--
-- Name: idx_circuit_breaker_events_service; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_circuit_breaker_events_service ON mcp_documents.circuit_breaker_events USING btree (service_id);


--
-- Name: idx_circuit_breaker_events_state; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_circuit_breaker_events_state ON mcp_documents.circuit_breaker_events USING btree (state_to);


--
-- Name: idx_circuit_breaker_events_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_circuit_breaker_events_timestamp ON mcp_documents.circuit_breaker_events USING btree ("timestamp" DESC);


--
-- Name: idx_claims_document; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_claims_document ON mcp_documents.claims USING btree (document_id);


--
-- Name: idx_claims_embedding; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_claims_embedding ON mcp_documents.claims USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_claims_section; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_claims_section ON mcp_documents.claims USING btree (section_id);


--
-- Name: idx_claims_subject; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_claims_subject ON mcp_documents.claims USING btree (subject);


--
-- Name: idx_compliance_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_compliance_agent ON mcp_documents.compliance_results USING btree (agent_id);


--
-- Name: idx_compliance_compliant; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_compliance_compliant ON mcp_documents.compliance_results USING btree (compliant);


--
-- Name: idx_compliance_execution; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_compliance_execution ON mcp_documents.compliance_results USING btree (execution_id);


--
-- Name: idx_compliance_tenant; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_compliance_tenant ON mcp_documents.compliance_results USING btree (tenant_id);


--
-- Name: idx_compliance_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_compliance_timestamp ON mcp_documents.compliance_results USING btree ("timestamp");


--
-- Name: idx_conflicts_claims; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_conflicts_claims ON mcp_documents.conflicts USING btree (claim_a_id, claim_b_id);


--
-- Name: idx_conflicts_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_conflicts_status ON mcp_documents.conflicts USING btree (resolution_status);


--
-- Name: idx_control_operations_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_control_operations_agent ON mcp_documents.control_operations USING btree (target_agent_id);


--
-- Name: idx_control_operations_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_control_operations_status ON mcp_documents.control_operations USING btree (status);


--
-- Name: idx_control_operations_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_control_operations_timestamp ON mcp_documents.control_operations USING btree ("timestamp" DESC);


--
-- Name: idx_control_operations_user; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_control_operations_user ON mcp_documents.control_operations USING btree (user_id);


--
-- Name: idx_dataset_examples_dataset; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_dataset_examples_dataset ON mcp_documents.dataset_examples USING btree (dataset_id);


--
-- Name: idx_dataset_examples_split; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_dataset_examples_split ON mcp_documents.dataset_examples USING btree (dataset_id, split);


--
-- Name: idx_datasets_name; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_datasets_name ON mcp_documents.datasets USING btree (name);


--
-- Name: idx_docs_content_hash; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_docs_content_hash ON mcp_documents.documents USING btree (content_hash);


--
-- Name: idx_docs_embedding; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_docs_embedding ON mcp_documents.documents USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_docs_fts; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_docs_fts ON mcp_documents.documents USING gin (to_tsvector('english'::regconfig, raw_content));


--
-- Name: idx_docs_source_path; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_docs_source_path ON mcp_documents.documents USING btree (source_path);


--
-- Name: idx_docs_type; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_docs_type ON mcp_documents.documents USING btree (document_type);


--
-- Name: idx_entities_canonical; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_entities_canonical ON mcp_documents.entities USING btree (canonical_id);


--
-- Name: idx_entities_embedding; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_entities_embedding ON mcp_documents.entities USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_entities_name; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_entities_name ON mcp_documents.entities USING btree (name);


--
-- Name: idx_events_aggregate; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_events_aggregate ON mcp_documents.events USING btree (aggregate_type, aggregate_id);


--
-- Name: idx_events_created; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_events_created ON mcp_documents.events USING btree (created_at);


--
-- Name: idx_events_type; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_events_type ON mcp_documents.events USING btree (event_type);


--
-- Name: idx_goals_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_goals_agent ON mcp_documents.goals USING btree (agent_id);


--
-- Name: idx_goals_agent_did; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_goals_agent_did ON mcp_documents.goals USING btree (agent_did);


--
-- Name: idx_goals_created; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_goals_created ON mcp_documents.goals USING btree (created_at);


--
-- Name: idx_goals_goal_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_goals_goal_id ON mcp_documents.goals USING btree (goal_id);


--
-- Name: idx_goals_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_goals_status ON mcp_documents.goals USING btree (status);


--
-- Name: idx_invocation_agent_time; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_invocation_agent_time ON mcp_documents.tool_invocations USING btree (agent_did, started_at);


--
-- Name: idx_invocation_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_invocation_status ON mcp_documents.tool_invocations USING btree (status);


--
-- Name: idx_invocation_tenant_time; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_invocation_tenant_time ON mcp_documents.tool_invocations USING btree (tenant_id, started_at);


--
-- Name: idx_metrics_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_metrics_agent ON mcp_documents.metrics USING btree (agent_id);


--
-- Name: idx_metrics_labels; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_metrics_labels ON mcp_documents.metrics USING gin (labels);


--
-- Name: idx_metrics_name; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_metrics_name ON mcp_documents.metrics USING btree (metric_name);


--
-- Name: idx_metrics_tenant; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_metrics_tenant ON mcp_documents.metrics USING btree (tenant_id);


--
-- Name: idx_metrics_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_metrics_timestamp ON mcp_documents.metrics USING btree ("timestamp");


--
-- Name: idx_model_usage_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_model_usage_agent ON mcp_documents.model_usage USING btree (agent_id);


--
-- Name: idx_model_usage_agent_did; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_model_usage_agent_did ON mcp_documents.model_usage USING btree (agent_did);


--
-- Name: idx_model_usage_created; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_model_usage_created ON mcp_documents.model_usage USING btree (created_at);


--
-- Name: idx_model_usage_model; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_model_usage_model ON mcp_documents.model_usage USING btree (model_provider, model_name);


--
-- Name: idx_model_usage_request; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_model_usage_request ON mcp_documents.model_usage USING btree (request_id);


--
-- Name: idx_model_usage_session; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_model_usage_session ON mcp_documents.model_usage USING btree (session_id);


--
-- Name: idx_model_usage_tenant; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_model_usage_tenant ON mcp_documents.model_usage USING btree (tenant_id);


--
-- Name: idx_plans_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_plans_agent ON mcp_documents.plans USING btree (agent_id);


--
-- Name: idx_plans_created; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_plans_created ON mcp_documents.plans USING btree (created_at);


--
-- Name: idx_plans_goal; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_plans_goal ON mcp_documents.plans USING btree (goal_id);


--
-- Name: idx_plans_plan_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_plans_plan_id ON mcp_documents.plans USING btree (plan_id);


--
-- Name: idx_plans_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_plans_status ON mcp_documents.plans USING btree (status);


--
-- Name: idx_quality_scores_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_quality_scores_agent ON mcp_documents.quality_scores USING btree (agent_id);


--
-- Name: idx_quality_scores_assessment; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_quality_scores_assessment ON mcp_documents.quality_scores USING btree (assessment);


--
-- Name: idx_quality_scores_tenant; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_quality_scores_tenant ON mcp_documents.quality_scores USING btree (tenant_id);


--
-- Name: idx_quality_scores_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_quality_scores_timestamp ON mcp_documents.quality_scores USING btree ("timestamp");


--
-- Name: idx_rate_limit_events_consumer; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_rate_limit_events_consumer ON mcp_documents.rate_limit_events USING btree (consumer_id);


--
-- Name: idx_rate_limit_events_exceeded; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_rate_limit_events_exceeded ON mcp_documents.rate_limit_events USING btree (exceeded);


--
-- Name: idx_rate_limit_events_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_rate_limit_events_timestamp ON mcp_documents.rate_limit_events USING btree ("timestamp" DESC);


--
-- Name: idx_saga_executions_started; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_saga_executions_started ON mcp_documents.saga_executions USING btree (started_at DESC);


--
-- Name: idx_saga_executions_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_saga_executions_status ON mcp_documents.saga_executions USING btree (status);


--
-- Name: idx_saga_steps_saga; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_saga_steps_saga ON mcp_documents.saga_steps USING btree (saga_id);


--
-- Name: idx_saga_steps_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_saga_steps_status ON mcp_documents.saga_steps USING btree (status);


--
-- Name: idx_sections_document; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_sections_document ON mcp_documents.sections USING btree (document_id);


--
-- Name: idx_sections_embedding; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_sections_embedding ON mcp_documents.sections USING ivfflat (embedding public.vector_cosine_ops) WITH (lists='100');


--
-- Name: idx_sections_fts; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_sections_fts ON mcp_documents.sections USING gin (to_tsvector('english'::regconfig, content));


--
-- Name: idx_service_registry_events_service; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_service_registry_events_service ON mcp_documents.service_registry_events USING btree (service_id);


--
-- Name: idx_service_registry_events_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_service_registry_events_timestamp ON mcp_documents.service_registry_events USING btree ("timestamp" DESC);


--
-- Name: idx_service_registry_events_type; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_service_registry_events_type ON mcp_documents.service_registry_events USING btree (event_type);


--
-- Name: idx_tasks_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tasks_agent ON mcp_documents.tasks USING btree (agent_id);


--
-- Name: idx_tasks_created; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tasks_created ON mcp_documents.tasks USING btree (created_at);


--
-- Name: idx_tasks_plan; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tasks_plan ON mcp_documents.tasks USING btree (plan_id);


--
-- Name: idx_tasks_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tasks_status ON mcp_documents.tasks USING btree (status);


--
-- Name: idx_tasks_task_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tasks_task_id ON mcp_documents.tasks USING btree (task_id);


--
-- Name: idx_tool_category; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_category ON mcp_documents.tool_definitions USING btree (category);


--
-- Name: idx_tool_deprecation_state; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_deprecation_state ON mcp_documents.tool_definitions USING btree (deprecation_state);


--
-- Name: idx_tool_description_embedding; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_description_embedding ON mcp_documents.tool_definitions USING ivfflat (description_embedding public.vector_cosine_ops);


--
-- Name: idx_tool_executions_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_executions_agent ON mcp_documents.tool_executions USING btree (agent_id);


--
-- Name: idx_tool_executions_created; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_executions_created ON mcp_documents.tool_executions USING btree (created_at);


--
-- Name: idx_tool_executions_invocation; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_executions_invocation ON mcp_documents.tool_executions USING btree (invocation_id);


--
-- Name: idx_tool_executions_session; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_executions_session ON mcp_documents.tool_executions USING btree (session_id);


--
-- Name: idx_tool_executions_status; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_executions_status ON mcp_documents.tool_executions USING btree (status);


--
-- Name: idx_tool_executions_tenant; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_executions_tenant ON mcp_documents.tool_executions USING btree (tenant_id);


--
-- Name: idx_tool_executions_tool; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_executions_tool ON mcp_documents.tool_executions USING btree (tool_id);


--
-- Name: idx_tool_version_tool_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_tool_version_tool_id ON mcp_documents.tool_versions USING btree (tool_id);


--
-- Name: idx_training_examples_agent; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_training_examples_agent ON mcp_documents.training_examples USING btree (agent_id);


--
-- Name: idx_training_examples_domain; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_training_examples_domain ON mcp_documents.training_examples USING btree (domain);


--
-- Name: idx_training_examples_quality; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_training_examples_quality ON mcp_documents.training_examples USING btree (quality_score);


--
-- Name: idx_user_interactions_timestamp; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_user_interactions_timestamp ON mcp_documents.user_interactions USING btree ("timestamp" DESC);


--
-- Name: idx_user_interactions_type; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_user_interactions_type ON mcp_documents.user_interactions USING btree (interaction_type);


--
-- Name: idx_user_interactions_user; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX idx_user_interactions_user ON mcp_documents.user_interactions USING btree (user_id);


--
-- Name: ix_tool_invocations_agent_did; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX ix_tool_invocations_agent_did ON mcp_documents.tool_invocations USING btree (agent_did);


--
-- Name: ix_tool_invocations_invocation_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE UNIQUE INDEX ix_tool_invocations_invocation_id ON mcp_documents.tool_invocations USING btree (invocation_id);


--
-- Name: ix_tool_invocations_session_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX ix_tool_invocations_session_id ON mcp_documents.tool_invocations USING btree (session_id);


--
-- Name: ix_tool_invocations_tenant_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX ix_tool_invocations_tenant_id ON mcp_documents.tool_invocations USING btree (tenant_id);


--
-- Name: ix_tool_invocations_tool_id; Type: INDEX; Schema: mcp_documents; Owner: postgres
--

CREATE INDEX ix_tool_invocations_tool_id ON mcp_documents.tool_invocations USING btree (tool_id);


--
-- Name: idx_snapshots_aggregate; Type: INDEX; Schema: shared; Owner: postgres
--

CREATE INDEX idx_snapshots_aggregate ON shared.snapshots USING btree (aggregate_type, aggregate_id, version DESC);


--
-- Name: task_contexts auto_save_task_context_version; Type: TRIGGER; Schema: mcp_contexts; Owner: postgres
--

CREATE TRIGGER auto_save_task_context_version AFTER UPDATE ON mcp_contexts.task_contexts FOR EACH ROW EXECUTE FUNCTION mcp_contexts.auto_save_context_version();


--
-- Name: task_contexts increment_task_contexts_version; Type: TRIGGER; Schema: mcp_contexts; Owner: postgres
--

CREATE TRIGGER increment_task_contexts_version BEFORE UPDATE ON mcp_contexts.task_contexts FOR EACH ROW EXECUTE FUNCTION mcp_contexts.increment_task_version();


--
-- Name: global_context update_global_context_updated_at; Type: TRIGGER; Schema: mcp_contexts; Owner: postgres
--

CREATE TRIGGER update_global_context_updated_at BEFORE UPDATE ON mcp_contexts.global_context FOR EACH ROW EXECUTE FUNCTION mcp_contexts.update_updated_at_column();


--
-- Name: task_contexts update_task_contexts_updated_at; Type: TRIGGER; Schema: mcp_contexts; Owner: postgres
--

CREATE TRIGGER update_task_contexts_updated_at BEFORE UPDATE ON mcp_contexts.task_contexts FOR EACH ROW EXECUTE FUNCTION mcp_contexts.update_updated_at_column();


--
-- Name: alerts alerts_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.alerts
    ADD CONSTRAINT alerts_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: anomalies anomalies_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.anomalies
    ADD CONSTRAINT anomalies_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: claims claims_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.claims
    ADD CONSTRAINT claims_document_id_fkey FOREIGN KEY (document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: claims claims_section_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.claims
    ADD CONSTRAINT claims_section_id_fkey FOREIGN KEY (section_id) REFERENCES mcp_documents.sections(id) ON DELETE CASCADE;


--
-- Name: compliance_results compliance_results_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.compliance_results
    ADD CONSTRAINT compliance_results_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: conflicts conflicts_claim_a_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.conflicts
    ADD CONSTRAINT conflicts_claim_a_id_fkey FOREIGN KEY (claim_a_id) REFERENCES mcp_documents.claims(id) ON DELETE CASCADE;


--
-- Name: conflicts conflicts_claim_b_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.conflicts
    ADD CONSTRAINT conflicts_claim_b_id_fkey FOREIGN KEY (claim_b_id) REFERENCES mcp_documents.claims(id) ON DELETE CASCADE;


--
-- Name: consolidations consolidations_result_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.consolidations
    ADD CONSTRAINT consolidations_result_document_id_fkey FOREIGN KEY (result_document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: control_operations control_operations_target_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.control_operations
    ADD CONSTRAINT control_operations_target_agent_id_fkey FOREIGN KEY (target_agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: dataset_examples dataset_examples_dataset_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.dataset_examples
    ADD CONSTRAINT dataset_examples_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES mcp_documents.datasets(id) ON DELETE CASCADE;


--
-- Name: dataset_examples dataset_examples_example_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.dataset_examples
    ADD CONSTRAINT dataset_examples_example_id_fkey FOREIGN KEY (example_id) REFERENCES mcp_documents.training_examples(id) ON DELETE CASCADE;


--
-- Name: document_tags document_tags_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.document_tags
    ADD CONSTRAINT document_tags_document_id_fkey FOREIGN KEY (document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: evaluations evaluations_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.evaluations
    ADD CONSTRAINT evaluations_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: feedback feedback_claim_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.feedback
    ADD CONSTRAINT feedback_claim_id_fkey FOREIGN KEY (claim_id) REFERENCES mcp_documents.claims(id) ON DELETE CASCADE;


--
-- Name: feedback feedback_conflict_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.feedback
    ADD CONSTRAINT feedback_conflict_id_fkey FOREIGN KEY (conflict_id) REFERENCES mcp_documents.conflicts(id) ON DELETE CASCADE;


--
-- Name: feedback feedback_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.feedback
    ADD CONSTRAINT feedback_document_id_fkey FOREIGN KEY (document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: feedback_entries feedback_entries_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.feedback_entries
    ADD CONSTRAINT feedback_entries_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: goals goals_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.goals
    ADD CONSTRAINT goals_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: metrics metrics_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.metrics
    ADD CONSTRAINT metrics_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: model_usage model_usage_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.model_usage
    ADD CONSTRAINT model_usage_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: plans plans_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.plans
    ADD CONSTRAINT plans_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: provenance provenance_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.provenance
    ADD CONSTRAINT provenance_document_id_fkey FOREIGN KEY (document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: quality_scores quality_scores_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.quality_scores
    ADD CONSTRAINT quality_scores_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: sections sections_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.sections
    ADD CONSTRAINT sections_document_id_fkey FOREIGN KEY (document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.sessions
    ADD CONSTRAINT sessions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: supersessions supersessions_new_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.supersessions
    ADD CONSTRAINT supersessions_new_document_id_fkey FOREIGN KEY (new_document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: supersessions supersessions_old_document_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.supersessions
    ADD CONSTRAINT supersessions_old_document_id_fkey FOREIGN KEY (old_document_id) REFERENCES mcp_documents.documents(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tasks
    ADD CONSTRAINT tasks_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: tool_executions tool_executions_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_executions
    ADD CONSTRAINT tool_executions_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- Name: tool_executions tool_executions_tool_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_executions
    ADD CONSTRAINT tool_executions_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES mcp_documents.tools(id);


--
-- Name: tool_versions tool_versions_tool_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.tool_versions
    ADD CONSTRAINT tool_versions_tool_id_fkey FOREIGN KEY (tool_id) REFERENCES mcp_documents.tool_definitions(tool_id) ON DELETE CASCADE;


--
-- Name: training_examples training_examples_agent_id_fkey; Type: FK CONSTRAINT; Schema: mcp_documents; Owner: postgres
--

ALTER TABLE ONLY mcp_documents.training_examples
    ADD CONSTRAINT training_examples_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES mcp_documents.agents(id);


--
-- PostgreSQL database dump complete
--

\unrestrict WqYM5KwlojtBg3j4X9lpBMIxFvbQ26de2CwG6yFM8I4q85Oxm9VZG1xcjMQxedl

